# Index Page Categorization — Canonical Scheme
### Created: May 2026
### Status: ACTIVE — authoritative reference for `index.html` structure
### Last amended: August 2026 (five-hub structure; standing note added)

---

## Standing note on how to read this doc

**Nothing in this document is immutable.** Where earlier drafts said "do not modify" or
"do not change," read that as **"check with Daniel before changing."** These are settled
defaults recorded so that a new session doesn't re-derive them from scratch — not walls.

If a structure here would confine a build in a way that doesn't serve the site, say so and
propose the better structure. Get Daniel's sign-off, make the change, then update this doc
in the same pass so it stays an accurate description of the site rather than a stale one.

---

## Purpose

This doc is the canonical reference for organizing pages on `index.html`. When new topic pages are added, this spec determines which sub-bucket they belong to. Hand this doc to a Claude session along with the new pages and they can slot them in without rediscovering the schema.

---

## Front Page — Five Top-Level Hubs

The front page has five hubs, in this order:

1. **Cuestionarios y Práctica** — interactive AI tools and entrenadores. **Settled — confirm with Daniel before restructuring.**
2. **Vocabulario** — pages about words: meanings, families, lexical relationships
3. **Gramática** — pages about structure: rules, conjugation, syntax, patterns
4. **Notas de Clase** — one page per Spanish class, organised by *provenance* rather than word class
5. **Materiales de Referencia** — resource portal + legacy section

All hubs default to **closed** on page load. Inside Vocab and Gram, sub-buckets are also collapsed by default and can be opened independently (multiple at once is fine).

Hub id/prefix map: `hub-quizzes` · `hub-vocab` · `hub-grammar` · `hub-clases` · `hub-materials`.

---

## Vocabulario — Canonical Sub-Bucket List

Display order (by expected frequency of use):

1. **Verbos** — verb families, thematic verb groups, verb meaning deep dives
2. **Sustantivos** — noun deep dives, polysemous nouns
3. **Adjetivos** — adjective vocabulary, adjective groups
4. **Adverbios** — adverb vocabulary
5. **Interrogativos** — question word vocab (qué, cuál, cómo, dónde, cuánto, por qué)
6. **Modismos** — idioms, fixed expressions, frases hechas, tener expressions
7. **Miscelánea** — anything that doesn't fit the above (numbers, time expressions, false friends, palabras tramposas, loanwords as a list)

---

## Gramática — Canonical Sub-Bucket List

Display order:

1. **Verbos** — conjugation, forms, the verb system (infinitive, gerund, participle, ser/estar, subjuntivo, imperativo, hay vs estar, etc.)
2. **Estructuras y patrones** — multi-word and cross-cutting structures (oraciones condicionales, voz pasiva, SE pasiva/impersonal, discurso indirecto, comparativos, cleft sentences, hace + time, verbos de cambio)
3. **Pronombres** — DOP, IOP, reflexive, demonstrative pronouns, possessive pronouns
4. **Preposiciones** — de, a, por/para, con, en, etc.
5. **Adjetivos** — placement, demonstratives (as adjectives), possessives (as adjectives), comparativos when scoped to adjective behavior
6. **Sustantivos** — gender, number, nominalization, diminutivos, aumentativos
7. **Adverbios** — formation (-mente), placement
8. **Conjunciones** — y/o/pero/sino/aunque, subordinating conjunctions
9. **Artículos** — el/la/un/una/lo, neuter article uses
10. **Miscelánea** — ortografía (acentos, tildes), puntuación, anything else that doesn't fit

---

## "Verbos" Lives in Both Vocab and Gram — Decision Rule

This is intentional. The split:

- **Vocabulario → Verbos**: page is about *meaning* — what does this verb mean, what's its family, what are its lexical patterns.
  - Examples: Familia de Poner · Tema del Movimiento · Verbos de Demostración · Prestar y Pedir Prestado
- **Gramática → Verbos**: page is about *form or system* — how the verb conjugates, what its grammatical role is, what structural slot it fills.
  - Examples: El Mundo del Infinitivo · Patrones de Uso Verbal · Ser vs Estar · Subjuntivo overview · Imperativo

**Test:** "Could the lesson on this page be applied to almost any verb?" → Gramática. "Is this page about a specific verb or a small named set of verbs?" → Vocabulario.

---

## Edge-of-Two-Buckets — Resolved Categorizations

These topics have plausible homes in two places. Already-decided routing:

| Topic | Goes to | Reason |
|---|---|---|
| Comparativos | Gram → Estructuras | Cross-class structural pattern |
| Voz pasiva con ser | Gram → Estructuras | Clause-level structure |
| SE pasiva/impersonal | Gram → Estructuras | Clause-level distinction |
| Verbos de cambio (volverse, hacerse, ponerse, quedarse) | Gram → Estructuras | Structural pattern, not lexical meaning |
| Demonstrative ADJECTIVES (este, ese, aquel as modifiers) | Gram → Adjetivos | Behave as adjectives |
| Demonstrative PRONOUNS (este, ese, aquel standalone) | Gram → Pronombres | Behave as pronouns |
| Possessive ADJECTIVES (mi, tu, su) | Gram → Adjetivos | Behave as adjectives |
| Possessive PRONOUNS (el mío, el tuyo) | Gram → Pronombres | Behave as pronouns |
| Tener expressions (tener hambre, tener prisa) | Vocab → Modismos | Idiomatic combinations |
| Lunfardo single-word lists | Vocab → Miscelánea | Word-class diverse |
| Lunfardo expressions / phrases | Vocab → Modismos | Phrase-level |
| Time expressions with hace | Gram → Estructuras | Structural |
| Numbers (cardinal, ordinal) | Vocab → Miscelánea | Doesn't fit a word class |

If a new edge case appears, pick the strongest fit and commit. Don't agonize. Moving a page later is one block of HTML to relocate.

---

## Empty Sub-Buckets — Not Pre-Rendered

Empty sub-buckets are NOT in `index.html`. They exist only here. When the first page of an empty category is added, the sub-hub block is inserted at that point in the canonical order.

This keeps the live page free of empty/placeholder cards. The cost is that the schema isn't visible in the markup — that's what this doc exists for.

---

## How to Add a New Page — Existing Bucket

1. Find the matching `<div class="sub-hub" id="...">` block in `index.html`.
2. Inside its `<div class="sub-hub-items">`, add a new `<a class="link-item">` block.
3. Update the `<span class="sub-hub-count">N páginas</span>` count.
4. No CSS or JS changes required.

**Page link template** (plain page, no badge):
```html
<a class="link-item" href="topics/your_page.html">
  <div class="link-item-left">
    <div class="link-dot" style="background:#4a90d9"></div>
    <div>
      <div class="link-title">Page Title</div>
      <div class="link-sub">One-line description, ideally under 80 chars</div>
    </div>
  </div>
  <div class="link-right">
    <span class="link-arrow">›</span>
  </div>
</a>
```

**For interactive Preact+htm pages**, add a badge:
```html
<span class="link-badge" style="background:rgba(74,144,217,0.1);color:#4a90d9;border:1px solid rgba(74,144,217,0.25)">interactivo</span>
```
…inserted inside `<div class="link-right">` before the `<span class="link-arrow">›</span>`.

---

## How to Add a New Page — First Page of an Empty Category

The category has no sub-hub yet. Create one. Insert it inside the parent hub's `<div class="hub-items">`, **in the canonical order from this spec** (e.g. an Adjetivos sub-hub goes between Sustantivos and Adverbios in Vocab).

**Sub-hub block template:**
```html
<div class="sub-hub" id="HUB_PREFIX-bucket-name">
  <div class="sub-hub-header" onclick="toggleHub('HUB_PREFIX-bucket-name')">
    <div class="sub-hub-title">Bucket Name</div>
    <div class="sub-hub-meta">
      <span class="sub-hub-count">1 página</span>
      <span class="sub-hub-chevron">▼</span>
    </div>
  </div>
  <div class="sub-hub-body">
    <div class="sub-hub-items">
      <!-- page link goes here -->
    </div>
  </div>
</div>
```

**ID prefix conventions:**
- Vocab buckets: `vocab-` (e.g. `vocab-adjetivos`, `vocab-modismos`)
- Gram buckets: `gram-` (e.g. `gram-articulos`, `gram-conjunciones`)
- Materials: `materials-` (currently only `materials-legado`)

**Then** update the parent hub's `<span class="hub-count">N categorías</span>`.

---

## Notas de Clase — the fourth hub

Class sheets are organised by **where the content came from**, not by what the content is.
A single class routinely covers a noun set, a pragmatics point and a verb — so it cuts across
the Vocab/Gram word-class axis entirely. That mismatch is why it is a hub of its own rather
than a sub-bucket.

- **No sub-buckets.** The hub body holds `hub-section` blocks labelled by **year**, with one
  `link-item` per class inside, **newest first**.
- **Files:** `topics/clase-de-espanol/clase-YYYY-MM-DD.html`. Flat — no subpages.
- **Count word:** `clase` / `clases` (counts class sheets, not sections).
- **Icon / dot colour:** 📝 with rose `#f472b6`.
- **No badge** on the link items — class sheets are static, like Vocab and Gram pages.

### The pressure valve — how class sheets stay small

A class sheet is a *summary*, never an exhaustive treatment. When a topic on a sheet outgrows
that:

1. The sheet keeps a short summary and links **out** to a full page in Vocab or Gram.
2. If that full page doesn't exist yet, the sheet still ships complete; the link renders as a
   muted `.topic-link.pending` block with no `href`, and the page goes on the roadmap.
3. Links are **one-way**. Topic pages never link back to the class — they stay independent of
   when Daniel happened to learn the thing.

### When to add a class-notes landing page

Not yet. With a handful of classes the index hub lists them directly. Once the list passes
roughly **8 entries**, build `topics/clase-de-espanol/index.html` as a hub landing page and
change the index block to show the 6 most recent plus a `Ver todas las clases →` link.

---

## Count Conventions

| Where | Word |
|---|---|
| Top-level hub: Vocab, Gram | `categorías` (counts visible sub-buckets) |
| Top-level hub: Notas de Clase | `clase` / `clases` (counts class sheets) |
| Top-level hub: Materiales | `secciones` (counts visible sections — currently 2: Portal + Legado) |
| Top-level hub: Cuestionarios | `herramientas` (different scheme — leave alone) |
| Sub-hub | `página` / `páginas` (counts page links inside) |

---

## Order Within a Sub-Bucket

Pages appear in the order written in the HTML. No alphabetization. Order by importance or recency, whatever reads best. The user scans, not searches.

---

## When NO Bucket Fits

If a new page genuinely doesn't fit any canonical bucket:

1. First, try **Miscelánea** — that's what it's for.
2. Only add a brand-new bucket if at least **two pages** would belong to it and they don't fit elsewhere.
3. New buckets should be word classes or major structural categories (like Estructuras y patrones), not narrow topics. "Subjuntivo" is not a new bucket — it's pages within Gram → Verbos.

If a new bucket is genuinely needed, update this spec doc first, then add the sub-hub.

---

## Defaults Future Sessions Should Not Change Silently

Each of these is a deliberate decision, not a prohibition. Propose a change, get Daniel's
sign-off, then amend this doc.

- Don't restore the removed `+ por añadir` placeholders. Empty categories stay invisible.
- Don't reorganize Cuestionarios y Práctica without asking first.
- Don't pre-render empty sub-buckets to "scaffold" the schema.
- Don't change top-level hub names or display order without asking.
- The front-page dialect toggle has been **removed** — neutral Latin American Spanish is the permanent default. Don't reinstate it.
- Don't add ad-hoc categories outside this spec — extend the spec instead.

---

## Quick Reference — Current State

As of the August 2026 amendment, populated sub-buckets:

**Vocabulario:**
- Verbos (5): Familia de Poner · Verbos con Que- · Tema del Movimiento · Prestar y Pedir Prestado · Los Verbos de Demostración
- Sustantivos (1): La geometría de «Vuelta»

**Gramática:**
- Verbos (2): El Mundo del Infinitivo · Patrones de Uso Verbal
- Estructuras y patrones (2): Oraciones Condicionales · Se Pasiva vs. Se Impersonal
- Pronombres (1): El Pronombre Objetivo
- Preposiciones (2): Los Usos Extendidos de «De» · La regla de «De + Adjetivo»

**Notas de Clase:**
- 2026 (1): Clase del 12 de agosto de 2026

**Materiales de Referencia:**
- Portal de Recursos: materiales.html
- Legado (collapsed): mis-materiales-espanol.netlify.app/gramatica.html · /vocabulario.html

When this list goes out of date, update it (or just refer to `index.html` itself — both are valid).
