<!-- FILE ROLE ------------------------------------------------------------
WHAT THIS IS:  Where things live. The index categorization scheme, the page
               families, the verb-page organization rules, and the current
               inventory of what exists.
BELONGS HERE:  Anything answering "where does this page go" or "what exists".
DOES NOT:      How a page is BUILT (-> 03/04). What is open on a page (-> 05).
LAST UPDATED:  2026-08-23 (folder restructure; inventory refreshed from the
               live repo; "Palabras que se confunden" family added)
------------------------------------------------------------------------ -->

# 02 — Site map

## Part A — Index categorization (canonical scheme)
### Created: May 2026
### Status: ACTIVE — authoritative reference for `index.html` structure
### Last amended: August 2026 (five-hub structure; standing note added)

---

## Standing note on how to read this doc

**Nothing in this document is immutable.** Where earlier drafts said "do not modify" or
"do not change," read that as **"check with Daniel before changing."** These are settled
defaults recorded so that a new session doesn't re-derive them from scratch — not walls.

If a structure here would confine a build in a way that doesn't serve the site, say so and
propose the better structure. Get Daniel's sign-off, make the change, then update this doc
in the same pass so it stays an accurate description of the site rather than a stale one.

---

## Purpose

This doc is the canonical reference for organizing pages on `index.html`. When new topic pages are added, this spec determines which sub-bucket they belong to. Hand this doc to a Claude session along with the new pages and they can slot them in without rediscovering the schema.

---

## Front Page — Five Top-Level Hubs

The front page has five hubs, in this order:

1. **Cuestionarios y Práctica** — interactive AI tools and entrenadores. **Settled — confirm with Daniel before restructuring.**
2. **Vocabulario** — pages about words: meanings, families, lexical relationships
3. **Gramática** — pages about structure: rules, conjugation, syntax, patterns
4. **Notas de Clase** — one page per Spanish class, organised by *provenance* rather than word class
5. **Materiales de Referencia** — resource portal + legacy section

All hubs default to **closed** on page load. Inside Vocab and Gram, sub-buckets are also collapsed by default and can be opened independently (multiple at once is fine).

Hub id/prefix map: `hub-quizzes` · `hub-vocab` · `hub-grammar` · `hub-clases` · `hub-materials`.

---

## Vocabulario — Canonical Sub-Bucket List

Display order (by expected frequency of use):

1. **Verbos** — verb families, thematic verb groups, verb meaning deep dives
2. **Sustantivos** — noun deep dives, polysemous nouns
3. **Adjetivos** — adjective vocabulary, adjective groups
4. **Adverbios** — adverb vocabulary
5. **Interrogativos** — question word vocab (qué, cuál, cómo, dónde, cuánto, por qué)
6. **Modismos** — idioms, fixed expressions, frases hechas, tener expressions
7. **Miscelánea** — anything that doesn't fit the above (numbers, time expressions, false friends, palabras tramposas, loanwords as a list)

---

## Gramática — Canonical Sub-Bucket List

Display order:

1. **Verbos** — conjugation, forms, the verb system (infinitive, gerund, participle, ser/estar, subjuntivo, imperativo, hay vs estar, etc.)
2. **Estructuras y patrones** — multi-word and cross-cutting structures (oraciones condicionales, voz pasiva, SE pasiva/impersonal, discurso indirecto, comparativos, cleft sentences, hace + time, verbos de cambio)
3. **Pronombres** — DOP, IOP, reflexive, demonstrative pronouns, possessive pronouns
4. **Preposiciones** — de, a, por/para, con, en, etc.
5. **Adjetivos** — placement, demonstratives (as adjectives), possessives (as adjectives), comparativos when scoped to adjective behavior
6. **Sustantivos** — gender, number, nominalization, diminutivos, aumentativos
7. **Adverbios** — formation (-mente), placement
8. **Conjunciones** — y/o/pero/sino/aunque, subordinating conjunctions
9. **Artículos** — el/la/un/una/lo, neuter article uses
10. **Miscelánea** — ortografía (acentos, tildes), puntuación, anything else that doesn't fit

---

## "Verbos" Lives in Both Vocab and Gram — Decision Rule

This is intentional. The split:

- **Vocabulario → Verbos**: page is about *meaning* — what does this verb mean, what's its family, what are its lexical patterns.
  - Examples: Familia de Poner · Tema del Movimiento · Verbos de Demostración · Prestar y Pedir Prestado
- **Gramática → Verbos**: page is about *form or system* — how the verb conjugates, what its grammatical role is, what structural slot it fills.
  - Examples: El Mundo del Infinitivo · Patrones de Uso Verbal · Ser vs Estar · Subjuntivo overview · Imperativo

**Test:** "Could the lesson on this page be applied to almost any verb?" → Gramática. "Is this page about a specific verb or a small named set of verbs?" → Vocabulario.

---

## Edge-of-Two-Buckets — Resolved Categorizations

These topics have plausible homes in two places. Already-decided routing:

| Topic | Goes to | Reason |
|---|---|---|
| Comparativos | Gram → Estructuras | Cross-class structural pattern |
| Voz pasiva con ser | Gram → Estructuras | Clause-level structure |
| SE pasiva/impersonal | Gram → Estructuras | Clause-level distinction |
| Verbos de cambio (volverse, hacerse, ponerse, quedarse) | Gram → Estructuras | Structural pattern, not lexical meaning |
| Demonstrative ADJECTIVES (este, ese, aquel as modifiers) | Gram → Adjetivos | Behave as adjectives |
| Demonstrative PRONOUNS (este, ese, aquel standalone) | Gram → Pronombres | Behave as pronouns |
| Possessive ADJECTIVES (mi, tu, su) | Gram → Adjetivos | Behave as adjectives |
| Possessive PRONOUNS (el mío, el tuyo) | Gram → Pronombres | Behave as pronouns |
| Tener expressions (tener hambre, tener prisa) | Vocab → Modismos | Idiomatic combinations |
| Lunfardo single-word lists | Vocab → Miscelánea | Word-class diverse |
| Lunfardo expressions / phrases | Vocab → Modismos | Phrase-level |
| Time expressions with hace | Gram → Estructuras | Structural |
| Numbers (cardinal, ordinal) | Vocab → Miscelánea | Doesn't fit a word class |

If a new edge case appears, pick the strongest fit and commit. Don't agonize. Moving a page later is one block of HTML to relocate.

---

## Empty Sub-Buckets — Not Pre-Rendered

Empty sub-buckets are NOT in `index.html`. They exist only here. When the first page of an empty category is added, the sub-hub block is inserted at that point in the canonical order.

This keeps the live page free of empty/placeholder cards. The cost is that the schema isn't visible in the markup — that's what this doc exists for.

---

## How to Add a New Page — Existing Bucket

1. Find the matching `<div class="sub-hub" id="...">` block in `index.html`.
2. Inside its `<div class="sub-hub-items">`, add a new `<a class="link-item">` block.
3. Update the `<span class="sub-hub-count">N páginas</span>` count.
4. No CSS or JS changes required.

**Page link template** (plain page, no badge):
```html
<a class="link-item" href="topics/your_page.html">
  <div class="link-item-left">
    <div class="link-dot" style="background:#4a90d9"></div>
    <div>
      <div class="link-title">Page Title</div>
      <div class="link-sub">One-line description, ideally under 80 chars</div>
    </div>
  </div>
  <div class="link-right">
    <span class="link-arrow">›</span>
  </div>
</a>
```

**For interactive Preact+htm pages**, add a badge:
```html
<span class="link-badge" style="background:rgba(74,144,217,0.1);color:#4a90d9;border:1px solid rgba(74,144,217,0.25)">interactivo</span>
```
…inserted inside `<div class="link-right">` before the `<span class="link-arrow">›</span>`.

---

## How to Add a New Page — First Page of an Empty Category

The category has no sub-hub yet. Create one. Insert it inside the parent hub's `<div class="hub-items">`, **in the canonical order from this spec** (e.g. an Adjetivos sub-hub goes between Sustantivos and Adverbios in Vocab).

**Sub-hub block template:**
```html
<div class="sub-hub" id="HUB_PREFIX-bucket-name">
  <div class="sub-hub-header" onclick="toggleHub('HUB_PREFIX-bucket-name')">
    <div class="sub-hub-title">Bucket Name</div>
    <div class="sub-hub-meta">
      <span class="sub-hub-count">1 página</span>
      <span class="sub-hub-chevron">▼</span>
    </div>
  </div>
  <div class="sub-hub-body">
    <div class="sub-hub-items">
      <!-- page link goes here -->
    </div>
  </div>
</div>
```

**ID prefix conventions:**
- Vocab buckets: `vocab-` (e.g. `vocab-adjetivos`, `vocab-modismos`)
- Gram buckets: `gram-` (e.g. `gram-articulos`, `gram-conjunciones`)
- Materials: `materials-` (currently only `materials-legado`)

**Then** update the parent hub's `<span class="hub-count">N categorías</span>`.

---

## Notas de Clase — the fourth hub

Class sheets are organised by **where the content came from**, not by what the content is.
A single class routinely covers a noun set, a pragmatics point and a verb — so it cuts across
the Vocab/Gram word-class axis entirely. That mismatch is why it is a hub of its own rather
than a sub-bucket.

- **No sub-buckets.** The hub body holds `hub-section` blocks labelled by **year**, with one
  `link-item` per class inside, **newest first**.
- **Files:** `topics/clase-de-espanol/clase-YYYY-MM-DD.html`. Flat — no subpages.
- **Count word:** `clase` / `clases` (counts class sheets, not sections).
- **Icon / dot colour:** 📝 with rose `#f472b6`.
- **No badge** on the link items — class sheets are static, like Vocab and Gram pages.

### The pressure valve — how class sheets stay small

A class sheet is a *summary*, never an exhaustive treatment. When a topic on a sheet outgrows
that:

1. The sheet keeps a short summary and links **out** to a full page in Vocab or Gram.
2. If that full page doesn't exist yet, the sheet still ships complete; the link renders as a
   muted `.topic-link.pending` block with no `href`, and the page goes on the roadmap.
3. Links are **one-way**. Topic pages never link back to the class — they stay independent of
   when Daniel happened to learn the thing.

### When to add a class-notes landing page

Not yet. With a handful of classes the index hub lists them directly. Once the list passes
roughly **8 entries**, build `topics/clase-de-espanol/index.html` as a hub landing page and
change the index block to show the 6 most recent plus a `Ver todas las clases →` link.

---

## Count Conventions

| Where | Word |
|---|---|
| Top-level hub: Vocab, Gram | `categorías` (counts visible sub-buckets) |
| Top-level hub: Notas de Clase | `clase` / `clases` (counts class sheets) |
| Top-level hub: Materiales | `secciones` (counts visible sections — currently 2: Portal + Legado) |
| Top-level hub: Cuestionarios | `herramientas` (different scheme — leave alone) |
| Sub-hub | `página` / `páginas` (counts page links inside) |

---

## Order Within a Sub-Bucket

Pages appear in the order written in the HTML. No alphabetization. Order by importance or recency, whatever reads best. The user scans, not searches.

---

## When NO Bucket Fits

If a new page genuinely doesn't fit any canonical bucket:

1. First, try **Miscelánea** — that's what it's for.
2. Only add a brand-new bucket if at least **two pages** would belong to it and they don't fit elsewhere.
3. New buckets should be word classes or major structural categories (like Estructuras y patrones), not narrow topics. "Subjuntivo" is not a new bucket — it's pages within Gram → Verbos.

If a new bucket is genuinely needed, update this spec doc first, then add the sub-hub.

---

## Defaults Future Sessions Should Not Change Silently

Each of these is a deliberate decision, not a prohibition. Propose a change, get Daniel's
sign-off, then amend this doc.

- Don't restore the removed `+ por añadir` placeholders. Empty categories stay invisible.
- Don't reorganize Cuestionarios y Práctica without asking first.
- Don't pre-render empty sub-buckets to "scaffold" the schema.
- Don't change top-level hub names or display order without asking.
- The front-page dialect toggle has been **removed** — neutral Latin American Spanish is the permanent default. Don't reinstate it.
- Don't add ad-hoc categories outside this spec — extend the spec instead.

---

## Quick Reference — Current State

As of the August 2026 amendment, populated sub-buckets:

**Vocabulario:**
- Verbos (5): Familia de Poner · Verbos con Que- · Tema del Movimiento · Prestar y Pedir Prestado · Los Verbos de Demostración
- Sustantivos (1): La geometría de «Vuelta»

**Gramática:**
- Verbos (2): El Mundo del Infinitivo · Patrones de Uso Verbal
- Estructuras y patrones (2): Oraciones Condicionales · Se Pasiva vs. Se Impersonal
- Pronombres (1): El Pronombre Objetivo
- Preposiciones (2): Los Usos Extendidos de «De» · La regla de «De + Adjetivo»

**Notas de Clase:**
- 2026 (1): Clase del 12 de agosto de 2026

**Materiales de Referencia:**
- Portal de Recursos: materiales.html
- Legado (collapsed): mis-materiales-espanol.netlify.app/gramatica.html · /vocabulario.html

When this list goes out of date, update it (or just refer to `index.html` itself — both are valid).

---

## Part B — Page families defined by intent

Added 2026-08-23. This is a **second axis**, cutting across the word-class buckets in Part A.

Most pages are filed by what they are *made of* — adjectives, verbs, structures. But some pages exist for a different reason entirely: **two or more words collide at reading speed**, and that collision *is* the subject. Filing those by their grammatical material hides the only property they share.

### Family: *Palabras que se confunden*

**Bucket:** Vocabulario → **Palabras que se confunden** (new sub-bucket, sits alongside Miscelánea).

**Status: NOT YET IMPLEMENTED.** The principle is settled; the index migration is not scheduled. See `06-ideas.md` → `reagrupar-confundibles`. Until then the existing members stay where they are.

**Why not Miscelánea.** Miscelánea is where a page goes when it has *no* home — that is the definition of pigeonholing. This family has a clear identity, so it earns a named bucket.

**Why not a hub yet.** Daniel's call, 2026-08-23: flat bucket now, revisit as it fills. It will probably become a hub eventually (see the sub-types below), but a hub built for four pages is premature.

**Current and planned members:**

| Page | File | Collision type |
|---|---|---|
| Las cinco A | `topics/rasgos.html` | near-synonyms (*amable · agradable · amigable*…) |
| Tropiezos con P | `topics/tropiezos-con-p.html` | similar form (*propio · precio · premio*…) |
| Palabras Tramposas | `topics/palabras-tramposas.html` | English interference |
| Medida vs. Medio | `topics/medida-medio.html` *(in build — `TALLER-medida-medio.md`)* | similar form |

**The three collision types above are a live observation, not yet a structure.** Same felt experience — "I misread this" — three different underlying causes. If and when this becomes a hub, those are its likely spine.

**Adding a page to this family:** the test is *why the page exists*, not what it contains. If Daniel built it because two words kept getting mixed up, it belongs here — even if its material is adjectives, or nouns, or a mix. Overlap with theme pages is expected and fine: *a medida que* will also appear on a future conectores hub. The family page owns the disambiguation; the theme page cross-links rather than re-covering.

---

## Part C — Current inventory (live repo, 2026-08-23)

Regenerate rather than trust: `git clone --depth 1 https://github.com/Dan-Salyer666/mi-proyecto-espanol.git`

**Root (16):** `index.html` · `entrenadores.html` · `materiales.html` · `preguntas-centro.html` · `espanol-rioplatense.html` · `poner.html` · `que-verbos.html` · `prestar-pedir.html` · `tema-del-movimiento.html` · `traduccion-interactiva.html` · `enlace-practica.html` · `oraciones-condicionales.html` + `condicionales-tipo1/2/3` + `condicionales-practica`

**`topics/` (24):** `El_mundo_del_infinitivo` · `Geometria_vueltas` · `IOP usage` ⚠ · `Uso_de_DE` · `Verbos_de_Demostracion` · `adjectivos-no-graduables` · `adverbios` · `cuando-las-cosas-se-rompen` · `desde-hace-y-construcciones-de-tiempo` · `entradas-pasajes-y-facturas` · `formacion-de-palabras` · `formacion-de-preguntas` · `futbol-idioma-del-mundo` · `genero-de-los-sustantivos` · `la_regla_de` · `paisajes` · `palabras-tramposas` · `pedir-comida-y-bebida` · `rasgos` ⚠ · `se-pasiva-impersonal` · `seven_usage_patterns` · `tiempo_y_distancia` · `tropiezos-con-p` · `ya-todavia-aun`

⚠ = filename problem, see `05-state.md` → *Deferred edits*.

**Subfolders:** `topics/clase-de-espanol/` (2) · `topics/subpages/` (8) · `topics/verbos-en-profundidad/` (3)

**`interactive/` (9):** `comprension-lectora` · `entrenador-de-verbos` · `entrenador-de-verbos2` · `preguntas` · `preguntas-dinamica` · `preguntas-jeopardy` · `preguntas-trampas` · `quiz-genero` · `tiempo-y-distancia-interactivo`

### Datasets (not specs — they live in the repo)

- `datos/verbos/verbos-a-d.js` · `verbos-e-l.js` · `verbos-m-q.js` · `verbos-r-z.js` — Entrenador 2's verb data.
- `datos/seeds/semillas-data.js` — Comprensión Lectora seed vat (v2).
- `final_master_list.md` — **moved out of this folder into the repo** (1,224 verb rows). It is a dataset, not a spec. Still needed as the **dedupe reference** for future SpanishDict batches.
- `repo/specs/` — dead archive, ignore. Also holds the 2026-08-23 pre-restructure snapshot zip.

---

## Part D — Verb page organization

> Verbatim from `02-site-map.md`, 2026-08-23.

# Mi Proyecto Español — Verbos: Going-Forward Organization
### Created: June 2026
### Status: ACTIVE — governs how new verb pages slot into Vocab → Verbos
### Amended: August 2026 — §4 rewritten to the folder model when the hub shipped with *tener*
### Companion to: `02-site-map.md`, `03-page-standards.md`, `06-ideas.md`

---

## 1. Purpose

Two shapes of verb page now exist on the site, and they grow at different rates. This doc decides where each one lives so the **Vocab → Verbos** sub-bucket stays a short, scannable list instead of turning into a wall of individual links. Hand this file to any future session alongside `02-site-map.md` and a new verb page slots in without re-litigating the structure.

The whole point: **one extra click is cheaper than a list of twenty.**

---

## 2. The two content shapes

**A. Single-verb deep dive** — one verb, many contexts and frames.
- Examples: *esperar* (wait/hope/expect); the planned explorers for *quedar, echar, llevar, meter, dar*; eventually a rebuilt *poner*.
- Source format: a `.md` like `esperar-uso.md` — numbered frames, NOTA points, example sentences, frame/contrast tables.
- **Growth: unbounded.** You keep finding verbs that earn their own page. This is the list that explodes if left flat.

**B. Thematic cluster** — a small *named set* of verbs grouped by what they **do**.
- Examples: *Tema del Movimiento*, *Los Verbos de Demostración*, *Prestar y Pedir Prestado*, and the new breaking/damaging set (*romper, dañar, estropearse, averiarse, pudrir(se)…*).
- Each is a meaty multi-verb page that takes real work to assemble.
- **Growth: bounded and slow.** There will never be twenty of these.

---

## 3. The rule

| Shape | Home | Why |
|---|---|---|
| **Single-verb deep dive** | Child of **one hub page** | Unbounded set → hub it, so the index shows one entry no matter how many verbs |
| **Thematic cluster** | **Flat link item** in Vocab → Verbos | Bounded, slow-growing → an extra click would be over-engineering |

---

## 4. The hub: "Verbos en Profundidad"

One parent page collects every single-verb deep dive. **Shipped August 2026 with *tener* as the first child.**

### Folder model

The hub and all its children live in **one dedicated folder**. This was adopted when the hub shipped, because `topics/` was already ~25 files and this section grows without limit.

```
topics/verbos-en-profundidad/
    verbos-en-profundidad.html     ← hub
    tener.html
    tener-estructural.html         ← flat sibling extension
    (quedar.html, echar.html, poder.html … as built)
```

- **Hub file:** `topics/verbos-en-profundidad/verbos-en-profundidad.html`. The name repeats the folder deliberately — an `index.html` would give a cleaner URL but produce multiple identically-named files in the editor, which was judged the worse trade.
- **Children are named by verb alone.** The folder already carries the family name; `verbos-en-profundidad-tener.html` says it twice.
- **Hyphens, never underscores.** Every path on the site is hyphenated; one underscore folder becomes a permanent guessing game.
- **Reorganization is additive only.** No existing page moved, no existing link was rewritten. A site-wide `topics/` reorganization was explicitly considered and declined — it is a high-risk, zero-visible-change deploy and must never ride along with a content build.

### Paths

| From | To | Path |
|---|---|---|
| verb page | assets | `../../assets/…` |
| verb page | hub | `verbos-en-profundidad.html` |
| verb page | main menu | `../../index.html` |
| hub | main menu | `../../index.html` |
| `index.html` | hub | `topics/verbos-en-profundidad/verbos-en-profundidad.html` |
| favicon (all) | — | absolute `/assets/bandera/…` |

### Nesting rule — amended

The original rule was one level only: hub → verb page, no deeper. *Tener* broke it by needing a second page for the structural construction.

**Amended rule:** a verb page may have **flat sibling extensions** named `<verb>-<subtopic>.html`, living in the same folder rather than a nested subfolder. They sort alphabetically beside their parent, and their back-nav points to the parent verb page (`← Volver a Tener`), not to the hub. Per-verb subfolders remain disallowed until some verb genuinely needs three or more pages.

### What the hub page is

A *light* page: title card + one short intro paragraph + a grid of verb cards. **No content cards of its own.** Card format is the verb set large with a thesis line beneath — *TENER — un sistema, no una lista*; *PODER — una sola potencia, varios blancos* — so the hub teaches something at a glance instead of listing infinitives.

**No placeholder cards for unbuilt verbs.** A hub full of dead links is worse than a short hub. Verbs in preparation may be named in a plain roadmap note at the foot of the page; they do not get cards until they exist.

### Index wiring

A **single** `<a class="link-item">` in the Vocab → Verbos sub-hub, per `02-site-map.md` → *How to Add — Existing Bucket*. This one entry stands in for the entire deep-dive library.

**Children are NOT individually wired into `index.html`.** The hub is the only index entry; discovery happens *on* the hub page. **This is the mechanism that keeps the sub-bucket flat.**

---

## 5. The single-verb pipeline (repeatable)

1. **Draft** the verb as a `.md` — frames, NOTA points, example sentences, contrast tables. `esperar-uso.md` is the template.
2. **Build** it to `03-page-standards.md` as a child of the hub, at `topics/verbos-en-profundidad/<verb>.html`:
   - numbered sections → content cards
   - NOTA blocks → NOTA boxes (English explainer layer, Spanish terms italicized inside)
   - frame/contrast tables → decision guides
   - every example sentence → an `.example-es` row with a 🔊 button (correct Spanish only in the spoken line)
3. **Add** a verb card to the hub's `.subpage-links`. No `index.html` change.
4. **Validate** per project discipline: `node --check` on extracted JS, tag-balance counter, CSS brace count, grep the named feature markers (favicon block, back-nav path, rate bar, `es-419` chain, absence of voseo in spoken lines).
5. **Deploy the child alone**, then the hub card and any index change as a separate step — one observable change per deploy.

---

## 6. Thematic clusters stay flat — and when to revisit

- **Adding one:** a single `<a class="link-item">` in the Vocab → Verbos sub-hub + bump the `sub-hub-count`. (`02-site-map.md` → *How to Add — Existing Bucket*.) Built to `03-page-standards.md` like any topic page.
- **Trigger to reconsider:** if flat thematic verb pages ever exceed **~6–7**, stand up a parallel **"Verbos por Tema"** hub and migrate them in (same parent→subpage convention as §4). Until then, flat beats an extra click.

---

## 7. Cleanup of the two legacy pages

- **`Verbos con Que-` → remove.** Not useful; predates the single-topic format. Delete the link item, decrement the sub-hub count, archive the file. Do it anytime.
- **`Familia de Poner` → rebuild, don't delete.** *poner/ponerse* is worth keeping and overlaps the planned **meter** explorer (meter/poner are a natural pair). When the hub exists, rebuild *poner* to spec as a hub child — consider merging *poner + meter* into one explorer. Pull it from the flat list at that point. Not urgent.

---

## 8. Where the roadmap's verb explorers land

The Verb Depth Explorer pages on the horizon — **quedar, echar, llevar, meter, dar, poder, rendir** — are all single-verb deep dives, so they all become **children of the Verbos en Profundidad hub**.

***Tener* is the first child and the pattern-setter** (August 2026), not *esperar* as originally projected. What it established, for reuse:

- **Thesis-line naming** — every verb page gets a claim, not a label.
- **Frame chips** — each phrase entry carries its full grammatical frame as labelled chips (`PREP` · `IMP` · `CUANT` · `ASP` · `GRAM` · `REG`), generated from a single data array alongside the master table so the two cannot drift.
- **A legend is mandatory** wherever chips appear — placed at the head of the inventory section and mirrored into the Guía Rápida. Chips must be readable cold, months later, without hunting for the section that explained them.
- **System before inventory** — the rules that cut across the whole verb come first; the phrase families follow.
- **Hybrid accordion** — argument sections open by default, lookup sections collapsed.
- **Honest marking** — where a rule *predicts* a form but usage is unattested, the entry is tagged rather than asserted, and the open items are collected in one block at the foot of the page.

---

## 9. Net effect on the index

Vocab → Verbos goes from "every verb is its own link" to:

- **Verbos en Profundidad** ← hub; holds N single-verb pages, costs 1 index entry *(shipped: tener)*
- **Tema del Movimiento**
- **Los Verbos de Demostración**
- **Prestar y Pedir Prestado**
- *(Familia de Poner — interim, until rebuilt into the hub)*
- **Cuando las cosas se rompen** *(the breaking/damaging set — shipped)*

One entry per theme, plus one entry for the entire deep-dive library — regardless of how many individual verbs accumulate inside.

> The hub shipped in August 2026; the *Quick Reference — Current State* block in `02-site-map.md` has been updated to reflect it.

---

*End of doc. Commit a copy to the project folder once approved.*
