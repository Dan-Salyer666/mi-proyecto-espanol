# Tiempo y Distancia Interactivo — Quiz 2 & Quiz 3 Shelved Work

### Created: May 2026
### Status: SHELVED — page is functionally complete; these two quizzes deferred indefinitely
### Purpose: Continuity doc if Daniel ever wants to resume building Quiz 2 / Quiz 3

---

## Page status as of shelving

The page `interactive/tiempo-y-distancia-interactivo.html` is feature-complete *except* for two quiz stubs inside the Cuestionarios tab. Everything else ships:

- **Tab 1 — Tiempo:** done. 12 sections.
- **Tab 2 — Distancia:** done. 10 sections + cross-tab callout.
- **Tab 3 — Cuestionarios:**
  - Quiz 1 (Práctica con fichas) **done**. 50-question external bank at `interactive/subpages/tiempo-distancia-fichas-bank-1.js`. Two-column layered drag + tap UX with sticky badge pool. Cotidiano-only (ignores the register switch by design).
  - Quiz 2 (Completar la oración) **stub only** — see below.
  - Quiz 3 (Traducción EN → ES) **stub only** — see below.
- **Tab 4 — Guía Rápida:** done. 26-row cheat-sheet table.
- All images, TTS dual-voice, register filter, navy translucent tabs — all live.
- Front-page wiring: linked from `index.html` at `Cuestionarios y Práctica → Recursos Interactivos → Tiempo y Distancia (interactivo)`.

---

## Where the stubs live in the page

Both stubs are sub-panels inside `<section id="tab-cuestionarios">`. The internal sub-tab nav at the top of that section already switches between them:

```html
<nav class="subtab-bar">
  <button class="subtab-btn active" data-subtab="fichas">Práctica con fichas</button>
  <button class="subtab-btn" data-subtab="fillin">Completar la oración</button>
  <button class="subtab-btn" data-subtab="translation">Traducción</button>
</nav>
```

The two stub panels are:

- `<div class="subtab-content" id="subtab-fillin">` — Quiz 2 stub
- `<div class="subtab-content" id="subtab-translation">` — Quiz 3 stub

Each contains a `distancia-placeholder` block with a "se construye en una fase futura" message. Replace those when building.

---

## Quiz 2 — Completar la oración

### What it was meant to be
A fill-in-the-blank quiz **generated and graded by the AI** (not pre-authored). The user clicks "generar cuestionario," gets 10 fresh fill-in items, types in the blanks, hits "comprobar," and gets per-question NOTA-style English feedback explaining the construction mechanics.

### API integration
- Uses the existing `/api/claude` Netlify serverless function (`netlify/functions/claude.mts`)
- Same lazy password gate pattern as Comprensión Lectora and condicionales-practica
- Two task strings per the main spec: `generate_quiz_fillin` (create items) and `correct_fillin` (grade)
- Lenient grading on accents and capitalization; accepts known variants

### Patterns to copy
Look at **`condicionales-practica.html`** first — it's the closest model:
- Has the lazy password gate UI (lines ~210–260)
- Wraps API calls in try/catch with "Error de conexión" fallback
- Handles 401 password-incorrect responses separately from network errors
- Uses `sessionPassword` after successful gate, stored in memory not localStorage

For the question-rendering layout, **`comprension-lectora.html`** (lines ~700+) has the more mature shell — password input field as a top-level form element, then the quiz body renders below once authenticated.

### Open design questions
Daniel needs to answer these before building:

1. **Layout** — same two-column as Quiz 1 (questions left, something on right)? Or single column? Quiz 2 has no badge pool, so the right column would have to hold something else (instructions? scoreboard? regenerate button?) — or just collapse to single column.
2. **Round size** — 10 questions like Quiz 1? Or shorter (5)?
3. **Register awareness** — should Quiz 2 respect the page-level cotidiano switch, or be cotidiano-only like Quiz 1?
4. **Generation trigger** — auto-generate on tab-switch (uses tokens), or require explicit "generar nuevo cuestionario" button?
5. **Verb agreement leeway** — should the grader accept "vivo" when "Vivo" was expected (capitalization-insensitive)? Likely yes. Accents? Likely yes.

### Bank-vs-API tradeoff to flag
The original plan was API-generated. But after Quiz 1's switch to a pre-authored bank, Daniel might want Quiz 2 to also be bank-based — same `window.FICHAS_BANKS`-style loader, different bank file (`tiempo-distancia-fillin-bank-1.js`). That avoids the API cost per-round and gives more authoring control. Worth asking before building.

---

## Quiz 3 — Traducción (EN → ES)

### What it was meant to be
The user sees an English sentence ("I've lived here for two years"), types a Spanish translation, and the AI grades it. The hard part: **multiple Spanish translations should be accepted as correct** — for that English sentence:
- *Vivo acá desde hace dos años*
- *Hace dos años que vivo acá*
- *Llevo dos años viviendo acá*
- *Vivo aquí desde hace dos años*

All four (and others) are correct. The grading prompt has to recognize equivalence across the construction families taught on this page.

### API integration
- Same `/api/claude` plumbing as Quiz 2
- Task strings: `generate_quiz_translation` and `correct_translation`
- Returns include English NOTA-style explanations of *which* construction the user chose and what others would have been equally valid

### The leeway challenge
This is the engineering risk for Quiz 3. The grader needs to:
1. Recognize semantic equivalence across the page's construction families (hace que / desde hace / llevar)
2. Allow voseo vs tuteo (vivís vs vives)
3. Allow neutral Lat-Am vs Rioplatense vocabulary (acá vs aquí)
4. Catch genuine errors (wrong tense, wrong preposition, missing *que*, etc.)
5. NOT just match against one canonical answer

Prompt engineering for this needs:
- A list of acceptable translation families per stimulus passed to the model
- Explicit "accept any of: X, Y, Z" framing
- Examples of acceptable vs unacceptable variations
- Maybe a two-pass approach: first check structural correctness, then check semantic match

### Open design questions
1. **Generation:** does the AI invent English stimuli on the fly, or are the English prompts pre-authored and only grading uses the API? Pre-authored English stimuli give more control and let Daniel curate which constructions get exercised.
2. **Display of accepted alternatives:** after grading, show the user *other* valid translations they could have written? Probably yes — that's high pedagogical value.
3. **Voseo handling:** mark in the user prompt that voseo is accepted? Or grade silently?

---

## If resumed: suggested order

1. Confirm format/scope answers to the open questions above with Daniel
2. Look at `condicionales-practica.html` and `comprension-lectora.html` for password-gate and API-call patterns. Copy, don't rewrite.
3. Build Quiz 2 first (simpler API; validates plumbing in this page's context)
4. Build Quiz 3 second (same plumbing, more complex prompt design)
5. Each deploy = one observable change (Quiz 2 ships, observe; Quiz 3 ships, observe)

---

## What NOT to redo

- The page's tab chassis, CSS, register switch, TTS, images, Tiempo content, Distancia content, Guía Rápida, and Quiz 1 are all stable. Don't touch them while building Quiz 2/3.
- The 50-question bank file is final and self-registering. Don't merge its content into the page.
- The two-column layout established for Quiz 1 was a specific design decision — don't force Quiz 2/3 to use it just for symmetry.
- The `registerChanged` event dispatch from the page register switch still fires, but Quiz 1 ignores it. Quiz 2/3 should make their own decision on whether to listen.

---

*End of handoff doc.*
