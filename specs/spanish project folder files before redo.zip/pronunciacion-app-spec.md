# Pronunciación — App Spec

**Status:** Committed spec. Build in phases, one observable change per deploy, each phase tested before the next.
**Page (interactive):** `interactive/pronunciacion.html` (working name)
**Storage:** Google Drive (per-word records) + device `localStorage` (Sin Ver pools)
**Pronunciation scoring:** Azure Speech — Pronunciation Assessment, via Netlify token function
**Dialect:** Neutral Latin American Spanish throughout (no Spain *distinción*, no voseo). Azure locale `es-MX`; TTS neutral fallback chain excluding `es-AR`/`es-UY`/`es-ES`.

---

## 1. Purpose

A pronunciation drill, not a vocabulary tool. The English definition is always visible from the moment a word appears — hiding the word would defeat the point. There are two modes: **Review** (silent practice, no API) and **Test** (mic + Azure scoring). Words carry a color tag (red/yellow/green) that evolves as you test, plus a fixed subjective difficulty tag set by you.

---

## 2. Data model

### 2.1 Per-word record (Google Drive, persistent)

| Field | Type | Owner | Notes |
|---|---|---|---|
| `id` | string | system | Stable unique ID. Keys Drive updates and Sin Ver seen-sets. |
| `word` | string | **you edit** | Spanish word, e.g. `organización` |
| `definition` | string | **you edit** | English, e.g. `(the) organization` |
| `phonetic` | string | **you edit** | Custom respelling, e.g. `ohr-gah-nee-sah-SYOHN` |
| `difficulty` | `"hard"` \| `"less-hard"` | **you edit** | Your subjective tier. Set at build, editable. Never changes by testing. |
| `colorTag` | `"red"` \| `"yellow"` \| `"green"` | system | **All words start `red`.** Evolves via the ladder (§5). |
| `lastScore` | ScoreObject \| null | system | Most recent test run. |
| `bestScore` | ScoreObject \| null | system | Highest `accuracyScore` ever. |

**You edit:** `word`, `definition`, `phonetic`, `difficulty`.
**System manages:** `colorTag`, `lastScore`, `bestScore`.

**ScoreObject** (all relevant Azure data stored, even though display headline is one number):

```json
{
  "accuracyScore": 88,
  "recognizedText": "perro",
  "matched": true,
  "phonemes": [
    { "phoneme": "p",  "score": 95 },
    { "phoneme": "e",  "score": 90 },
    { "phoneme": "r",  "score": 62 },
    { "phoneme": "o",  "score": 93 }
  ],
  "fluencyScore": 100,
  "completenessScore": 100,
  "timestamp": "2026-06-05T00:00:00Z"
}
```

`fluency`/`completeness` are stored for completeness but **not used for scoring** — they are degenerate for single words. The headline metric is `accuracyScore`.

### 2.2 Local (device `localStorage`)

**Sin Ver seen-sets — five pools**, one per mutually-exclusive filter:
`HARD`, `LESS-HARD`, `YELLOW`, `RED`, `TODOS`.

- Each pool stores a set of word `id`s marked *seen*.
- **Shared across Review and Test** — seeing a word in Review marks it seen for Test, until that pool resets.
- Pools cycle independently: a word seen in a RED run is marked seen only in the RED pool, not in TODOS/HARD/etc.

---

## 3. The two modes

### 3.1 Review mode

- **No password, no API, no mic.**
- On each word, shown immediately and all functional: `word`, `phonetic`, **speaker button** (neutral TTS), `definition`, `difficulty` tag, `colorTag` badge, and a score box showing **Last / Best** (read from Drive; no Current, since no test happens).
- **Continue** is always active. Hitting it speaks the word (neutral TTS) and advances.
- Sin Ver applies (§7).
- Tags **do not change** in Review.

### 3.2 Test mode

- **Password gated** — same password as Comprensión Lectora.
- **Visible immediately:** `word`, `definition`, `difficulty` tag, `colorTag` badge, **mic badge** (under the word).
- **Hidden / non-functional until answered:** `phonetic`, speaker button, the score box, **Continue** (greyed out).
- After answering: `phonetic` appears, speaker becomes functional, score box appears (**Last / Current / Best**, §6), `colorTag` updates with audio cue (§5–6), Continue activates.
- Continue (once active) speaks the word and advances — same as Review.

---

## 4. Azure integration

### 4.1 Auth & call

- A **Netlify serverless function** mints a short-lived Azure token; the Azure key stays server-side (same secret-handling discipline as `/api/claude`). The browser Speech SDK uses the token. (Google Drive auth is separate — `drive.file`, lazy.)
- **Sent per assessment:** audio (16 kHz mono PCM) + reference text (the target word) + config: `locale: es-MX`, `gradingSystem: HundredMark`, `granularity: Phoneme`, `phonemeAlphabet: IPA`, `EnableMiscue: true`.
- **Used from the response:** `AccuracyScore` (headline), recognized/Display text (lexical gate), per-phoneme `AccuracyScore` array. Fluency/Completeness stored, not scored.

### 4.2 Score → Red / Yellow / Green

1. **Lexical gate first.** If the recognized word ≠ target (case-insensitive; accent-insensitive to avoid false fails) **or** nothing was recognized → **RED**, regardless of the number. This kills false passes like *organizasión* scoring high because it sounds nearly identical to the real word.
2. **If matched, threshold the `accuracyScore`:**
   - ≥ `greenThreshold` → **GREEN**
   - ≥ `yellowThreshold` and below green → **YELLOW**
   - below `yellowThreshold` → **RED**
3. **Thresholds start at 85 / 70 and are tuned in Phase 3** against your own voice — record words you know you say well vs. poorly, slide the cutoffs to match reality. Stored as config constants, easy to change.

### 4.3 Weak-phoneme hint (in from the start)

After answering, show a one-line hint naming the weakest phoneme(s) when one sound sits clearly below the rest — e.g. *Punto débil: la rr.* Neutral Spanish, one line, no clutter. Data comes free in the same response.

---

## 5. Color-tag ladder (state machine)

`red < yellow < green`. **A word never jumps two levels in one test** — hysteresis, so one lucky/unlucky attempt can't swing it the whole way.

- **Green result** → move **up** one step.
- **Red result** → move **down** one step.
- **Yellow result** → move **toward yellow** by one step.

Full table:

| Current tag | Test result | New tag |
|---|---|---|
| GREEN | green | GREEN |
| GREEN | yellow | YELLOW |
| GREEN | red | YELLOW |
| YELLOW | green | GREEN |
| YELLOW | yellow | YELLOW |
| YELLOW | red | RED |
| RED | green | YELLOW |
| RED | yellow | YELLOW |
| RED | red | RED |

All words begin RED; the dataset evolves as you test and improve.

---

## 6. Score display & feedback (Test mode, after answering)

### 6.1 Layout

Three boxes — **Last / Current / Best** — each showing the single `accuracyScore` number and a horizontal 0–100 bar with the score marked. Plus the weak-phoneme line (§4.3).
(Review mode shows **Last / Best** only.)

### 6.2 Raw-score color (Current vs Last) — *separate from the color tag*

- Current **>** Last → **green** box
- Current **<** Last → **red** box
- Current **=** Last → **blue** box
- Current **>** Best (new record) → **GOLD** box (overrides the above)
- First-ever attempt (no Last/Best) → GOLD (it sets the best by default)

### 6.3 Audio cue (color-tag change) — *separate from the box color*

- Tag moved **up** (improved, including to green) → **bright/high** beep.
- Tag **stayed** or **dropped** → **duller/lower** beep.

> Two independent feedback systems: the **box color** is about raw score vs your history; the **beep + badge** is about the R/Y/G ladder.

---

## 7. Sin Ver (seen-tracking) & snapshot

### 7.1 Snapshot at run start

When you hit Start, the app **picks the run's exact word list up front and freezes it.** It does not re-pick or re-shuffle mid-run. Because color-tag changes are written only at the end (§7.3), pool membership is stable for the whole run — no word leaves the RED pool under your feet.

### 7.2 Selection + reset logic (resolved at snapshot)

- Draw unseen words from the selected pool.
- If the pool's unseen words run out before the run is filled, **reset that pool's seen-set** and keep drawing from the full pool.
- Example (Test, RED pool of 30, 25 already seen, 10-question run): first 5 are the unseen words; the pool then resets; the remaining 5 are drawn from the refreshed 30. Resolved deterministically at snapshot time — same result, no live recompute.

### 7.3 Batched write at run end

The app holds all changes in memory during the run and writes to Drive **once** at the end:
- updated `colorTag`s,
- updated `lastScore` (and `bestScore` where beaten),
- seen-marks for the run's words in the active pool.

Fewer Drive writes, stable run, same pattern as the género quiz.

---

## 8. Question-count logic

Counts: **10 / 20 / 30**. Let `A` = words available in the selected pool.

- `A ≥ chosen` → run `chosen`.
- `A < chosen` but `A ≥ 10` → **reject**; popup offers only the counts that fit (`≤ A`), then back to selection.
  - e.g. `A = 25`, chose 30 → "run 10 or 20." `A = 15`, chose 20 → "run 10."
- `A < 10` → popup: *"Tienes N palabras disponibles. ¿Continuar con un set reducido?"*
  - **Yes** → run `A` questions; the **10 button highlights in a distinct "truncated" color** to signal a partial set.
  - **No** → back to selection (pick different filters).

All popups have an exit back to the selection screen.

---

## 9. Front end

- **Top:** Google Drive connect (reuse the existing pattern from Comprensión Lectora / género quiz — `drive.file`, lazy auth).
- **Mode selector:** Review / Test. Test → password prompt (Comprensión Lectora password). Review → no password.
- **Filters** (button style per Entrenador 2), **mutually exclusive**:
  - Difficulty: `HARD`, `LESS-HARD`
  - Color: `YELLOW`, `RED` (no green — you already know those)
  - `TODOS`
- **Count selector:** 10 / 20 / 30.
- **Start** → count-logic validation (§8) → snapshot (§7) → quiz.

### 9.1 Quiz card (layout per the Gemini sketches; colors/exact styling TBD)

- Top-left: color-tag badge (shows the word's current `colorTag`).
- Top-right: progress counter `[n/total]`.
- Center: speaker icon, **WORD** (large), `phonetic` (under word, per visibility rules), mic button (Test only), `definition` (always visible).
- Bottom: score boxes (§6).
- Right: Continue button (greyed in Test until answered).

---

## 10. Mic interaction (Test only)

- Mic badge sits under the word. Tap → **countdown 3, 2, 1**, then a start signal + neutral cue **"Habla"** (not voseo "Hablá").
- **Fixed 3-second capture window** with a visual timer (spinner/hourglass/shrinking bar). Records the full 3 s to completion regardless.
- Stop signal at 3 s, then **"Enviando… espera"** during the API round-trip.
- Results render: `phonetic` shown, speaker active, score boxes, weak-phoneme line, tag update + beep, Continue activates.

---

## 11. Edit / dataset entry (Phase 5 placeholders)

- Placeholder for **single-word entry** (style as on the género / tramposa pages).
- Placeholder **link to a future full-page dataset editor** (built later — out of scope for now).

---

## 12. Dialect rule

Neutral Latin American Spanish everywhere: Spanish-primary UI chrome, neutral TTS (fallback `es-419 → es-MX → es-US → es-CO → other es-*`, excluding `es-AR`/`es-UY`/`es-ES`), Azure locale `es-MX`, countdown cue "Habla." No Spain *distinción*, no voseo, unless explicitly requested.

---

## 13. Phases

| Phase | Scope | Observable result |
|---|---|---|
| **0** | This spec. | Committed. |
| **1** | Shell: Drive connect + mode select + password gate + filter buttons + count-validation popups, against a seed dataset. No quiz, no Azure. | Connect, pick filters, see the validation popups behave. |
| **2** | Review mode end-to-end (no API): card, phonetic, neutral speaker, definition, tags, Continue, Sin Ver snapshot, end stats box. | A full Review run works start to finish. |
| **3** | Azure in isolation: Netlify token function + mic + 3 s capture + single-word assessment → log the JSON. Calibrate thresholds on your voice; verify lexical gate + per-phoneme. | Say a word, see the real scores. Thresholds locked. |
| **4** | Test mode integration: score boxes (Last/Current/Best + bar + weak-phoneme line), raw-score color feedback, tag ladder, audio beeps, batched Drive write of tags + scores + seen. | A full Test run updates Drive once at the end. |
| **5** | Polish + edit/single-entry placeholders + end-stats refinements. | — |
| **6** | (Later) full dataset editor. | — |

---

## 14. End-of-run stats box

At the end of both modes, a popup shows the count of words by tag — **green / yellow / red** — for the filtered set. In Test mode these reflect the tag changes just written; in Review they reflect current tags (unchanged).

---

## 15. Open items & deferred

- **Seed dataset:** initial words need `word` / `definition` / `phonetic` / `difficulty`; all start `red`. Curate before the first live Drive connect becomes the source of truth (same caution as the género quiz).
- **Reusable specs to extract later:** `google-drive-connection-spec.md`, the password-gate pattern, the filter-button style — so future builds reference a file instead of re-deriving.
- **Cleanup (separate from this build):** remove the stale "Prefer es-AR voice" line in `master_briefing.md` (line ~249); clean neutral-tagged entries in `final_master_list.md` that use *vos* in examples (e.g. "te toca a vos" → "te toca a ti").

---

## 16. Locked decisions (settled this session)

1. Single headline metric = Azure **AccuracyScore**; no blended number, no multi-metric bars. Display = the number + a 0–100 bar.
2. **Lexical gate** forces RED on mismatch / no recognition.
3. R/Y/G thresholds **start 85 / 70, tuned in Phase 3** on Daniel's voice.
4. **Weak-phoneme hint included from the start.**
5. Color-tag **one-step ladder** (§5) as tabled.
6. **Snapshot at run start + batched Drive write at run end.**
7. **Shared Sin Ver pool** across Review and Test; five pools total.
8. Mic = **fixed 3-second window** with warning, countdown, start/stop signals.
9. Score-box color (green better / red worse / blue same / gold best) is **separate** from the R/Y/G tag + beep.
10. **Store all relevant Azure data** per word, even though only the headline number is shown.
11. **Neutral Latin American Spanish** is the absolute default (no Spain *distinción*, no voseo).
