# Mi Proyecto Español — *Tener* / Verbos en Profundidad: Estado

### Status: **SHIPPED** — August 2026
### Replaces: `verbos-en-profundidad-tener-spec.md` (delete it)
### Companions: `verbos-organizacion-spec.md` (folder + naming rules), `single-topic-page-spec.md` (scaffold), `page-roadmap.md`

**What this file is:** everything a future session needs to pick this up — what exists, what is still open, and what the build established for the verbs that follow. The spec and the content drafts are superseded; this is the single record.

---

## 1. What shipped

Three pages, one index edit, all deployed.

| File | Role |
|---|---|
| `topics/verbos-en-profundidad/verbos-en-profundidad.html` | Hub. Light page — title, intro, verb cards. One card (*tener*), plus a dashed roadmap note naming *quedar*, *poder*, *rendir* as in preparation. **No placeholder cards.** |
| `topics/verbos-en-profundidad/tener.html` | Main page. ~196 KB. |
| `topics/verbos-en-profundidad/tener-estructural.html` | Flat sibling. ~48 KB. |
| `index.html` | One `link-item` at the top of Vocab → Verbos; sub-hub count 6 → 7. |

Background on all three: `../../assets/los fondos/Guernica.webp` (capital G — Netlify is case-sensitive), `brightness(0.55)` + overlay `rgba(10,22,40,0.62)`.

### `tener.html` structure

**Parte I — El sistema** (open by default): ① El motor · ② Las preposiciones · ③ El imperativo y el deseo · ④ Pretérito e imperfecto · ⑤ Complementos con *que* · ⑤b Queísmo y dequeísmo

**Parte II — Las familias** (accordion, collapsed): ⑥ Estados físicos (15) · ⑦ Estados emocionales (22) · ⑧ Carácter y disposición (21) · ⑨ Juicio, valor y resultado (20) · ⑩ Los modales (9) · ⑪ Frases fijas y modismos (13 + 11 modismos)

**Parte III — Referencia:** ⑫ Tabla maestra (filterable) · Puntos por confirmar · subpage link

**100 phrases · 19 NOTAs · 88 spoken examples · 13 TOC anchors.**

### `tener-estructural.html` structure

① El marco (*tener* + objeto + predicado) · ② El resultativo (agreement) · ③ *Haber* · *tener* · *llevar* · ④ Las formas fijas · ⑤ El reproche (*te lo tengo dicho*) · ⑥ La negativa (*tener* + obj + *sin* + inf) · ⑦ *Tener a alguien por*

**7 sections · 8 NOTAs · 31 spoken examples.** Sticky TOC, no accordion, no master table. Ships with **no** `por confirmar` chips — all its flagged items were resolved before build.

---

## 2. Open questions — for class

Eleven entries on `tener.html` carry a `? por confirmar` chip, and the page has a **Puntos por confirmar** block near the bottom listing six of them. Daniel is slipping these into class individually rather than as a list. **When one is settled, remove its chip and its line from that block.**

| # | Item | The question |
|---|---|---|
| 1 | **¡Ten vergüenza!** | Genuine productive imperative, or a frozen reproach? Highest consequence — it decides whether the ③ asymmetry table needs rewriting. Currently marked `IMP ✓ · neg ✓`. |
| 2 | *ten tacto* · *ten iniciativa* · *ten sangre fría* · *ten coraje* | All marked ✓ because the controllability rule predicts it. Are they actually said as commands? |
| 3 | *tener mala pata* | Panhispanic, or regionally narrower? |
| 4 | *tenerle idea a alguien* | Current usage and register in the Río de la Plata. |
| 5 | *interés en* vs. *interés por* | Is the fields/people split real, or too neat? |
| 6 | *respeto a* vs. *respeto por* | Is the authority/admiration split real? |
| 7 | *ten en mente* · *ten a mano* · *ten a raya* | Marked ✓ — actually used as imperatives? |
| 8 | *tener bajo control* | Marked ✓ as a directive. Confirm. |
| 9 | *tener madera de* | Register and currency in Latin America. |
| 10 | *tener un quilombo* | Register call — kept with a badge. Too coarse for the page? |
| 11 | *tener previsto* / *tener por costumbre* | Flagged formal — accurate, or ordinary register? |

**Note on the marker.** `por confirmar` currently promises a native-speaker review that is happening slowly and informally. If that stalls, relabel the chip to `uso variable` and rewrite the block to say these are lower-confidence rather than pending — a marker that never resolves is worse than none. Daniel's call; leave as-is for now.

**Two AI reviews already applied** (Gemini, treated as a second opinion, not attestation): the first resolved 30 drafted items for `tener.html`, the second resolved 5 for `tener-estructural.html`. Corrections that landed include *envidia* → dative (*tenerle envidia a*), *dificultad en* dropped in favour of *para*, *¡Ten suerte!* deleted as rule-breaking, *gripe/catarro* taking no quantifier (*una gripe fuerte* instead), and the word order in `tener-estructural` §⑥ reversed to object-first (*tengo tres libros sin leer*).

---

## 3. The frame chip system

The device the page hangs on, and the thing most worth reusing.

Every phrase entry in Parte II carries a strip of **labelled** chips. The label is a dimmed, letter-spaced axis name inside the chip, so no value is ever orphaned.

| Axis | Colour | Values |
|---|---|---|
| `PREP` | violet | `de` `a` `con` `en` `por` `para` `sobre` `que` · `ninguna` · slash = both |
| `IMP` | green ✓ / red ✕ / amber mixed | `✓` · `✕` · `✕ · neg ✓` · `✓ · neg ✓` · `→ que tengas` |
| `CUANT` | grey | `mucho/a/os/as` · `ninguna` |
| `ASP` | teal | `pret ≠ imp` |
| `GRAM` | blue | `le + a` · `+ obj. directo` · `+ infinitivo` · `+ subj` · `ind · neg → subj` · `sujeto inanimado` · `lleva artículo` · `usa adjetivo` · `casi siempre negativo` · `neg · interrog` |
| `REG` | rose | `coloquial` · `formal` · `muy formal` |
| `?` | dashed outline | `por confirmar` |

**Chips appear on every entry**, including where a whole family shares the same values — absence must never mean "not checked".

### Hard-won lessons

- **A legend is not optional.** The first build shipped without one and was unreadable a week later. Bare `—` for both "no preposition" and "no quantifier" was the specific failure. The legend now sits at the head of Parte II **and** inside the Guía Rápida modal.
- **Rename opaque values rather than documenting them.** `dativo` → `le + a` was worth more than the paragraph explaining `dativo`.
- **One meaning per colour.** The first build had amber doing both `por confirmar` and mixed-imperative, and grey doing both empty-preposition and quantifier.
- **English for the legend**, on an otherwise-Spanish page. Its whole job is being readable cold.
- Writing the legend **caught three content errors** — *ganas*, *ganas de* and *esperanza* were wrongly tagged `→ que tengas`, conflating the imperative escape hatch with the subjunctive complement. Only *éxito* and *suerte* legitimately carry it.

---

## 4. How the page is built

`tener.html` is **generated**, not hand-written, for the parts that repeat.

- A single Python data table holds all 100 phrases (`frase, obj, gloss, prep, imp, cuant, extra, region, registro, confirm`).
- It emits both the family-card HTML **and** the JS array behind the tabla maestra, so **the cards and the table cannot drift**. A validation check asserts entry count == array length.
- Parte I, the legend and the NOTAs are hand-written.

**Validation run after every build step:** Python tag-balance checker (strip script/style/comments, stack-track, skip void elements) · CSS brace count · `node --check` on every extracted JS block · greps for the favicon block, back-nav path, background path, rate bar, `es-419` fallback chain · no voseo in any `.example-es` · every example row has a speak button and a `data-region` · all TOC anchors resolve.

If the page needs regenerating from scratch, the data table is the thing to rebuild; everything else follows from it.

---

## 5. Language and policy notes

- All spoken lines are **neutral Latin American**. Rioplatense items (*fiaca*, *bronca*, *onda*, *quilombo*, *tené*) appear as text with a `reg-badge` and still play with a neutral voice.
- NOTA blocks are **English** on otherwise-Spanish pages; Spanish terms italicized inside.
- Deliberate redundancy: ④ overlaps a future pretérito/imperfecto page, ⑤ and ⑤b overlap the future subjuntivo hub, and ⑤b overlaps a future queísmo page. **This was requested** — one place to review *tener* completely, with reinforcement later.

---

## 6. What's next

- **`quedar`** — next verb. Big topic (resultant states, pronominal *quedarse*, the mandatory *se*).
- **`poder`** — spec exists: `verbos-en-profundidad-poder-spec.md`. Thesis line already chosen: *una sola potencia, varios blancos*. Cross-links to *tener* ④ via the *pude / podía* ↔ *tuve que / tenía que* parallel.
- **`rendir`** — spec exists: `rendir-page-spec.md`, content approved, HTML not started.
- **Participios como adjetivos** — roadmap §3, under the **Adjetivos** hub, not this one. `tener-estructural.html` already covers agreement and the four-way auxiliary contrast (*haber* invariable · *ser* passive · *estar* resultant · *tener/llevar* resultative) and links forward to it. That page should cover what this one does **not**: dual participles (*freído/frito*, *imprimido/impreso*, *despertado/despierto*, *elegido/electo*), the animacy split (*puerta abierta* vs. *persona abierta*), and participles lexicalized as nouns. Cross-link on agreement rather than re-covering it.

---

*One file per project. Delete `verbos-en-profundidad-tener-spec.md`; this replaces it.*
