<!-- FILE ROLE ------------------------------------------------------------
WHAT THIS IS:  The rules of this folder. What each file is for, how a spec is
               born and killed, where a new idea goes, what gets handed back
               at the end of a session.
BELONGS HERE:  Rules about the folder itself.
DOES NOT:      Anything about Spanish or about the site.
LAST UPDATED:  2026-08-23 (created in the folder restructure)
------------------------------------------------------------------------ -->

# 00 — How this folder works

**Read this first. It is two pages and it will save you an hour.**

Before 2026-08-23 this folder held 25 markdown files organised **by topic** — one file per page, per idea, per spec. That is unbounded by construction: every new topic mints a new file and nothing has an exit condition. Daniel could not see what was active and neither could a fresh session.

It is now organised **by role**. There is a fixed number of jobs a document can do, so the folder's shape stays stable and only its contents change. This mirrors the cadence Daniel already uses on his Nobara Linux project, which works.

---

## The eight permanent files

These always exist, always with these names. They are edited, never replaced or multiplied.

| File | Its job |
|---|---|
| `00-README-project-folder.md` | This file. The rules. |
| `01-briefing.md` | The learner, language policy, content philosophy, design tokens, workflow, collaboration protocol. |
| `02-site-map.md` | Where things live. Index categorization, verb organization, page families, current inventory. |
| `03-page-standards.md` | How a static topic page is built. |
| `04-app-standards.md` | How an interactive / Drive-backed app is built. |
| `05-state.md` | What is live and still has open threads. Deferred edits. Shelved decisions. Recent sessions. |
| `06-ideas.md` | The dumping ground — **index only**. One short block per idea. Must stay scannable. |
| `07-materials.md` | Raw material and demoted specs, full text, referenced by slug from `06`. Append-only. |

## The temporary files: `TALLER-<slug>.md`

A full build spec for a page **actively being built**. **Maximum three at a time.** These are the only files allowed to come and go.

**Plus one standing exception: `TALLER-clase.md`.** Class notes are a recurring process, not a one-off build, so they get a permanent file outside the cap. Its top half is the procedure (which never changes); its bottom half is the current class (which is cleared when that sheet ships). A class never competes with a build for a slot.

**Current slots (2026-08-23):** `TALLER-rendir.md` · `TALLER-ser-estar.md` · `TALLER-medida-medio.md` · `TALLER-clase.md` (standing).

---

## Rule 1 — Spec lifecycle: the built page *is* the spec

The recurring failure was that build specs outlived their builds. So:

**Born.** A spec becomes a `TALLER-` file only when Daniel says *"we're building this next."* Not when the idea arrives, not when it gets interesting, not when it gets long. An elaborate idea is still an idea.

**Lives.** As `TALLER-<slug>.md`, one of at most three. Promotion **moves** the text out of `06`/`07` — it is never copied, so there is never a second version drifting.

**Dies at deploy — in the same session as the deploy.** Killing it is **Claude's job, not Daniel's.** It is not something Daniel should have to remember. Death is a three-way split:

1. Anything that describes how the site is built *in general* → promote into `03` or `04`.
2. Anything still open → **one line** in `05-state.md`.
3. Everything else → **deleted**, because the page now contains it.

**Never keep a spec "for reference."** That is precisely how `repo/specs/` grew to 40 dead files that nobody reads. The shipped page is a more accurate record of itself than any document about it can be — this folder had a state file claiming 11 chips on a page that actually had 19.

---

## Rule 2 — Idea intake: an idea is a heading, never a file

New idea → a `###` block in `06-ideas.md`. Never a new file. The minimum it must carry is three lines, deliberately cheap:

- **What** — one sentence.
- **Where it came from** — a class, a mistake Daniel made, a gap he hit while reading. This is the field that stops an idea from becoming unreadable in six months.
- **Shape** — static page / app / addition to an existing page / unknown.

If there is more than a paragraph of raw material, it goes to `07-materials.md` under the same slug and the block points at it. **`06` must stay scannable in one screen** — that is its entire value.

Ideas are never ranked and never dated as commitments. The only ordering is a **Next up** list of at most five at the top of `06`, which only Daniel edits.

**Promotion** requires both: Daniel picks it, and a slot is free. Nothing else promotes an idea — not age, not how well-specced it is.

**Nothing is deleted for tidiness.** Content leaves a file only when it has landed somewhere else — the site, or another file. Same golden rule as site content.

---

## Rule 3 — No file promises work

A file may record that something is deferred. It may not turn that into a queue with an implied deadline, and Claude may not read one back as a to-do list.

- `05-state.md` has a **Deferred edits** section phrased as *"when this page is next open, also do X"* — not *"pending tasks."*
- **Uncertainty is annotated on the page, never converted into a task.** If a claim is shaky, mark it `USO VARIABLE` / `REG: incierto` / `NO ATESTIGUADO` at the point of the claim and move on. See `01-briefing.md` → *Content Sign-Off Is Daniel's Alone*.
- Teacher questions live in the `Preguntas para la profe` block on class sheets. That is a notepad, not a work queue.

---

## Rule 4 — Session-end protocol

Every session ends with **updated versions of files that already exist**. Concretely, at the end of a session Claude hands back whichever of these apply:

| If this happened | Hand back |
|---|---|
| A page shipped | `05-state.md` updated **and** its `TALLER-` file killed per Rule 1 |
| A general rule was learned | `03-page-standards.md` or `04-app-standards.md` |
| A site-wide fundamental changed | `01-briefing.md` |
| A page was added, moved, or renamed | `02-site-map.md` |
| New ideas came up | `06-ideas.md`, plus `07-materials.md` if there is raw text |
| A build was started | one new `TALLER-<slug>.md` (only if a slot is free) |
| A class sheet was worked on | `TALLER-clase.md` |

Also update the **Recent sessions** log at the top of `05-state.md` — two lines, capped at five entries, oldest drops off. It exists so a cold session knows what just happened without reading everything.

**If Claude thinks it needs a file outside this set, it must say why and get Daniel's agreement first.** The folder did not reach 25 files because anyone decided it should; it reached 25 because each individual new file seemed reasonable at the time.

---

## Ground truth

The **live repo** is always authoritative over anything written here:

```
git clone --depth 1 https://github.com/Dan-Salyer666/mi-proyecto-espanol.git
```

`repo/specs/` in there is a **dead archive** — ignore it entirely. It also holds `mi-proyecto-espanol-project-folder-snapshot-2026-08-23.zip`, the 24 pre-restructure files preserved verbatim, in case anything is ever missed.

Sessions are irregular and can be months apart. Every file in this folder opens with a role header stating what it is, what belongs in it, and what does not — so it can be read cold.
