<!-- FILE ROLE ------------------------------------------------------------
WHAT THIS IS:  The raw-material vault. Full text of every idea that has not
               been promoted to a TALLER file, preserved verbatim.
BELONGS HERE:  Anything longer than a paragraph that 06-ideas.md points to.
DOES NOT:      Anything already built (the page is the record) or anything
               currently in a TALLER file (no duplicates — promotion MOVES text).
HOW TO USE:    Never read this file top to bottom. Find the slug in
               06-ideas.md, then jump to the matching "## SLUG" heading here.
NOTHING HERE IS DELETED. Material leaves only by being promoted out.
LAST UPDATED:  2026-08-23 (created in the folder restructure)
------------------------------------------------------------------------ -->

# 07 — Materials

Slug index (all sections are `## slug — title`):

| Slug | Title | Origin |
|---|---|---|
| `gradacion` | Gradación e intensidad | Class 2026-07-30 |
| `distancia-psicologica` | Distancia psicológica / atenuación | Comprensión Lectora story |
| `poder` | Verbos en Profundidad — poder | Roadmap |
| `adverbios-adds` | Adverbios — three gaps + two fixes | Audit of live page |
| `pronunciacion` | Pronunciation app (Azure) | Daniel, back-burnered 2026-08-23 |
| `entrenador-admin` | Entrenador data admin | Discussion |
| `conectores` | Logical connectors — source notes | Raw dump |
| `conectores-imagenes` | Conectores — mental images | Raw dump |
| `tiempo-distancia-quizzes` | Shelved quiz 2 + quiz 3 drafts | Shelved 2026 |
| `ya-fase-etapa` | ya — unapplied fase/etapa half | Half-applied addendum |
| `roadmap-detalle` | Full roadmap detail + source-file map | page-roadmap.md |

---

## gradacion — Gradación e intensidad

> Moved verbatim from `gradacion-e-intensidad-page-spec.md` on 2026-08-23. NOTE: §8's clause "verify every verb pair in ③ against RAE + teacher before content sign-off" is VOID as of 2026-08-23 — content sign-off is Daniel's alone. Shaky rows in the ③ pair table get `REG: incierto` or `NO ATESTIGUADO` inline instead. Must be resolved against `roadmap-detalle` §6 (Grados y cantidades) before building — same territory, two directions.

<!-- ─── begin verbatim ─── -->

# Gradación e intensidad — Page Spec

> **Status:** PRELIMINARY. Architecture and scope only. Card contents, NOTA text,
> example sentences, images, accent trio, and background pattern are all **not yet
> settled** — this doc exists to hold the shape while the details get hashed out.
> **Do not build from this as-is.** Content draft comes first, per house workflow.
>
> **Origin:** Spanish class, July 30 2026. Teacher flagged \**me encanta mucho* and laid
> out the gustar ladder (*me gusta → un poco → bastante → mucho → muchísimo → me encanta*,
> and nothing above *encanta*). Recognized as the same phenomenon as the existing
> *adjetivos no graduables* page, but operating across far more than adjectives.

---

## 1. Núcleo en una línea

**Spanish gives a predicate one intensity slot.** If the word already fills that slot —
lexically, morphologically, or constructionally — the syntactic intensifier (*muy* /
*mucho*) is locked out. \**Muy delicioso* and \**me encanta mucho* fail for the identical
reason.

The page's job is to make that one principle visible across word classes, and — more
usefully — to answer the question the prohibition raises: **if not *muy/mucho*, then what?**

---

## 2. Placement

- **Section:** Gramática → **Estructuras y patrones**
  - Rationale: cross-cutting by nature (verbs, adjectives, adverbs, morphology). Does not
    belong under Adjetivos, which is the whole point of building it separately.
- **File:** `topics/gradacion-e-intensidad.html`
- **Back nav:** `../index.html` → `← Volver al menú`
- **Index bucket:** `gram-estructuras` (existing sub-hub — increment `sub-hub-count`)
- **Build spec:** standard `single-topic-page-spec.md`. Static, no API, neutral TTS.

**Title candidates** (pick later):
1. *Gradación e intensidad* — subtitle: *Un solo espacio para el grado*
2. *Un solo espacio para la intensidad*
3. *Lo que no admite «muy»*

---

## 3. Relationship to the existing Adjetivos page

**Nothing on the existing page gets torn up or moved.** It stays as the adjective-specific
deep dive.

- This page carries **one truncated adjective card** (see ⑦) — the principle restated for
  adjectives in a few lines, a short illustrative list, and an explicit link out.
- Adjective examples (*delicioso, enorme, horrible*) may appear **as illustration** in the
  general cards (② especially), since the principle can't be taught without them. That's
  fine — the truncated card is the formal handoff, not the only mention.
- **Adjetivos relacionales** (\**energía muy nuclear*, \**informe muy mensual*) —
  recommend these stay **entirely** on the adjectives page. They block *muy* for a
  different reason (classifying, not qualifying — no scale at all), and folding them in
  here muddies the one-slot thesis. Mention in passing at most.
- Add a short pointer NOTA on the **existing** adjectives page directing up to this one.
  Separate edit, separate deploy — not bundled into this build.

---

## 4. Proposed card breakdown

Eight cards + decision guide. Count is negotiable; ③ and ⑥ are the load-bearing ones.

### ① El principio: un solo espacio
The one-slot thesis stated plainly, with the two flagship failures side by side
(\**muy delicioso* / \**me encanta mucho*) to establish that this is one phenomenon and
not two coincidences. Short card. Sets up everything below.

### ② Léxico elativo — la intensidad ya viene dentro
Words that *are* the intensified version of a plainer word. Paired presentation
(plain → elative) so the "already contains *muy*" claim is visible rather than asserted.

Sample pairs: *bueno → excelente · grande → enorme · malo → atroz · rico → delicioso ·
bonito → precioso · sorprendente → asombroso*. Verbs get their own card (③) but a
one-line forward reference belongs here.

### ③ Verbos de emoción: la escala del gusto — **flagship card**
The teacher's ladder, then the generalization: **neutral psych-verb + elative
counterpart** is a systematic pattern, not a *gustar* quirk.

The ladder as given in class:
> *me gusta · me gusta un poco · me gusta bastante · me gusta mucho · me gusta muchísimo ·* **me encanta**

Then the pair table (draft inventory — verify each before content sign-off):

| Neutral (admite *mucho*) | Elativo (lo bloquea) |
|---|---|
| gustar | **encantar**, fascinar |
| interesar | **apasionar**, fascinar |
| querer | **adorar**, idolatrar |
| no gustar / disgustar | **detestar**, aborrecer |
| molestar, fastidiar | **indignar**, enfurecer |
| dar miedo, asustar | **aterrar**, aterrorizar |
| sorprender | **asombrar**, pasmar |
| alegrar | **entusiasmar**, emocionar |
| cansar | **agotar**, extenuar |

Plus a short non-psych tail to show the pattern isn't confined to emotion verbs:
*llover → diluviar · comer → devorar · romper → destrozar · destruir → arrasar ·
pedir → suplicar · reír → carcajearse*.

### ④ Escalas cerradas — lo que llega al tope
Different mechanism, same surface effect: the property has a built-in ceiling, so degree
is meaningless. *muerto, lleno, vacío, perfecto, único, infinito, embarazada*; verbs
*morir, terminar, acabar, aniquilar*. Key payoff: these take **completamente / totalmente**,
not *muy* — which is the bridge into ⑥.

### ⑤ Ya intensificado por la forma
Cases where morphology or a fixed expression fills the slot:
- **-ísimo** — \**muy buenísimo*, \**muy carísimo*
- **Prefijos** — *rebueno, superconocido, archiconocido, hipersensible*
- **Comparativos sintéticos** — \**más mejor*, \**muy mejor* (but ✓ *mucho mejor* — see ⑧)
- **Locuciones precargadas** — *muerto de hambre, hecho polvo, a más no poder*

### ⑥ Qué se dice en su lugar — **second load-bearing card**
The correction to how this is usually taught: *no graduable* does **not** mean *no
intensificable*. It means a **different intensifier**.

- **Reforzadores de veracidad:** *realmente, verdaderamente, absolutamente, totalmente,
  completamente, simplemente, francamente*
  → *absolutamente delicioso · realmente me encanta · me encanta de verdad*
- **Para escalas cerradas:** *completamente lleno, totalmente vacío*
- **Por encima de *encanta*, la lengua se vuelve perifrástica:**
  *me vuelve loco · me muero por · soy fanático de · no puedo vivir sin*
  → This is the actual top of the ladder and the practical payoff of the whole page.

### ⑦ Adjetivos — resumen y enlace *(truncated by design)*
Three or four lines: same principle, applied to adjectives; a compact illustrative list;
then the link out to the existing page for the full treatment (including relacionales).
Deliberately thin. Uses the `.subpage-links` block styling or a variant — decide at build.

### ⑧ Trampas vecinas
Two adjacent errors that live in the same conversation and are worth catching here:
- ***muy* vs *mucho* distribution** — *muy* modifies adjectives/adverbs, *mucho* modifies
  verbs/nouns. \**Muy me gusta*. And the exception: *mucho* **does** modify synthetic
  comparatives — *mucho mejor* ✓ / \**muy mejor* ✗.
- **La escala negativa corre con *nada*, no con *mucho*** — *no me gusta nada* is the
  **intensified** negative; *no me gusta mucho* is a **mitigated** one. Asymmetry worth
  its own row.

### Decision guide (optional, recommend include)
Shape: *¿Puedo decir «muy/mucho» aquí?* → three or four rows routing to
*sí* / *no, usá **completamente*** / *no, usá **realmente*** / *no, cambiá de palabra*.

---

## 5. NOTA\* candidates — proposed, not approved

Per house rules these are a discussion, not a unilateral insert. Candidates, in rough
priority order:

1. **The register caveat (recommend: include).** *Me encanta muchísimo* does occur in
   casual Latin American speech and online. The teacher's rule is the right rule to
   internalize and to write by, but it's a **register line, not a grammaticality wall**.
   Daniel reads above his level and will meet it in the wild — tag it honestly rather
   than pretending it doesn't exist. Sits in ③.
2. **Two mechanisms, one symptom.** Why elative lexemes (②/③) and closed scales (④) are
   genuinely different things that produce the same blocked slot. Structural clarity —
   the kind of distinction that earns its keep. Sits between ③ and ④, or opens ④.
3. **Why English hides this.** English lets *very* stack much more freely (*very
   delicious* is unremarkable), so the constraint is invisible from the L1 side and has
   to be learned as a positive rule. Short. Sits in ①.
4. **The *mucho mejor* exception explained** — why *mucho* survives where *muy* dies on
   synthetic comparatives. Possibly too fine-grained for a NOTA; may just be a table row
   in ⑧.

---

## 6. Scope boundaries

**In scope**
- The one-slot principle and its four sources
- The full alternate-intensifier inventory (this is the reason the page exists)
- The *gustar → encantar* ladder and the psych-verb pair pattern
- *muy* vs *mucho* distribution; the *nada* negative asymmetry

**Out of scope**
- Full treatment of **degree adverbs** (*medio, bastante, demasiado, apenas*) — the
  `adverbios` spec explicitly punted these as "different topic." This page uses
  *un poco / bastante / muchísimo* as **rungs on the ladder** in ③ but does not take on
  the degree-adverb system. If that page ever gets written, this one links to it.
- Comparative and superlative **syntax** (*más… que*, *el más… de*) — separate topic
- **Adjetivos relacionales** — stays on the adjectives page (see §3)
- **Aumentativos / diminutivos** as intensity (*-azo, -ote*) — adjacent, but that's a
  morphology topic. Flag as a possible future cross-link, not content here.

---

## 7. Cross-links to add later (each a separate, intentional edit)

- Existing **adjetivos no graduables** page → pointer NOTA up to this page
- **Adverbios** page → link, if/when the degree-adverb additions land
- Any **gustar-class verbs** page → link into card ③
- `index.html` → new `link-item` in `gram-estructuras`, count incremented

---

## 8. Deferred — decide before content draft

- [ ] Final title + Spanish subtitle
- [ ] Accent color trio and background pattern (per `single-topic-page-spec.md` §14)
- [ ] Card count — is ⑧ one card or two? Is ① too thin to stand alone?
- [ ] **Does card ③ stay here, or does the psych-verb ladder graduate to its own page**
      in the Verbos en Profundidad track, with a summary + link left behind? Open.
- [ ] Images — none proposed yet. A single "one slot, already occupied" visual for ①
      could carry the whole thesis, but nothing is committed.
- [ ] Guía Rápida modal — plausible fit (a *muy / mucho / completamente / realmente*
      cheat sheet). Decide once card content firms up.
- [ ] Verify every verb pair in ③ against RAE + teacher before content sign-off. Several
      of the elative claims (*me fascina mucho*, *odio mucho*) sit closer to the
      acceptability line than others and need checking, not asserting.

---

*End of preliminary spec. Not build-ready. Next step: content draft for sign-off.*

<!-- ─── end verbatim ─── -->

---

## distancia-psicologica — Distancia psicológica / atenuación

> Moved verbatim from `distancia-psicologica-page-spec.md` on 2026-08-23. Slug unconfirmed; §9 decisions open.

<!-- ─── begin verbatim ─── -->

# Mi Proyecto Español — Spec: *La distancia psicológica en el verbo* (página de gramática)

**Type:** Single-topic reference page (info/grammar only)
**Location (proposed):** `topics/distancia-y-atenuacion.html` — slug flagged for confirmation in §9
**Scaffold authority:** inherits `single-topic-page-spec.md` in full (fonts, palette, favicon, back-nav, English NOTA layer, neutral-voice TTS, rate bar, emoji policy, responsive rules, self-check). This document specifies *only* what is unique to this topic: the content architecture, the example sets, the NOTA plan, the contrast device, and what is shelved / cross-linked.
**Status:** DRAFT for later. No build until decisions in §9 are locked. Filed for the queue, not for this session.
**Origin:** Daniel hit *¿Tú por casualidad no guardarás una grabación de aquellos tiempos?* in a Comprensión Lectora story and the future tense there threw him. Gemini framed the broader phenomenon as "psychological distancing." That framing is sound and is the spine of this page.

---

## 1. Thesis (the spine of the whole page)

The page runs on **one idea: the present indicative is the deictic center, and every softening, hedging, or conjecturing move is a step away from it.**

- The **present indicative** is *here, now, real, certain*. It asserts. It is the most direct thing a Spanish verb can do.
- To be polite, hesitant, speculative, or emotional, the speaker **steps back from that center** — and Spanish maps that step onto the **verb's tense and mood**, not onto a separate politeness vocabulary.
- The step happens along what is, metaphorically, **one axis of remoteness** that Spanish builds from two real ones:
  - **The time axis** — pushing the verb into the **future** (project rather than assert) or the **past** (frame the wish as belonging to a moment that isn't *now*).
  - **The reality axis** — moving from **indicative → condicional → subjuntivo**, i.e., from "this is so" toward "this is hypothetical / unreal."

Temporal and modal remoteness both stand in for **social and epistemic remoteness.** Distance in time or reality *is* distance in the conversation: it gives the listener room, removes pressure, and hedges the speaker's commitment.

| The blunt center | The step back | What the step buys |
|---|---|---|
| *Quiero una mesa.* | *Quisiera una mesa.* | deference (past + irrealis) |
| *¿Puedes traerme agua?* | *¿Podrías traerme agua?* | a request framed as hypothetical |
| *¿Tienes una grabación?* | *¿No tendrás una grabación?* | conjecture removes the demand |
| *Son las cinco.* | *Serán las cinco.* | "must be" — a guess, not a claim |
| *Viene.* | *Dudo que venga.* | the speaker refuses to assert it |

**Hard point the page must land:** these are **not five unrelated "uses" to memorize.** They are one move — *retreat from the present indicative* — pointed in different directions. The reader should leave able to *derive* each form from the central metaphor.

---

## 2. Section architecture (single long page, anchored nav)

Five content sections. The thesis first, the two conjecture forms as a matched pair, the three courtesy forms as an escalating gradient, and the subjunctive as the capstone (the reality axis in its general form). Each is a `.grammar-card` (or the contrast-row variant per §3). Section order is the teaching order. **Every section header carries its RAE label**, per Daniel's request.

### Section 1 — *El centro y los dos ejes*
The master reframe. Establishes the present indicative as the center, introduces the time axis and the reality axis, and previews the table above as the organizing promise of the page. Heaviest NOTA on the page sits here (NOTA-A).
- **Anchor contrast:** *Quiero* (center) → *Querría* / *Quisiera* (stepped back), held up as the whole page in miniature.

### Section 2 — *El futuro de conjetura (futuro de probabilidad)*
**RAE label:** *futuro de conjetura* / *futuro de probabilidad*. The form that threw Daniel, and the reason it threw him: it does **two different jobs**, and the page splits them cleanly.

- **Job A — conjetura sobre el presente** (the common one): the future expresses a *guess about a current situation*, ≈ English "must be / probably / I wonder."
  - *Serán las cinco.* (It must be five.)
  - *Tendrá unos cuarenta años.* (He's probably about forty.)
  - *¿Dónde estará?* (Where can he be? / I wonder where he is.)
  - In narrative this is everywhere, often voicing a character's inner guessing — **this is the use most likely to have ambushed the reading**, not the request-softener.
- **Job B — atenuar una pregunta o petición** (the inquiry-softener): the future projects an inquiry into "do you happen to…," removing the demand. This is the cornerstone.
  - **Cornerstone (real, from the story):** *¿Tú por casualidad no guardarás una grabación de aquellos tiempos?* — "You wouldn't by any chance have kept a recording from back then, would you?"
  - The softening is **stacked**: *no* + *por casualidad* + future of conjecture. The negation and *por casualidad* pre-concede a "no," so the listener feels no pressure; the future turns the inquiry into a guess rather than a demand.
- **Mechanic-isolating minimal pair (verb held constant):** *¿Tienes una grabación?* → *¿No tendrás una grabación?* Same verb, only the tense moves — this is the teaching pair, kept beside the cornerstone so the reader sees the bare shift before the fully-hedged literary version.
- NOTA-B sits here (the two directions).

> **Accuracy note for the builder:** the original `.md` example switched verbs (*¿Tienes…?* → *¿Guardarás…?*), which hid the mechanic. Keep one verb constant in the *teaching* pair (*tener*), and use the *guardar* sentence as the *authentic* anchor — both, not one or the other.

### Section 3 — *El condicional de conjetura (condicional de probabilidad)*
**RAE label:** *condicional de conjetura* / *condicional de probabilidad*. The **past-tense twin** of Section 2, and the piece that completes the symmetry the `.md`'s "master pattern" only gestured at.
- **Symmetry, stated plainly:** future = a guess about the **present**; conditional = a guess about the **past**.
  - *Serían las cinco cuando llegó.* (It must have been five when he arrived.)
  - *Tendría unos cuarenta años entonces.* (He must have been about forty back then.)
  - *Estaría cansado, por eso no vino.* (He was probably tired — that's why he didn't come.)
- Short section. NOTA-C is one tight paragraph pairing it against Section 2.

### Section 4 — *Las tres cortesías: quería · querría · quisiera*
The page's centerpiece. Three distinct RAE-labeled forms that all soften a request by stepping back — presented **as one escalating gradient** so the reader feels the deference increase rather than memorizing three rules.

- **4a — *imperfecto de cortesía* (de modestia).** Push a present wish into the past so it stops pressing on *now*.
  - *Quería pedirte un favor.* (I wanted to ask you a favor.)
  - *¿Qué deseaba?* — the service-counter classic ("What would you like?").
  - *Venía a preguntarte si…* (I was coming to ask you whether…)
- **4b — *condicional de cortesía*.** Frame the request as hypothetical — what the listener *would* do in an imagined scenario.
  - *¿Podría traerme agua?* (Could you bring me water?)
  - *Querría pedirle un favor.* / *Desearía hablar con el gerente.*
- **4c — *imperfecto de subjuntivo de cortesía*.** Past **and** irrealis at once — maximum deference. Lexicalized on a small set: *quisiera*, *pudiera*, *debiera*.
  - *Quisiera una mesa para dos.* (I would like a table for two.)
  - *¿Pudiera usted ayudarme?* / *Debiera usted descansar.*
- **Featured device — the deference gradient** (see §3): one request shown at four distances, baseline included:
  *Quiero una mesa* → *Quería una mesa* → *Querría una mesa* → *Quisiera una mesa*
  (direct → softened → hypothetical → deferential). The same sentence, escalating; the whole section's payoff in one row.
- NOTA-D explains the gradient (ordering, register, overlap, regional notes).

### Section 5 — *El subjuntivo: el eje de la irrealidad*
**RAE frame:** the **subjuntivo** as the grammatical pole of *irrealidad*. Included **for completeness, not exhaustively** — per Daniel, repetition with the future Subjunctive hub is welcome, and this page benefits from naming the reality axis in full. Cross-links to the Subjunctive hub for the deep treatment.
- The reframe: the courtesy forms in Sections 2–4 are **lexicalized corners of this same irrealis logic.** The subjunctive is the general engine; *quisiera* and friends are where the engine has frozen into set polite formulas.
- **Anchor contrast (reality vs. unreality):**
  - *Es seguro que **viene**.* (indicative — asserted fact) / *Dudo que **venga**.* (subjunctive — the speaker won't assert it).
  - *Sé que **está** aquí.* / *No creo que **esté** aquí.*
  - *Es verdad que **lo sabe**.* / *Espero que **lo sepa**.* (emotion/desire, not assertion).
- The point the section makes — and then hands off: the subjunctive distances from **objective reality** (doubt, emotion, desire, the unreal), exactly as the tense-shifts distance from the **immediate present**. Same retreat, the other axis.
- NOTA-E is the capstone: names the two axes together, ties all five sections back to the one metaphor, and points to the Subjunctive hub. Explicitly **does not** attempt the full subjunctive trigger inventory.

---

## 3. Core visual device — the *Directo | Distanciado* contrast row

The page is built from minimal pairs, so the repeating unit is a **two-column contrast row: Directo (present indicative) | Distanciado (the stepped-back form), with a meaning-delta line beneath.** This mirrors the source `.md`'s own Direct/Distanced layout and is the natural pedagogy.

Build it on the **existing `.decision-row` pattern** from the scaffold (two cells + center arrow on desktop, stacked with a left-accent border on mobile) — **no new CSS architecture**, just relabeled columns (Directo / Distanciado) and the delta line. Each side carries its own Spanish example (DM Serif Display) + short English `.example-en` gloss + 🔊 button, per scaffold.

**One bespoke element — the deference gradient (Section 4):** a single horizontal four-step row (*Quiero → Quería → Querría → Quisiera*) with increasing visual "distance" left to right (e.g., progressive indent, or a graded accent intensity across the trio variables). This is the one place worth a small custom layout; flagged for sign-off in §9. If it proves fiddly on mobile, fall back to a stacked four-row mini-table — but try the horizontal escalation first, since the *increasing distance* is the point.

---

## 4. NOTA plan (English layer — propose-before-drafting, per scaffold §2.2)

Five NOTAs proposed; prose not yet written, pending Daniel's nod on coverage and placement.

- **NOTA-A · Section 1 — "Two axes, one retreat."** The heaviest block. Lays out the distancing metaphor: temporal remoteness (future/past) and modal remoteness (indicative→condicional→subjuntivo) both stand in for social/epistemic distance. The cognitive-linguistics "remoteness" framing, in plain English. Several paragraphs.
- **NOTA-B · Section 2 — "The future does two jobs."** *The note that answers what threw Daniel.* Why one form covers both *guess about the present* (*Serán las cinco*) and *softened inquiry* (*¿No tendrás…?*), and how to tell which is in play from context. Unpacks the cornerstone's stacked hedge (*no* + *por casualidad* + future) explicitly. ~2 paragraphs.
- **NOTA-C · Section 3 — future ↔ conditional symmetry** (short): present-guess vs. past-guess, stated as a clean matched pair.
- **NOTA-D · Section 4 — the *quería / querría / quisiera* gradient** (medium): the deference ordering (most casual → most deferential), the substantial overlap (all three render "I'd like"), and register/regional notes — *quería* is the everyday default at counters; *quisiera* reads more formal/written; the imperfect-of-courtesy is pan-Hispanic and not regionally marked.
- **NOTA-E · Section 5 — the two-axis capstone** (medium): names the time axis and the reality axis together, frames the courtesy forms as lexicalized borrowings from the subjunctive's irrealis logic, and hands off to the Subjunctive hub for the full mood treatment. States plainly that this page is the *distance* story, not the *complete subjunctive* story.

---

## 5. Cross-linking (per Daniel — repetition is welcome)

- **Subjunctive hub (Tier 1 roadmap):** Section 5 and NOTA-E link forward to it. This page gives a self-contained *completeness* pass on the subjunctive as the reality axis; the hub owns the exhaustive trigger inventory. Daniel has explicitly said overlapping treatments are fine — they reinforce, and the angle here (subjunctive *as distance*) differs from a standard trigger-list approach, so the repetition earns its place.
- **Optional back-links** from `desde-hace-y-construcciones-de-tiempo.html` (shares the "tense as more than time" theme) — flagged as a nice-to-have, not required for v1.

---

## 6. Rioplatense policy (per scaffold)

Grammar and all core examples in **neutral Latin American Spanish**, **neutral-voice TTS only** (no dual-voice JS). All address forms use *tú* / *usted* — **no voseo** anywhere (no *querés*, no *vos*). The cornerstone sentence's *tú por casualidad* is neutral and stays as-is. If any regionally-flavored example is ever added, it gets `data-region` flagging and stays out of the spine, per prior pages — but none is currently planned.

---

## 7. Accuracy ledger (corrections folded in from the source `.md`)

For the builder — what changed from Gemini's draft and why:

1. **Section 1 of the `.md` (future) is split into two jobs** (conjecture-about-present vs. inquiry-softener). The draft conflated them; the present-conjecture use is almost certainly what disrupted Daniel's reading, and it deserves top billing.
2. **The verb is held constant in the teaching pair** (*tener*: *¿Tienes? → ¿No tendrás?*). The draft's *¿Tienes? → ¿Guardarás?* switched verbs and hid the mechanic. The *guardar* sentence survives as the authentic anchor, not as the mechanic demo.
3. **The conditional of probability is added** (Section 3) — absent from the draft, and the piece that actually completes the draft's own "same axis" claim.
4. **The three courtesy forms are unified into a gradient** rather than three parallel sections, with the *quería/querría/quisiera* escalation as the visual payoff.
5. **RAE labels are attached to every section** (*futuro de conjetura*, *condicional de conjetura*, *imperfecto de cortesía*, *condicional de cortesía*, *imperfecto de subjuntivo de cortesía*), so the page reads as a real reference rather than a coined-term explainer. "Psychological distancing" remains the umbrella hook for the NOTA layer only.
6. **The subjunctive section is reframed** from "a fifth politeness device" to "the general irrealis engine the courtesy forms borrow from" — and explicitly scoped to completeness, with the hub owning depth.

---

## 8. Shelved — explicitly NOT in this build

- **Quizzes / drills** of any kind (conjecture-vs-courtesy recognition, gradient-ordering, etc.).
- Any **API-backed** feature — this is a static single-topic page; no `/api/claude`.
- **The exhaustive subjunctive trigger inventory** — that is the Subjunctive hub's job. Section 5 names the axis and stops.
- **Optative / desiderative "ojalá," concessive "aunque," and the full conditional-sentence (si-clause) system** — adjacent irrealis territory, but out of scope here to keep the page on the *distance* thesis. Candidates for their own pages later.

---

## 9. Decisions to confirm before build

1. **Title / slug.** "Psychological distancing" is the English NOTA hook, but the Spanish page title needs a real label. There's no single RAE term for the whole phenomenon; the umbrella candidates are *atenuación* (the recognized pragmatics term for hedging) and *conjetura*. Proposed titles — pick or counter:
   - *La distancia en el verbo: conjetura y cortesía*
   - *Atenuación y conjetura: alejarse del presente*
   - *Tiempo y modo a distancia*
   Slug follows the choice (proposed default: `distancia-y-atenuacion.html`).
2. **Section count.** Ship the **five-section** structure (thesis · futuro de conjetura · condicional de conjetura · las tres cortesías · subjuntivo), or split "las tres cortesías" back into three separate sections to mirror the source `.md` 1:1? (Recommendation: keep the gradient merge — the escalation *is* the lesson.)
3. **Deference gradient device** (§3) — approve the bespoke horizontal four-step *Quiero → Quería → Querría → Quisiera* row, or keep everything on the plain `.decision-row` pattern?
4. **Subjunctive depth** — confirm "completeness, not exhaustive + cross-link to the hub" is the right scope, versus a fuller in-page treatment.
5. **Background pattern + accent trio** — pick from the scaffold options, or have the builder propose a pairing that reads distinct from Ser/Estar, Condicionales, and Desde-Hace?
6. **Anchored section nav** — five sections is borderline for in-page jump links. In, or keep a clean scroll like the shorter single-topic pages?
7. **Images** — recommendation: **none** for v1; the topic is carried by contrast pairs and the gradient. One candidate worth Daniel's call: a small schematic of the **target / two-axis** model from Section 1 (center = present indicative, arrows stepping outward along time and reality). Include as a single SVG-style figure, or ship text-only and add later?

---

## 10. Scaffold inheritance checklist (nothing re-specified here)

Taken verbatim from `single-topic-page-spec.md`: one self-contained HTML file, inline CSS/JS, no frameworks, no API; DM Serif Display + Outfit; navy palette + one accent trio; favicon block; `← Volver al menú` → `../index.html`; Spanish-primary chrome with English NOTA layer; one rate bar near top; neutral-voice TTS (no voseo, no `es-AR`/`es-UY`); 600px responsive breakpoint; emoji policy (🔊 ⚡ ✕ only); full self-check before delivery.

<!-- ─── end verbatim ─── -->

---

## poder — Verbos en Profundidad — poder

> Moved verbatim from `verbos-en-profundidad-poder-spec.md` on 2026-08-23. Hub and the tener precedent both exist; no dependencies left.

<!-- ─── begin verbatim ─── -->

# Mi Proyecto Español — Spec: *poder* (Verbos en Profundidad)

**Type:** Single-verb deep dive — child of the **Verbos en Profundidad** hub.
**Location:** `topics/subpages/verbos-en-profundidad-poder.html`
**Back-nav:** `← Volver a Verbos en Profundidad` → `../verbos-en-profundidad.html`
**Asset paths:** `../../assets/…`
**Scaffold authority:** inherits `single-topic-page-spec.md` in full (fonts, palette, favicon, back-nav, NOTA\* layer, neutral-only TTS, rate bar, accent trio, one background pattern, emoji policy, responsive rules, self-check). This document specifies *only* what is unique to *poder*: the spine, the section architecture, the contrast devices, the NOTA plan, and the reviewable example sets.
**Status:** DRAFT for sign-off. **Review the Spanish here first** (glosses, examples, chips). No HTML until the decisions in §8 are locked.

> **Dependency:** assumes the **Verbos en Profundidad hub** (`topics/verbos-en-profundidad.html`) exists. If it doesn't yet, *poder* either waits on the hub or ships alongside it + a hub `.subpage-links` card. Flag which at sign-off.

---

## 1. Thesis (the spine of the whole page)

Most verbs in the deep-dive library fan out across prepositions. *poder* does not. Its apparent scatter — *can*, *may*, *might*, *to prevail*, *to cope*, plus the noun *el poder* — all radiate from **one idea: *potencia* — latent force or capacity.** The page's job is to make the reader *derive* every use from that single notion, so they stop filing *poder* under unrelated English words.

**One engine: *poder* = tener la fuerza o la capacidad para algo.** What changes is the **target** the capacity is aimed at:

| The capacity is aimed at… | …and *poder* surfaces as | Example |
|---|---|---|
| an **action** | the **modal/auxiliary** (+ infinitivo): ability · permission · possibility | *Puedo nadar.* |
| an **adversary or a load** | a **full lexical verb**: to prevail over / to cope with | *La curiosidad **pudo más que** el miedo.* |
| a **named thing** | the **noun** *el poder*: power, authority, faculty | *Tomó **el poder**.* |

That is the reframe the page opens with and keeps pointing back to. The modal isn't "the real *poder*" with the rest as exceptions — they're the same force pointed at different objects.

**The B2 payoff** rides on top of the engine: in the past, *poder* changes meaning by **tense, not by word** — *pude* (managed to, and did) vs. *podía* (had the ability, outcome open). This is the *poder* analogue of the "permanent vs. temporary" trap the *ser/estar* page kills: learners reach for the wrong past tense and lose the meaning. It gets its own section.

---

## 2. Section architecture (single long page, anchored nav)

Six content sections. Engine first; the user's sentence (*pudo más que*) lands in Section 4 but is *previewed* in Section 1 as a teaser of the lexical target. Idioms close.

Each section is a `.grammar-card`; Sections 3 carries the contrast device (§3 below). Numbering ①–⑥.

### ① El motor: una sola potencia, varios blancos
The master reframe. Establishes *potencia/capacidad* as the single idea and the three targets table above. Heaviest NOTA on the page sits here (**NOTA-A**). Previews *pudo más que el miedo* as the hook ("you already met the lexical face").

### ② Como auxiliar: *poder* + infinitivo
The high-frequency modal use, split into the three senses English scatters:
- **Capacidad** — *can / to be able to*
- **Permiso** — *may / can*; the impersonal **se puede** for rules
- **Posibilidad** — *might / may*; **puede que** + subjuntivo; **puede ser** = "maybe"

Politeness rider: the conditional softener *¿podrías…?* / *¿podría…?* (**NOTA-B**, short).

### ③ El contraste de los tiempos: *pude* vs. *podía*
The tense engine — the section that earns the page its B2 stripes. Built as the **contrast device** (§3). Carries **NOTA-C** (the heaviest grammar NOTA after A). This is where *pudo más que* gets its preterite reading explained: a one-time victory that actually happened.

### ④ Como verbo pleno: *poder con*, *poder más que*, *no poder más*
The lexical family — where the user's sentence lives.
- **poder más que (algo/alguien)** — to win out over, prove stronger than
- **poder con (algo/alguien)** — to cope with, handle, manage
- **no poder más** — to be at one's limit, be exhausted

### ⑤ El sustantivo: *el poder*
The nominalization, by sense:
- **Poder / autoridad** — *el poder político*, *tomar / estar en el poder*, *los poderes del Estado*
- **Facultad / capacidad** — *poderes mágicos*, *poder de convocatoria*
- **Jurídico** — *poder (notarial)* = power of attorney; *dar poder a alguien* (**NOTA-D**, register footnote)

### ⑥ Expresiones idiomáticas
Capstone. The fixed expressions, glossed.

**Conjugation:** a compact irregularity block (o→ue present; strong unaccented preterite *pude/pudo*; future/conditional stem *podr-*; gerundio *pudiendo*). Placement is an open decision (§8) — leaning toward a small table inside ① rather than a standalone card.

---

## 3. The contrast device — Section ③

Reuse the `ser/estar` contrast-row pattern (two-column, color-split), repurposed for the past-tense axis. Three contrast rows:

| Preterito (`pude`) | Imperfecto (`podía`) |
|---|---|
| *Pude abrir la puerta.* → I got it open (and did). | *De niño podía abrir esa puerta yo solo.* → I was able to (general ability). |
| *No pude terminar a tiempo.* → I failed to (didn't happen). | *Antes no podía concentrarme con ruido.* → I wasn't able to (ongoing state). |
| *Al fin pudo decir la verdad.* → managed, at last. | *Sabía que podía decir la verdad cuando quisiera.* → had the standing ability. |

**NOTA-C** carries the rule in English: preterite = *managed to / succeeded* (event realized; negated = *failed to*); imperfect = *had the ability*, silent on whether it happened. Tie it back to *pudo más que el miedo*: preterite ⇒ in that moment, curiosity actually won.

---

## 4. NOTA\* plan (English layer — propose, don't unilaterally insert)

| ID | Section | Scope | Covers |
|---|---|---|---|
| **NOTA-A** | ① | Substantial (multi-paragraph) | The one-engine reframe: *potencia* → three targets. The mental model that unifies modal, lexical, and noun. |
| **NOTA-B** | ② | Short (1–2 sentences) | Conditional as politeness softener; *puede que* requires the subjunctive even though English uses indicative ("he may come"). |
| **NOTA-C** | ③ | Substantial | The *pude/podía* mechanic — the core B2 grammar point. The contrast device pays this off. |
| **NOTA-D** | ⑤ | Short, register footnote | *poder* (noun) is a false-friend trap for *power* in the electrical/energy sense — that's *la energía / la corriente*, not *el poder*. Legal *poder notarial* glossed. |

NOTA scope/placement is itself a §8 decision — confirm before prose is drafted.

---

## 5. Reviewable example sets (vet the Spanish here)

All neutral Latin American — no voseo, no *vosotros*. Spoken line is the Spanish only. Format mirrors the *rotura* draft: **ES** 🔊 — *EN gloss*.

### ② Modal — capacidad
- **Puedo nadar.** — *I can swim.*
- **El paciente no puede caminar todavía.** — *The patient can't walk yet.*
- **¿Puedes ayudarme con esto?** — *Can you help me with this?*

### ② Modal — permiso (+ impersonal *se puede*)
- **¿Puedo pasar?** — *May I come in?*
- **Aquí no se puede fumar.** — *You can't smoke here.*
- **Ya pueden salir.** — *You may go now.*

### ② Modal — posibilidad
- **Puede llover esta tarde.** — *It might rain this afternoon.*
- **Puede que venga mañana.** — *He may come tomorrow.* *(venga = subjuntivo)*
- **—¿Estará en casa? —Puede ser.** — *"Is he home?" "Maybe."*

### ② Cortesía (condicional)
- **¿Podrías pasarme la sal?** — *Could you pass me the salt?*
- **¿Podría hablar con el doctor?** — *Could I speak with the doctor?*

### ③ Contraste *pude / podía*
- **Pude abrir la puerta.** — *I managed to open the door.* *(and did)*
- **No pude abrir la puerta.** — *I couldn't open the door.* *(and didn't)*
- **De niño podía tocar de oído.** — *As a child I could play by ear.* *(had the ability)*
- **Ayer pude terminar el informe.** — *Yesterday I managed to finish the report.*
- **Cuando era joven podía correr maratones.** — *When I was young I could run marathons.*

### ④ Léxico — *poder más que*
- **La curiosidad pudo más que el miedo.** — *Curiosity won out over fear.* *(the sentence that started this)*
- **Al final, el cansancio pudo más que él.** — *In the end, exhaustion got the better of him.*
- **Las ganas de verla pudieron más que la lógica.** — *The urge to see her overcame logic.*

### ④ Léxico — *poder con*
- **No puedo con tanto trabajo.** — *I can't cope with so much work.*
- **¿Puedes con la maleta?** — *Can you manage the suitcase?*
- **Ese niño puede con todo.** — *That kid can handle anything.*

### ④ Léxico — *no poder más*
- **No puedo más.** — *I can't take it anymore.*
- **Ya no podía más del cansancio.** — *I couldn't go on from exhaustion.*
- **Comí tanto que no puedo más.** — *I ate so much I can't manage another bite.*

### ⑤ Sustantivo — poder / autoridad
- **El poder político corrompe.** — *Political power corrupts.*
- **El general tomó el poder.** — *The general seized power.*
- **El partido lleva diez años en el poder.** — *The party has been in power for ten years.*
- **Los tres poderes del Estado.** — *The three branches of government.*

### ⑤ Sustantivo — facultad / capacidad
- **Dicen que tiene poderes.** — *They say she has powers.*
- **El orador tiene un gran poder de convocatoria.** — *The speaker has great drawing power.*

### ⑤ Sustantivo — jurídico
- **Le dio un poder notarial a su hija.** — *He gave his daughter power of attorney.*
- **Firmó un poder para vender la casa.** — *He signed a power of attorney to sell the house.*

### ⑥ Idiomáticas
- **Trabajaron a más no poder.** — *They worked flat out.*
- **Es amable a más no poder.** — *He's as nice as can be.*
- **No puedo con mi alma.** — *I'm dead on my feet.*
- **Querer es poder.** — *Where there's a will, there's a way.*
- **No lo puedo ver ni en pintura.** — *I can't stand the sight of him.*
- **¿Se puede saber qué estás haciendo?** — *Would you mind telling me what you're doing?*

### Conjugation reference (irregular)
- **Presente (o→ue):** puedo · puedes · puede · podemos · pueden
- **Pretérito (fuerte, sin tilde):** pude · pudiste · pudo · pudimos · pudieron
- **Futuro / condicional (raíz *podr-*):** podré · podría
- **Gerundio:** pudiendo · **Participio:** podido

---

## 6. Identity & tokens (proposed — confirm)

| Field | Value |
|---|---|
| Page title (h1) | options: **"*Poder*: una palabra, mucha fuerza"** · **"*Poder*: del modal al sustantivo"** · **"Las fuerzas de *poder*"** — pick one |
| Overline | `Verbos en Profundidad` |
| Ornament | `◆` (or match the hub's chosen ornament) |
| File | `topics/subpages/verbos-en-profundidad-poder.html` |
| Accent trio | one approved trio from `single-topic-page-spec.md` §14 — pick at assembly, show before locking |
| Background | one of the 5 SVG patterns, non-recently-used; shown at assembly |
| TTS | **neutral-only** |
| Modals | `⚡ Guía Rápida` cheat sheet — strong candidate (see §8). No `⚠ Parecidos` needed. |
| Bottom section | optional `Repaso` matching quiz (inline, static) — §8 decision |

---

## 7. Region / register chips

*poder* is pan-Hispanic and neutral throughout — expect **no region chips** on the core examples. Reserve `reg-*` chips only if a sense turns out regionally marked during the Spanish review (none flagged so far). Register chips (`formal` / `técnico` / `poco frecuente`) only on the legal *poder notarial* line if warranted.

---

## 8. Open decisions — lock before build

1. **Page title** — pick from the three proposals in §6 (or counter).
2. **Spine framing** — does *"una sola potencia, varios blancos"* land, or do you want a different organizing image for NOTA-A?
3. **Section count/order** — confirm the six-section sequence, idioms last.
4. **Conjugation block** — compact table inside ① vs. its own small card vs. NOTA prose. Leaning table-in-①.
5. **Guía Rápida modal** — include? Proposed contents: the three-target table + the *pude/podía* one-liner + the lexical trio + top idioms. Yes/no.
6. **Repaso quiz** — include a short static matching quiz at the bottom, or keep the page reference-only?
7. **Accent trio + background** — pick now or defer to assembly (I'll show options either way).
8. **Hub dependency** — does `verbos-en-profundidad.html` already exist, or does *poder* ship with it?

---

## 9. Out of scope / shelved

- **Subjunctive mechanics behind *puede que*** — gloss only; the full treatment belongs to the planned Subjunctive hub. Link out rather than teach here.
- **Pronominal *poderse*** (*"no se puede con él"*) — fold into *poder con* as a one-line note, not its own beat; it's marginal.
- **The electrical/energy false friend** — handled in a single NOTA-D sentence, not a section.

---

*End of spec. Once approved and built, remove this file from the project folder (one file per concern).*

<!-- ─── end verbatim ─── -->

---

## adverbios-adds — Adverbios — three gaps + two fixes

> Moved verbatim from `adverbios-page-additions-spec.md` on 2026-08-23. Expansion of the live 66K topics/adverbios.html, not a new page.

<!-- ─── begin verbatim ─── -->

# Adverbios Page — Planned Additions
### Created: July 2026
### Status: SPEC — content not yet drafted
### Target file: `topics/adverbios.html`

---

## Summary

The adverbios page covers *-mente* formation and fixed locuciones adverbiales organized by preposition. Three structural gaps were identified in the **formation** story, plus two smaller fixes to existing content.

---

## 1. New Card — Adjetivos adverbializados (bare adjective as adverb)

**What it is:** Adjectives used in bare masculine singular form to modify a verb, replacing *-mente*. The most informal/spoken strategy for forming manner adverbs.

**Key grammar point:** The adjective does NOT agree with the subject — it freezes in masculine singular. *Ella habla claro*, not *clara*. This invariability is what marks it as adverbial rather than predicative.

**NOTA point (English):** The agreement boundary is blurry. Some adjectives shade back toward predicative when speakers make them agree (*ella vive tranquila* = she lives [in a state of being] calm, vs. *ella vive tranquilamente* = she lives calmly). With *fijo, duro, claro, rápido, limpio*, the invariable adverbial reading is dominant and unambiguous. Test: if it agrees with the subject, it's predicative; if it doesn't, it's adverbial.

**Core examples (cluster around physical actions and speech):**

| Bare adjective | Meaning | -mente equivalent |
|---|---|---|
| hablar claro | to speak clearly | claramente |
| hablar alto / bajo | to speak loudly / softly | — (en voz alta / baja) |
| hablar fuerte | to speak loudly | fuertemente |
| mirar fijo | to stare fixedly | fijamente |
| trabajar duro | to work hard | duramente |
| jugar limpio / sucio | to play fair / dirty | limpiamente (rare) |
| pisar firme | to step firmly | firmemente |
| respirar hondo / profundo | to breathe deeply | profundamente |
| pensar rápido | to think fast | rápidamente |
| caminar lento | to walk slowly | lentamente |
| cortar fino | to cut thin | finamente |
| pegar fuerte | to hit hard | fuertemente |
| cantar bonito | to sing beautifully | — (bonitamente virtually unused) |

**Register:** Most informal — spoken Spanish's favorite shortcut. In formal writing, switch to *fijamente* or *de manera fija*.

**Placement on page:** New Card 3, immediately after current Card 2 ("Por qué los hablantes los evitan"). It's the most radical simplification of *-mente*, so it makes sense as the first alternative strategy shown.

**Triggered by:** Reading *mirando fijo* in a Comprensión Lectora story.

---

## 2. New Card — *De manera / de forma / de modo* + adjective

**What it is:** A productive template that can replace virtually any *-mente* adverb. Three interchangeable heads:

- *de manera* + adjective (most common in general writing)
- *de forma* + adjective (equally common, slightly more technical)
- *de modo* + adjective (a bit more formal/literary)

The adjective agrees with the noun: *de manera clara* (fem), *de modo claro* (masc).

**Key grammar point:** Unlike the fixed locuciones in the *de* card (Card 4 → renumbered to Card 6), this is a **live generative template** — you can apply it to almost any adjective. It's not a list to memorize; it's a machine for building adverbs.

**NOTA points (English):**
- This is the middle register — more polished than bare adjective, less heavy than *-mente*. Very common in journalism, narrative prose, professional communication.
- Cross-reference to false friends card: *de forma interesante* is the correct "interestingly" that avoids the *interesadamente* trap from Card 8 (renumbered to Card 10).

**Core examples:**

| Template phrase | Meaning | -mente equivalent |
|---|---|---|
| de manera clara / de forma clara | clearly | claramente |
| de manera directa | directly | directamente |
| de manera inmediata | immediately | inmediatamente |
| de forma gradual | gradually | gradualmente |
| de modo eficaz | effectively | eficazmente |
| de forma simultánea | simultaneously | simultáneamente |
| de manera voluntaria | voluntarily | voluntariamente |
| de forma interesante | interestingly | — (interesadamente = self-interestedly) |

**Register:** Written/polished — journalism, academic, narrative prose. Avoids *-mente* bulk while maintaining precision.

**Placement on page:** New Card 4, after the bare-adjective card. Teaching arc: Card 1 (*-mente* formation) → Card 2 (why speakers avoid it) → Card 3 (most casual alternative: bare adjective) → Card 4 (middle-register alternative: *de manera/forma/modo*) → Cards 5+ (fixed locuciones catalog).

**Triggered by:** Reading *de manera inmediata* in a Comprensión Lectora story. Page had *de inmediato* but not this construction.

---

## 3. New Card — Placement rules (where adverbs go in the sentence)

**What it is:** The page's subtitle says "formación y registro" and the index categorization spec lists the adverbios grammar bucket as "formation (-mente), placement" — but placement is never explicitly taught. The page shows correct placement through examples but never states the rules.

**Why it matters for B2:** English adverb placement is much more flexible. Default English instinct will put manner adverbs in wrong positions.

**Core rules (compact — one card or large NOTA):**

1. **Manner adverbs follow the verb.** *Habla claramente*, not *claramente habla* (fronting is possible for emphasis but marked/literary).
2. **Sentence adverbs lead the clause + comma.** *Por suerte, llegamos a tiempo.* / *En realidad, no me molesta.*
3. **Locución vs. -mente doesn't change placement.** *Con cuidado* goes in the same slot as *cuidadosamente*.
4. **Compound tenses: adverb goes after the participle, not between auxiliary and participle.** *Ha trabajado duramente*, not *ha duramente trabajado*.

**Placement on page:** Final card before the decision guide — "now that you know how to form them, here's where they go."

---

## 4. Small Fix — *Sin* entries added to existing *con* card

**What it is:** The *con* card teaches *con cuidado, con rapidez, con calma* but never mentions that *sin + noun* is the natural negation and produces equally common adverbial phrases.

**Not a new card** — fold 3–4 *sin* entries into the existing *con* card as a "y su reverso" mini-table or small addition to the table.

**Entries to add:**

| Locución | Meaning | -mente equivalent |
|---|---|---|
| sin duda | undoubtedly | indudablemente |
| sin querer | unintentionally | involuntariamente |
| sin parar | nonstop | incesantemente (rare) |
| sin embargo | however | — (sentence adverb, no -mente) |

**Note:** *sin embargo* is included because it's a *sin* locución, but it's a sentence adverb / connective, not a manner adverb. Could note this distinction or omit it to keep scope tight. It also appears on the conectores page (when built).

---

## 5. Small Fix — *-mente*-only adverbs acknowledged in decision guide

**What it is:** The decision guide has a row for "no *-mente* form exists → locución obligatoria" but never states the reverse: some adverbs have **no natural locución** and *-mente* is the only option regardless of register.

**Examples:** *probablemente, obviamente, sinceramente, precisamente, básicamente, personalmente*. These are mostly sentence-level modifiers, not manner adverbs — which is why they don't fit locución templates.

**Implementation:** A new row in the decision guide or a NOTA. Closes the loop — the page currently risks implying every *-mente* adverb has a lighter alternative.

---

## Revised Card Numbering (after additions)

| # | Topic | Status |
|---|---|---|
| ① | La formación en *-mente* | Existing (unchanged) |
| ② | Por qué los hablantes los evitan | Existing (unchanged) |
| ③ | **Adjetivos adverbializados** | **NEW** |
| ④ | ***De manera / de forma / de modo* + adj** | **NEW** |
| ⑤ | *con* + sustantivo (+ *sin* addition) | Existing (was ③, *sin* entries added) |
| ⑥ | *de* + sustantivo | Existing (was ④) |
| ⑦ | *en* + sustantivo | Existing (was ⑤) |
| ⑧ | *por* + sustantivo | Existing (was ⑥) |
| ⑨ | *a* + sustantivo / adjetivo | Existing (was ⑦) |
| ⑩ | Falsos amigos en *-mente* | Existing (was ⑧, add *de forma interesante* cross-ref) |
| ⑪ | Variación regional | Existing (was ⑨) |
| ⑫ | **Placement rules** | **NEW** |
| — | Decision guide | Existing (add *-mente*-only row) |

---

## Register Gradient (the teaching thesis, updated)

The completed page should establish a four-tier register gradient for manner adverbs:

1. **Bare adjective** (*habla claro*) — most informal, spoken
2. **Fixed locución** (*con cuidado, de repente, a ciegas*) — spoken/everyday, sometimes the only option
3. ***De manera/forma/modo + adj*** (*de manera clara*) — written, polished, middle register
4. ***-mente*** (*claramente*) — formal, technical, legal

---

## Out of Scope

These were considered and explicitly excluded from this page:

- **Degree adverbs** (*medio, bastante, demasiado*) — different topic
- **Comparative adverb forms** — different topic
- **Gerund as manner modifier** (*salió corriendo*) — separate construction, would belong on a gerundio page
- **Adverbs of place/time** — this page is scoped to adverbs of manner and sentence adverbs

<!-- ─── end verbatim ─── -->

---

## pronunciacion — Pronunciation app (Azure Speech)

> Moved verbatim from `pronunciacion-app-spec.md` on 2026-08-23. Back-burnered by Daniel 2026-08-23. Six phases, external API, new serverless function — a multi-session build whenever it is picked up.

<!-- ─── begin verbatim ─── -->

# Pronunciación — App Spec

**Status:** Committed spec. Build in phases, one observable change per deploy, each phase tested before the next.
**Page (interactive):** `interactive/pronunciacion.html` (working name)
**Storage:** Google Drive (per-word records) + device `localStorage` (Sin Ver pools)
**Pronunciation scoring:** Azure Speech — Pronunciation Assessment, via Netlify token function
**Dialect:** Neutral Latin American Spanish throughout (no Spain *distinción*, no voseo). Azure locale `es-MX`; TTS neutral fallback chain excluding `es-AR`/`es-UY`/`es-ES`.

---

## 1. Purpose

A pronunciation drill, not a vocabulary tool. The English definition is always visible from the moment a word appears — hiding the word would defeat the point. There are two modes: **Review** (silent practice, no API) and **Test** (mic + Azure scoring). Words carry a color tag (red/yellow/green) that evolves as you test, plus a fixed subjective difficulty tag set by you.

---

## 2. Data model

### 2.1 Per-word record (Google Drive, persistent)

| Field | Type | Owner | Notes |
|---|---|---|---|
| `id` | string | system | Stable unique ID. Keys Drive updates and Sin Ver seen-sets. |
| `word` | string | **you edit** | Spanish word, e.g. `organización` |
| `definition` | string | **you edit** | English, e.g. `(the) organization` |
| `phonetic` | string | **you edit** | Custom respelling, e.g. `ohr-gah-nee-sah-SYOHN` |
| `difficulty` | `"hard"` \| `"less-hard"` | **you edit** | Your subjective tier. Set at build, editable. Never changes by testing. |
| `colorTag` | `"red"` \| `"yellow"` \| `"green"` | system | **All words start `red`.** Evolves via the ladder (§5). |
| `lastScore` | ScoreObject \| null | system | Most recent test run. |
| `bestScore` | ScoreObject \| null | system | Highest `accuracyScore` ever. |

**You edit:** `word`, `definition`, `phonetic`, `difficulty`.
**System manages:** `colorTag`, `lastScore`, `bestScore`.

**ScoreObject** (all relevant Azure data stored, even though display headline is one number):

```json
{
  "accuracyScore": 88,
  "recognizedText": "perro",
  "matched": true,
  "phonemes": [
    { "phoneme": "p",  "score": 95 },
    { "phoneme": "e",  "score": 90 },
    { "phoneme": "r",  "score": 62 },
    { "phoneme": "o",  "score": 93 }
  ],
  "fluencyScore": 100,
  "completenessScore": 100,
  "timestamp": "2026-06-05T00:00:00Z"
}
```

`fluency`/`completeness` are stored for completeness but **not used for scoring** — they are degenerate for single words. The headline metric is `accuracyScore`.

### 2.2 Local (device `localStorage`)

**Sin Ver seen-sets — five pools**, one per mutually-exclusive filter:
`HARD`, `LESS-HARD`, `YELLOW`, `RED`, `TODOS`.

- Each pool stores a set of word `id`s marked *seen*.
- **Shared across Review and Test** — seeing a word in Review marks it seen for Test, until that pool resets.
- Pools cycle independently: a word seen in a RED run is marked seen only in the RED pool, not in TODOS/HARD/etc.

---

## 3. The two modes

### 3.1 Review mode

- **No password, no API, no mic.**
- On each word, shown immediately and all functional: `word`, `phonetic`, **speaker button** (neutral TTS), `definition`, `difficulty` tag, `colorTag` badge, and a score box showing **Last / Best** (read from Drive; no Current, since no test happens).
- **Continue** is always active. Hitting it speaks the word (neutral TTS) and advances.
- Sin Ver applies (§7).
- Tags **do not change** in Review.

### 3.2 Test mode

- **Password gated** — same password as Comprensión Lectora.
- **Visible immediately:** `word`, `definition`, `difficulty` tag, `colorTag` badge, **mic badge** (under the word).
- **Hidden / non-functional until answered:** `phonetic`, speaker button, the score box, **Continue** (greyed out).
- After answering: `phonetic` appears, speaker becomes functional, score box appears (**Last / Current / Best**, §6), `colorTag` updates with audio cue (§5–6), Continue activates.
- Continue (once active) speaks the word and advances — same as Review.

---

## 4. Azure integration

### 4.1 Auth & call

- A **Netlify serverless function** mints a short-lived Azure token; the Azure key stays server-side (same secret-handling discipline as `/api/claude`). The browser Speech SDK uses the token. (Google Drive auth is separate — `drive.file`, lazy.)
- **Sent per assessment:** audio (16 kHz mono PCM) + reference text (the target word) + config: `locale: es-MX`, `gradingSystem: HundredMark`, `granularity: Phoneme`, `phonemeAlphabet: IPA`, `EnableMiscue: true`.
- **Used from the response:** `AccuracyScore` (headline), recognized/Display text (lexical gate), per-phoneme `AccuracyScore` array. Fluency/Completeness stored, not scored.

### 4.2 Score → Red / Yellow / Green

1. **Lexical gate first.** If the recognized word ≠ target (case-insensitive; accent-insensitive to avoid false fails) **or** nothing was recognized → **RED**, regardless of the number. This kills false passes like *organizasión* scoring high because it sounds nearly identical to the real word.
2. **If matched, threshold the `accuracyScore`:**
   - ≥ `greenThreshold` → **GREEN**
   - ≥ `yellowThreshold` and below green → **YELLOW**
   - below `yellowThreshold` → **RED**
3. **Thresholds start at 85 / 70 and are tuned in Phase 3** against your own voice — record words you know you say well vs. poorly, slide the cutoffs to match reality. Stored as config constants, easy to change.

### 4.3 Weak-phoneme hint (in from the start)

After answering, show a one-line hint naming the weakest phoneme(s) when one sound sits clearly below the rest — e.g. *Punto débil: la rr.* Neutral Spanish, one line, no clutter. Data comes free in the same response.

---

## 5. Color-tag ladder (state machine)

`red < yellow < green`. **A word never jumps two levels in one test** — hysteresis, so one lucky/unlucky attempt can't swing it the whole way.

- **Green result** → move **up** one step.
- **Red result** → move **down** one step.
- **Yellow result** → move **toward yellow** by one step.

Full table:

| Current tag | Test result | New tag |
|---|---|---|
| GREEN | green | GREEN |
| GREEN | yellow | YELLOW |
| GREEN | red | YELLOW |
| YELLOW | green | GREEN |
| YELLOW | yellow | YELLOW |
| YELLOW | red | RED |
| RED | green | YELLOW |
| RED | yellow | YELLOW |
| RED | red | RED |

All words begin RED; the dataset evolves as you test and improve.

---

## 6. Score display & feedback (Test mode, after answering)

### 6.1 Layout

Three boxes — **Last / Current / Best** — each showing the single `accuracyScore` number and a horizontal 0–100 bar with the score marked. Plus the weak-phoneme line (§4.3).
(Review mode shows **Last / Best** only.)

### 6.2 Raw-score color (Current vs Last) — *separate from the color tag*

- Current **>** Last → **green** box
- Current **<** Last → **red** box
- Current **=** Last → **blue** box
- Current **>** Best (new record) → **GOLD** box (overrides the above)
- First-ever attempt (no Last/Best) → GOLD (it sets the best by default)

### 6.3 Audio cue (color-tag change) — *separate from the box color*

- Tag moved **up** (improved, including to green) → **bright/high** beep.
- Tag **stayed** or **dropped** → **duller/lower** beep.

> Two independent feedback systems: the **box color** is about raw score vs your history; the **beep + badge** is about the R/Y/G ladder.

---

## 7. Sin Ver (seen-tracking) & snapshot

### 7.1 Snapshot at run start

When you hit Start, the app **picks the run's exact word list up front and freezes it.** It does not re-pick or re-shuffle mid-run. Because color-tag changes are written only at the end (§7.3), pool membership is stable for the whole run — no word leaves the RED pool under your feet.

### 7.2 Selection + reset logic (resolved at snapshot)

- Draw unseen words from the selected pool.
- If the pool's unseen words run out before the run is filled, **reset that pool's seen-set** and keep drawing from the full pool.
- Example (Test, RED pool of 30, 25 already seen, 10-question run): first 5 are the unseen words; the pool then resets; the remaining 5 are drawn from the refreshed 30. Resolved deterministically at snapshot time — same result, no live recompute.

### 7.3 Batched write at run end

The app holds all changes in memory during the run and writes to Drive **once** at the end:
- updated `colorTag`s,
- updated `lastScore` (and `bestScore` where beaten),
- seen-marks for the run's words in the active pool.

Fewer Drive writes, stable run, same pattern as the género quiz.

---

## 8. Question-count logic

Counts: **10 / 20 / 30**. Let `A` = words available in the selected pool.

- `A ≥ chosen` → run `chosen`.
- `A < chosen` but `A ≥ 10` → **reject**; popup offers only the counts that fit (`≤ A`), then back to selection.
  - e.g. `A = 25`, chose 30 → "run 10 or 20." `A = 15`, chose 20 → "run 10."
- `A < 10` → popup: *"Tienes N palabras disponibles. ¿Continuar con un set reducido?"*
  - **Yes** → run `A` questions; the **10 button highlights in a distinct "truncated" color** to signal a partial set.
  - **No** → back to selection (pick different filters).

All popups have an exit back to the selection screen.

---

## 9. Front end

- **Top:** Google Drive connect (reuse the existing pattern from Comprensión Lectora / género quiz — `drive.file`, lazy auth).
- **Mode selector:** Review / Test. Test → password prompt (Comprensión Lectora password). Review → no password.
- **Filters** (button style per Entrenador 2), **mutually exclusive**:
  - Difficulty: `HARD`, `LESS-HARD`
  - Color: `YELLOW`, `RED` (no green — you already know those)
  - `TODOS`
- **Count selector:** 10 / 20 / 30.
- **Start** → count-logic validation (§8) → snapshot (§7) → quiz.

### 9.1 Quiz card (layout per the Gemini sketches; colors/exact styling TBD)

- Top-left: color-tag badge (shows the word's current `colorTag`).
- Top-right: progress counter `[n/total]`.
- Center: speaker icon, **WORD** (large), `phonetic` (under word, per visibility rules), mic button (Test only), `definition` (always visible).
- Bottom: score boxes (§6).
- Right: Continue button (greyed in Test until answered).

---

## 10. Mic interaction (Test only)

- Mic badge sits under the word. Tap → **countdown 3, 2, 1**, then a start signal + neutral cue **"Habla"** (not voseo "Hablá").
- **Fixed 3-second capture window** with a visual timer (spinner/hourglass/shrinking bar). Records the full 3 s to completion regardless.
- Stop signal at 3 s, then **"Enviando… espera"** during the API round-trip.
- Results render: `phonetic` shown, speaker active, score boxes, weak-phoneme line, tag update + beep, Continue activates.

---

## 11. Edit / dataset entry (Phase 5 placeholders)

- Placeholder for **single-word entry** (style as on the género / tramposa pages).
- Placeholder **link to a future full-page dataset editor** (built later — out of scope for now).

---

## 12. Dialect rule

Neutral Latin American Spanish everywhere: Spanish-primary UI chrome, neutral TTS (fallback `es-419 → es-MX → es-US → es-CO → other es-*`, excluding `es-AR`/`es-UY`/`es-ES`), Azure locale `es-MX`, countdown cue "Habla." No Spain *distinción*, no voseo, unless explicitly requested.

---

## 13. Phases

| Phase | Scope | Observable result |
|---|---|---|
| **0** | This spec. | Committed. |
| **1** | Shell: Drive connect + mode select + password gate + filter buttons + count-validation popups, against a seed dataset. No quiz, no Azure. | Connect, pick filters, see the validation popups behave. |
| **2** | Review mode end-to-end (no API): card, phonetic, neutral speaker, definition, tags, Continue, Sin Ver snapshot, end stats box. | A full Review run works start to finish. |
| **3** | Azure in isolation: Netlify token function + mic + 3 s capture + single-word assessment → log the JSON. Calibrate thresholds on your voice; verify lexical gate + per-phoneme. | Say a word, see the real scores. Thresholds locked. |
| **4** | Test mode integration: score boxes (Last/Current/Best + bar + weak-phoneme line), raw-score color feedback, tag ladder, audio beeps, batched Drive write of tags + scores + seen. | A full Test run updates Drive once at the end. |
| **5** | Polish + edit/single-entry placeholders + end-stats refinements. | — |
| **6** | (Later) full dataset editor. | — |

---

## 14. End-of-run stats box

At the end of both modes, a popup shows the count of words by tag — **green / yellow / red** — for the filtered set. In Test mode these reflect the tag changes just written; in Review they reflect current tags (unchanged).

---

## 15. Open items & deferred

- **Seed dataset:** initial words need `word` / `definition` / `phonetic` / `difficulty`; all start `red`. Curate before the first live Drive connect becomes the source of truth (same caution as the género quiz).
- **Reusable specs to extract later:** `google-drive-connection-spec.md`, the password-gate pattern, the filter-button style — so future builds reference a file instead of re-deriving.
- **Cleanup (separate from this build):** remove the stale "Prefer es-AR voice" line in `master_briefing.md` (line ~249); clean neutral-tagged entries in `final_master_list.md` that use *vos* in examples (e.g. "te toca a vos" → "te toca a ti").

---

## 16. Locked decisions (settled this session)

1. Single headline metric = Azure **AccuracyScore**; no blended number, no multi-metric bars. Display = the number + a 0–100 bar.
2. **Lexical gate** forces RED on mismatch / no recognition.
3. R/Y/G thresholds **start 85 / 70, tuned in Phase 3** on Daniel's voice.
4. **Weak-phoneme hint included from the start.**
5. Color-tag **one-step ladder** (§5) as tabled.
6. **Snapshot at run start + batched Drive write at run end.**
7. **Shared Sin Ver pool** across Review and Test; five pools total.
8. Mic = **fixed 3-second window** with warning, countdown, start/stop signals.
9. Score-box color (green better / red worse / blue same / gold best) is **separate** from the R/Y/G tag + beep.
10. **Store all relevant Azure data** per word, even though only the headline number is shown.
11. **Neutral Latin American Spanish** is the absolute default (no Spain *distinción*, no voseo).

<!-- ─── end verbatim ─── -->

---

## entrenador-admin — Entrenador de Verbos — data admin

> Moved verbatim from `entrenador-data-admin-spec.md` on 2026-08-23. Phased; agreed in discussion, never built.

<!-- ─── begin verbatim ─── -->

# Entrenador de Verbos II — Data Admin & Dynamic Verb Set
### Specification (v1, discussion-locked)

**Status:** Spec agreed in discussion. No code written yet. Build proceeds in phases, one phase tested before the next begins.

**Purpose:** Let Daniel add, review, and manage new verbs/phrases for Entrenador de Verbos II on the fly — through a front-end form plus an AI generation step — without hand-editing the curated data files, and have those additions sync across all his devices. The large curated corpus stays frozen and untouched.

---

## 1. Architecture: where the data lives

Three separate places, each with one job:

- **Netlify** — hosts the website and the **frozen curated verb files** (`verbos-a-d.js` … `verbos-r-z.js`). Identical on every device, read-only, served to whatever device opens the URL. This is the bulk of the data and it never changes from the browser.
- **Google Drive** — holds **one small mutable JSON file** containing Daniel's new verbs. Lives in the cloud, tied to his Google account, in the existing "Spanish Learning" app folder via `drive.file` OAuth scope. This is the *only* mutable data.
- **The device (PC / iPad / phone)** — runs the app in the browser; stores nothing permanent except device-local statistics. Just a window onto the two data sources above.

**Merge-at-load model.** On page load the trainer reads the frozen arrays from Netlify; on Drive connect it reads the dynamic file from Drive; it concatenates them into one in-memory dataset. After the merge, the app has **no notion of which verb came from where** — frozen and custom verbs behave identically in every quiz mode.

**Cross-device.** Because the mutable file lives in Drive, adding a verb on one device and studying it on another works automatically: log into the same Google account on the second device, the app fetches the latest file, merges, done. (Read-on-open / write-on-save, not live multiplayer sync — single device at a time when *editing*; last-write-wins.)

**Decision — the 700-verb set is NOT moved to Drive.** It is frozen and read-only; Netlify is the correct home for it (fast, no auth, no latency, uncorruptible). Moving it to Drive would add an OAuth dependency and load latency to the core trainer for zero benefit.

---

## 2. Graceful degradation (Drive optional)

- **Drive is optional for studying, required only for saving.** Frozen verbs load from Netlify regardless of Drive state. No login → trainer runs fully on the frozen 701-verb set.
- **Statistics are device-side and Drive-independent.** Missing Drive does not affect stats. A stat that references a custom verb not currently loaded goes *dormant* (skipped, not broken) until Drive reconnects.
- **Lazy connect-prompt.** Studying never prompts. The connect-Drive popup fires only on a *write* action (add / save / commit / edit). This reuses the comprensión-lectora connection UI and `driveRequest()` wrapper verbatim.

---

## 3. Data schema (the "two arrays" reality)

Each frozen file declares **two parallel arrays**. A complete entry spans both. The generation step must produce both.

### 3a. `VERB_PROFILES_xx` — reference profile (one object per verb)
```js
{
  verb: "abrigar",
  irregularity: "pret: g→gu (yo)",      // free-form tag; "regular", "pp: abierto", etc.
  summary: {
    blurb: "…one-paragraph profile…",
    uses: [
      { meaning: "to wrap up, to keep warm",
        example: { spanish: "…", english: "…" },
        register: "everyday" }
      // one entry per sense
    ],
    pronominalNote: null                 // string or null
  }
}
```

### 3b. `VERB_CONTEXTS_xx` — quiz-facing rows (one object per *context/sense*)
```js
{
  verb: "abrazar",
  phrase: "abrazar",
  grammar: "TR",                         // TR, INTR, RECIP, PRNL, … (transitivity/type tag)
  english: "to hug, to embrace",
  register: "everyday",                  // everyday, standard, … (observed; full set extracted at build)
  region: "neutral",                     // neutral, rioplatense, … (drives example dialect)
  notes: "",
  contextExplanation: "…",
  synonyms: [],
  example: { spanish: "…", english: "…" }
}
```

**Note on dialect:** the corpus is region-mixed and tagged per entry (`region`). The example's dialect must match its `region` tag (e.g. voseo for rioplatense, neutral elsewhere). The AI sets `region` and writes the example accordingly.

---

## 4. The dynamic Drive file

A single JSON file storing Daniel's additions as paired fragments, ready to merge into both arrays:

```jsonc
{
  "version": 1,
  "entries": [
    {
      "id": "uid-generated",
      "profile":  { /* VERB_PROFILES shape */ },
      "contexts": [ { /* VERB_CONTEXTS shape */ } ]   // 1+ rows
    }
  ]
}
```

At load: `allProfiles = [...frozenProfiles, ...drive.entries.profile]`, `allContexts = [...frozenContexts, ...drive.entries.contexts]`.

**Adding a context to an existing (frozen) verb** = append a new `contexts` row to the dynamic file. No edit to the frozen verb. (Whether the frozen verb's reference *card* also displays the new sense is a small display question resolved at build, once the trainer's array→mode wiring is read. Quiz behavior is clean either way.)

---

## 5. Functional components

### 5.1 Review / lookup (read-only)
- Type a verb/phrase → popup shows matching entries (frozen + dynamic), one line each: verb · context · register.
- Pure in-memory pattern match. No AI, no Drive needed for the frozen set.
- **Frozen entries: review-only. No edit, no delete.** (The curated 700 stay untouchable.)
- Dynamic entries: clickable → opens edit panel (see 5.4).

### 5.2 New-entry staging
- Form: **verb/phrase** + **desired context(s)** (free text — the context need not be verbatim; the AI interprets and fills all fields).
- Entries are saved to a **staging queue** (in the Drive file or a sibling staging file) so nothing is lost between sessions.

### 5.3 AI generation (the pipeline)
```
Staged entries → [Generate] → one Sonnet call PER entry (client-side loop)
              → results land in PENDING REVIEW (not yet live)
              → Daniel approves → [Commit] → written into the dynamic Drive file
              → trainer merges on next load
```
- **Per-entry loop, not one big batch** — each call is tiny and fast, eliminating the story-generation timeout risk; a single failure is isolated and retryable.
- **No Opus integration step.** Writing generated JSON into the Drive array is mechanical code, not an AI task.
- Model: **Sonnet via the existing `/api/claude` Netlify function** (lazy password auth pattern).
- **AI decides all tags** — `grammar`, `register`, `region`, `irregularity`, `contextExplanation`, `synonyms`, examples — mirroring the original corpus generation. A high-literary verb is tagged as such by the model.
- **Tag-vocabulary guardrail:** the generation prompt is seeded with the *actual* tag values extracted from the frozen files at build time (the grammar codes, register values, region values) so the AI chooses from the same vocabulary the badges/filters key off. Per-entry judgment stays the AI's; it just can't invent a label that breaks the UI.
- **Generation output is a structured verdict:**
  ```jsonc
  { "status": "ok" | "needs_review",
    "entry": { "profile": {…}, "contexts": [{…}] },
    "notes": "…" }   // notes surfaced in feedback box; also carries semantic near-dup warnings
  ```

### 5.4 CRUD on the dynamic set
- **Full create / read / update / delete — dynamic entries only.**
- Edit-in-place for minor corrections (errors are likelier here than in the curated set).
- The "never remove" / removability protection applies to the curated corpus, **not** Daniel's own additions.

### 5.5 Feedback / hold loop
- `status: "ok"` → goes to pending review (Daniel still approves before commit).
- `status: "needs_review"` → entry held; AI's concern shown in feedback box; two actions:
  - **Edit & resend** — reopens the input plus a clarification field; single re-request with the note appended (no multi-turn chat state).
  - **Cancel** — discard.
- Exact-duplicate detection is the review lookup (code). Semantic near-duplicate ("'to film' overlaps an existing sense of *rodar*") is returned as an AI `note`.

---

## 6. Protections summary

| | Frozen curated set (701) | Dynamic Drive set |
|---|---|---|
| Review / lookup | ✅ | ✅ |
| Edit | ❌ | ✅ (minor edits) |
| Delete | ❌ | ✅ |
| AI generation | n/a | ✅ |
| Storage | Netlify (read-only) | Google Drive (mutable) |

---

## 7. Where the admin UI lives

Recommended: a **separate gated admin page** (e.g. `entrenador-admin.html`) that owns Drive OAuth, generation, staging, review, and CRUD. The trainer page only *consumes* the merged set (loads the dynamic Drive file read-only and merges). Same `CLIENT_ID` / scope, so both pages share the one Drive file. Keeps OAuth + generation complexity out of the trainer.

---

## 8. Build phasing (one phase tested before the next)

1. **Review / lookup popup** — read-only over frozen + dynamic, in-memory. Near-zero risk, immediately useful.
2. **Dynamic Drive set + AI generation** — staging queue, per-entry Sonnet loop, pending review, commit, Drive write, trainer merge; edit/delete on dynamic entries.
3. **Feedback / needs-review loop** — structured verdict, hold, Edit-&-resend / Cancel.

---

## 9. Confirm at build time (does not change this spec)

- Pin the live Entrenador II filename (the name on file 404s; sister site `mis-materiales-espanol` is deprecated, ignore).
- Confirm whether the "another dataset may appear" merge hook already exists; if not, add the merge step.
- Read how the trainer wires `VERB_PROFILES_xx` vs `VERB_CONTEXTS_xx` to its four quiz modes — settles the "show new sense on a frozen verb's card?" display question.
- Confirm exact current storage of statistics (expected: device-side / localStorage), and that custom-verb stats go dormant (not broken) when Drive is absent.
- Extract the real tag vocabularies (grammar / register / region) from all four files to seed the generation prompt.

---

## 10. Inherited conventions

- Drive integration replicates `comprension-lectora.html` verbatim: `CLIENT_ID`, `drive.file` scope, `driveRequest()` wrapper, bubble/pill connection UI, token-expiry handling, lazy connect-on-write prompt.
- API via `/api/claude` serverless function; lazy password auth.
- Sonnet for generation.
- Always clone fresh from GitHub at the start of the build session.
- Surgical `str_replace` edits over file rewrites; one observable change per deploy.

<!-- ─── end verbatim ─── -->

---

## conectores — Logical connectors — source notes

> Moved verbatim from `spanish_logical_connectors.md` on 2026-08-23. Raw material for the future Conectores hub.

<!-- ─── begin verbatim ─── -->

# Spanish Logical Connectors (Conectores Lógicos)

Mastering these connectors is one of the most effective ways to move from speaking in choppy, isolated sentences to expressing fluid, complex thoughts.

## 1. Temporal (Time & Sequence)
These establish the chronological relationship between events.

| Phrase | Meaning | Register / Usage Note |
| :--- | :--- | :--- |
| **Cuando** | When | **Cotidiano.** Universal default. |
| **Mientras / Mientras que** | While / Whereas | **Cotidiano.** Universal. |
| **Hasta que** | Until | **Cotidiano.** Universal. |
| **En cuanto** | As soon as | **Cotidiano.** Very common in speech. |
| **Antes de que / Después de que**| Before / After | **Cotidiano.** Universal. |
| **Una vez que** | Once | **Cotidiano.** Standard in both speech and writing. |
| **A medida que** | As (proportional) | **Formal / Escrito.** Common in literature or careful speech; rarely used in quick street slang. |
| **Tan pronto como** | As soon as | **Formal.** A slightly more elevated version of *en cuanto*. |

## 2. Causal (Cause & Origin)
These point backward to explain why something is happening.

| Phrase | Meaning | Register / Usage Note |
| :--- | :--- | :--- |
| **Porque** | Because | **Cotidiano.** Universal default. Never starts a sentence. |
| **Como** | Since / Because | **Cotidiano.** Used specifically to start a sentence (e.g., *Como llovía, no fui*). |
| **Ya que** | Since / Given that | **Cotidiano / Formal.** Excellent bridge word; sounds natural in speech but elevates your writing. |
| **Dado que** | Given that | **Formal.** Common in professional or academic contexts. |
| **Debido a (que)** | Due to | **Formal / Periodístico.** Standard in news reports and formal writing. |
| **Puesto que** | Since / As | **Literario.** Rarely heard in the street; used in literature and essays. |

## 3. Consecutive (Result & Consequence)
These point forward to show the effect of an action.

| Phrase | Meaning | Register / Usage Note |
| :--- | :--- | :--- |
| **Entonces** | Then / So | **Cotidiano.** The most common conversational filler for consequence. |
| **Así que** | So | **Cotidiano.** Extremely common in casual speech to wrap up a thought. |
| **Por eso** | That's why | **Cotidiano.** Universal. |
| **Por lo tanto** | Therefore | **Formal.** Standard in essays and professional arguments. |
| **En consecuencia** | Consequently | **Formal / Literario.** Used in academic or legal frameworks. |
| **De modo que / De manera que** | So that / In such a way that | **Formal.** Used to describe the method or result of an action carefully. |

## 4. Contrastive (Opposition)
These set two ideas against each other. 

| Phrase | Meaning | Register / Usage Note |
| :--- | :--- | :--- |
| **Pero** | But | **Cotidiano.** Universal default. |
| **Sino** | But rather | **Cotidiano.** Used exclusively to correct a negative statement (e.g., *No es rojo, sino azul*). |
| **En cambio** | On the other hand | **Cotidiano / Formal.** Very natural way to pivot between two contrasting facts. |
| **Sin embargo** | However | **Formal.** Highly common in writing, used moderately in careful speech. |
| **Por el contrario** | On the contrary | **Formal.** Standard in debate or analytical writing. |
| **No obstante** | Nevertheless | **Literario.** You will read this constantly; you will rarely say it. |

## 5. Concessive & Conditional (Obstacles & Rules)
These set the boundaries or requirements for an action to occur.

| Phrase | Meaning | Register / Usage Note |
| :--- | :--- | :--- |
| **Si** | If | **Cotidiano.** Universal default. |
| **Aunque** | Even though / Although | **Cotidiano.** Universal default for obstacles. |
| **A pesar de que** | Despite / In spite of | **Cotidiano.** Slightly more emphatic than *aunque*, very common. |
| **Por más que** | No matter how much | **Cotidiano.** Highly expressive; used when someone is stubbornly trying something. |
| **A menos que** | Unless | **Cotidiano / Formal.** Standard for setting a negative condition. |
| **Siempre y cuando** | As long as | **Cotidiano / Formal.** Standard for setting a strict requirement. |
| **Con tal de (que)** | Provided that / Just to | **Cotidiano.** Carries a sense of desperation or high motivation (e.g., *Haré lo que sea con tal de pasar*). |
| **Pese a que** | Despite | **Formal / Periodístico.** The journalistic equivalent of *a pesar de que*. |
| **Aun cuando** | Even if / Even when | **Literario.** Elevated; used in formal hypothetical arguments. |

<!-- ─── end verbatim ─── -->

---

## conectores-imagenes — Conectores — mental images

> Moved verbatim from `conectores-mental-images.md` on 2026-08-23. Companion raw material to the above.

<!-- ─── begin verbatim ─── -->

# Conectores — Mental Images, Image Kit & Build Outline

**What this is:** a reference + build outline for a future **Conectores** page. Part 1 is the mental-image system (for internalizing, not translating). Part 2 is a Gemini prompt kit to generate the illustrations. Part 3 is the page build outline (summary, grammar NOTA, quiz ideas) to flesh out later.
**Feeds:** the *Conectores* entry in `page-roadmap.md`.
**Source notes:** `ya_que_and_asi_qui_mental_models.md`, `spanish_as_since_connectors.md`.
**Dialect:** Neutral Latin American (examples use *tú*, never voseo).

---

## Part 1 — The mental-image system

### The core axis (decode nothing — feel the gesture)

At the bridge between two thoughts, the hand is doing one of three things. That gesture *is* the choice; you never translate.

- **Forward** — the cause is behind you; you throw the result out ahead.
- **Down** — the result is already standing; you reach under it to show what holds it up.
- **Through** — there's resistance; you push past it.

Register sorts within each: the coffee-chat voice vs. the formal/clinical voice.

### Forward — throw the result ahead (consequence)

- **entonces** — *the stepping-stone hop.* You're walking and just step to the next stone. Lightest, fastest, conversational. → *No había yerba, entonces tomé café.*
- **así que** — *climb the ladder, tip over the slide.* The first clause is you climbing (building the situation up); *así que* is the lip, and the result is the landing. One-way, effortless. **Whatever follows *así que* is the landing/consequence.** → *No tenía comida, así que fui a la tienda.*
- **por eso** — *thumb jerked back, result thrown forward.* *Eso* points back at the named cause; then you toss the result out. **What follows *por eso* is the result.** → *Llovió mucho, por eso las calles están inundadas.*
- **por lo tanto / por consiguiente** — *the gavel.* Evidence laid out, the gavel drops: "therefore." Heavy, formal, final. → *El paciente presenta fiebre alta; por lo tanto, recetaremos antibióticos.*

### Down — show what holds the result up (cause)

- **porque** — *lift the floorboard.* The result stands; you pull up the board directly beneath to reveal a **new** reason no one's seen yet. Answers *why*. → *Fui a la tienda porque no tenía comida.*
- **ya que** — *moor to the stake the sword already left.* The sword already came down (the *ya* — already, settled) and left a fixed stake. *Ya que* is the mooring line you tie to it. **An anchor is non-directional** — that's why *ya que* floats to the front or the middle of the sentence; you tie on from either side. **The *ya que* clause is the stake (already true); the other clause is the boat you tie to it.** You can only moor to something already planted — so *ya que* **cannot** take a decision or result. → *Ya que estás aquí, ayúdame.* / *No voy a salir ya que no tengo dinero.*
- **como** (causal) — *the poured slab.* Wet concrete has to go down first and set before you build, so *Como…* always **opens** the sentence — you physically can't slot it into the middle. → *Como llegaste tarde, empezamos sin ti.*
- **dado que / puesto que** — *ya que in a suit.* A document **handed** (*dado*) or **placed** (*puesto*) on the table: "given this filed fact." Same mooring gesture, formal register. → *Dado que el presupuesto es limitado, cancelaremos el viaje.*

### Through — push past the obstacle (concession)

- **aunque** — *shoulder through the wind.* The obstacle is real, you feel it, you keep walking and come out the other side with your point intact. → *Aunque estaba cansado, terminé el trabajo.*
- **pero** — *the fork.* A quick pivot onto the other branch of the path. → *Quería ir, pero no pude.*
- **sin embargo / no obstante** — *the detour sign you ignore.* Formal "and yet"; you note it and hold your course. *Pero* in a suit.

### The two contrasts that trip people up

- **ya que vs. por eso** — opposite gestures: **moor down** (reason follows) vs. **throw forward** (result follows). Your hands can't confuse tying-down with throwing-ahead.
- **ya que vs. porque** — **lean on a post already standing** (known/expected reason) vs. **dig up a board to reveal a fresh cause** (new information). That's why *ya que* refuses a consequence — there's no post there yet.

---

## Part 2 — Image creation kit (for Gemini)

**Unifying device:** one recurring **traveler** (backpack, friendly) walking through a landscape of ideas, performing each gesture. One character across the whole set = a cohesive, memorable series that matches the "walking from one thought to the next" frame.

**Style you want:** warm, colorful, semi-realistic cartoon — modern storybook / soft-3D, Pixar-like lighting.

**Critical:** **no text or letters in the image.** Generate the scene clean; the connector word goes on the page as a *text layer over the image* (the overlay pattern from `labeled-image-overlay-spec.md`) — never baked into the pixels.

### Reusable prompt template

> Warm, colorful, semi-realistic cartoon illustration in a modern storybook style — soft 3D, gentle Pixar-like lighting, clean uncluttered background, cohesive vivid palette. Recurring character: the same friendly traveler with a backpack, shown full-body. **No text, no letters, no numbers anywhere in the image.** Square composition. Scene: **[SCENE]**

### Per-connector scenes (drop into [SCENE])

- **entonces** — the traveler mid-stride, lightly hopping from one flat stepping-stone to the next across easy, sunny ground.
- **así que** — the traveler at the top of a tall, fun slide, having just climbed a ladder of stacked blocks, tipping forward to slide down toward a soft landing pad below.
- **por eso** — the traveler jerking a thumb back over the shoulder at a glowing object behind, while the other hand presents/tosses a result object forward.
- **por lo tanto** — the traveler as a calm judge, bringing a wooden gavel down onto a block on a formal podium; serious, conclusive mood.
- **porque** — the traveler crouching to lift a wooden floorboard/trapdoor, warm light glowing up from the hidden space underneath.
- **ya que** — the traveler on a dock tying a boat's mooring rope to a sturdy wooden post already driven firmly into the ground; the post subtly glowing to read as "already there."
- **como** — a freshly poured, smooth concrete foundation slab being laid first on open ground, the traveler standing on it ready to build.
- **dado que / puesto que** — a formal hand placing a single document or card down onto a polished table; tidy, official feel. (Can reuse one image for both.)
- **aunque** — the traveler leaning hard into a strong wind (jacket and leaves blowing back) but clearly still advancing forward.
- **pero** — the traveler at a clear fork in the path, pivoting to step onto the other branch.
- **sin embargo** — the traveler passing a roadside detour sign while calmly continuing straight on the main road.

---

## Part 3 — Future page build outline

Build to `single-topic-page-spec.md`; this is the spine for the *Conectores* roadmap entry. Strong candidate to lead with a visual **mapa de conectores** (the forward / down / through axis) so the page teaches the gesture first, the words second.

### Page summary (the teaching arc)
1. Open with the three-gesture axis — forward / down / through — as the organizing mental model.
2. One block per connector: the illustration + its one-line mental image + the usage rule + a clean example.
3. Group by gesture, not alphabetically. Note the register split (casual vs. formal/clinical) inside each group.
4. Close with the two trap-contrasts (*ya que* vs *por eso*, *ya que* vs *porque*).

### Grammar NOTA points (write these in English, per convention)
- **ya que / puesto que / dado que** introduce a **presupposed/known** reason; **flexible position** (initial or medial); indicative.
- **porque** introduces **new** information answering *¿por qué?*; normally not sentence-initial; indicative (subjunctive only in negated *no porque…*).
- **como** (causal) **must be sentence-initial**; indicative.
- **por eso** introduces a **result** and refers back to the just-stated cause (*eso*).
- **así que / entonces** = informal consequence; **por lo tanto / por consiguiente** = formal consequence (often set off with a comma or semicolon).
- **aunque** + indicative = factual concession (*aunque está lloviendo* = even though it IS raining) vs. + subjunctive = hypothetical (*aunque llueva* = even if it rains).
- **pero** = contrast; **sino** = "but rather," only after a negation.
- Punctuation: comma before *así que / por eso / por lo tanto*; comma after a sentence-initial *ya que / como* clause.

### Quiz ideas
- **Sort by gesture** — drag each connector into forward / down / through.
- **Fill the bridge** — two clauses with a gap; choose or type the connector. Seed the traps: *ya que* vs *por eso* vs *porque* on the same pair of facts.
- **"Can you moor to it?"** — a *ya que* drill: is the clause that follows a *given* (valid) or a *result* (invalid)? Yes/no.
- **Register match** — same idea, casual vs. formal context (coffee chat vs. clinical note); pick the fitting connector.
- **Direction check** — given the connector, does the *next* clause carry the reason or the result?

---

*Outline only — nothing built yet. Hand Part 2 to Gemini for the illustrations (clean, no text); we overlay the words on the page later.*

<!-- ─── end verbatim ─── -->

---

## tiempo-distancia-quizzes — Shelved quiz 2 + quiz 3 drafts

> Moved verbatim from `tiempo-y-distancia-quiz2-quiz3-shelved.md` on 2026-08-23. Decision record lives in 05-state.md; the drafts themselves are here.

<!-- ─── begin verbatim ─── -->

# Tiempo y Distancia Interactivo — Quiz 2 & Quiz 3 Shelved Work

### Created: May 2026
### Status: SHELVED — page is functionally complete; these two quizzes deferred indefinitely
### Purpose: Continuity doc if Daniel ever wants to resume building Quiz 2 / Quiz 3

---

## Page status as of shelving

The page `interactive/tiempo-y-distancia-interactivo.html` is feature-complete *except* for two quiz stubs inside the Cuestionarios tab. Everything else ships:

- **Tab 1 — Tiempo:** done. 12 sections.
- **Tab 2 — Distancia:** done. 10 sections + cross-tab callout.
- **Tab 3 — Cuestionarios:**
  - Quiz 1 (Práctica con fichas) **done**. 50-question external bank at `interactive/subpages/tiempo-distancia-fichas-bank-1.js`. Two-column layered drag + tap UX with sticky badge pool. Cotidiano-only (ignores the register switch by design).
  - Quiz 2 (Completar la oración) **stub only** — see below.
  - Quiz 3 (Traducción EN → ES) **stub only** — see below.
- **Tab 4 — Guía Rápida:** done. 26-row cheat-sheet table.
- All images, TTS dual-voice, register filter, navy translucent tabs — all live.
- Front-page wiring: linked from `index.html` at `Cuestionarios y Práctica → Recursos Interactivos → Tiempo y Distancia (interactivo)`.

---

## Where the stubs live in the page

Both stubs are sub-panels inside `<section id="tab-cuestionarios">`. The internal sub-tab nav at the top of that section already switches between them:

```html
<nav class="subtab-bar">
  <button class="subtab-btn active" data-subtab="fichas">Práctica con fichas</button>
  <button class="subtab-btn" data-subtab="fillin">Completar la oración</button>
  <button class="subtab-btn" data-subtab="translation">Traducción</button>
</nav>
```

The two stub panels are:

- `<div class="subtab-content" id="subtab-fillin">` — Quiz 2 stub
- `<div class="subtab-content" id="subtab-translation">` — Quiz 3 stub

Each contains a `distancia-placeholder` block with a "se construye en una fase futura" message. Replace those when building.

---

## Quiz 2 — Completar la oración

### What it was meant to be
A fill-in-the-blank quiz **generated and graded by the AI** (not pre-authored). The user clicks "generar cuestionario," gets 10 fresh fill-in items, types in the blanks, hits "comprobar," and gets per-question NOTA-style English feedback explaining the construction mechanics.

### API integration
- Uses the existing `/api/claude` Netlify serverless function (`netlify/functions/claude.mts`)
- Same lazy password gate pattern as Comprensión Lectora and condicionales-practica
- Two task strings per the main spec: `generate_quiz_fillin` (create items) and `correct_fillin` (grade)
- Lenient grading on accents and capitalization; accepts known variants

### Patterns to copy
Look at **`condicionales-practica.html`** first — it's the closest model:
- Has the lazy password gate UI (lines ~210–260)
- Wraps API calls in try/catch with "Error de conexión" fallback
- Handles 401 password-incorrect responses separately from network errors
- Uses `sessionPassword` after successful gate, stored in memory not localStorage

For the question-rendering layout, **`comprension-lectora.html`** (lines ~700+) has the more mature shell — password input field as a top-level form element, then the quiz body renders below once authenticated.

### Open design questions
Daniel needs to answer these before building:

1. **Layout** — same two-column as Quiz 1 (questions left, something on right)? Or single column? Quiz 2 has no badge pool, so the right column would have to hold something else (instructions? scoreboard? regenerate button?) — or just collapse to single column.
2. **Round size** — 10 questions like Quiz 1? Or shorter (5)?
3. **Register awareness** — should Quiz 2 respect the page-level cotidiano switch, or be cotidiano-only like Quiz 1?
4. **Generation trigger** — auto-generate on tab-switch (uses tokens), or require explicit "generar nuevo cuestionario" button?
5. **Verb agreement leeway** — should the grader accept "vivo" when "Vivo" was expected (capitalization-insensitive)? Likely yes. Accents? Likely yes.

### Bank-vs-API tradeoff to flag
The original plan was API-generated. But after Quiz 1's switch to a pre-authored bank, Daniel might want Quiz 2 to also be bank-based — same `window.FICHAS_BANKS`-style loader, different bank file (`tiempo-distancia-fillin-bank-1.js`). That avoids the API cost per-round and gives more authoring control. Worth asking before building.

---

## Quiz 3 — Traducción (EN → ES)

### What it was meant to be
The user sees an English sentence ("I've lived here for two years"), types a Spanish translation, and the AI grades it. The hard part: **multiple Spanish translations should be accepted as correct** — for that English sentence:
- *Vivo acá desde hace dos años*
- *Hace dos años que vivo acá*
- *Llevo dos años viviendo acá*
- *Vivo aquí desde hace dos años*

All four (and others) are correct. The grading prompt has to recognize equivalence across the construction families taught on this page.

### API integration
- Same `/api/claude` plumbing as Quiz 2
- Task strings: `generate_quiz_translation` and `correct_translation`
- Returns include English NOTA-style explanations of *which* construction the user chose and what others would have been equally valid

### The leeway challenge
This is the engineering risk for Quiz 3. The grader needs to:
1. Recognize semantic equivalence across the page's construction families (hace que / desde hace / llevar)
2. Allow voseo vs tuteo (vivís vs vives)
3. Allow neutral Lat-Am vs Rioplatense vocabulary (acá vs aquí)
4. Catch genuine errors (wrong tense, wrong preposition, missing *que*, etc.)
5. NOT just match against one canonical answer

Prompt engineering for this needs:
- A list of acceptable translation families per stimulus passed to the model
- Explicit "accept any of: X, Y, Z" framing
- Examples of acceptable vs unacceptable variations
- Maybe a two-pass approach: first check structural correctness, then check semantic match

### Open design questions
1. **Generation:** does the AI invent English stimuli on the fly, or are the English prompts pre-authored and only grading uses the API? Pre-authored English stimuli give more control and let Daniel curate which constructions get exercised.
2. **Display of accepted alternatives:** after grading, show the user *other* valid translations they could have written? Probably yes — that's high pedagogical value.
3. **Voseo handling:** mark in the user prompt that voseo is accepted? Or grade silently?

---

## If resumed: suggested order

1. Confirm format/scope answers to the open questions above with Daniel
2. Look at `condicionales-practica.html` and `comprension-lectora.html` for password-gate and API-call patterns. Copy, don't rewrite.
3. Build Quiz 2 first (simpler API; validates plumbing in this page's context)
4. Build Quiz 3 second (same plumbing, more complex prompt design)
5. Each deploy = one observable change (Quiz 2 ships, observe; Quiz 3 ships, observe)

---

## What NOT to redo

- The page's tab chassis, CSS, register switch, TTS, images, Tiempo content, Distancia content, Guía Rápida, and Quiz 1 are all stable. Don't touch them while building Quiz 2/3.
- The 50-question bank file is final and self-registering. Don't merge its content into the page.
- The two-column layout established for Quiz 1 was a specific design decision — don't force Quiz 2/3 to use it just for symmetry.
- The `registerChanged` event dispatch from the page register switch still fires, but Quiz 1 ignores it. Quiz 2/3 should make their own decision on whether to listen.

---

*End of handoff doc.*

<!-- ─── end verbatim ─── -->

---

## ya-fase-etapa — ya — unapplied fase/etapa half

> Moved verbatim from `ya-addendum-fase-y-ya-que.md` on 2026-08-23. HALF APPLIED. *ya que* is live on topics/ya-todavia-aun.html (5 hits). *fase*/*etapa* is NOT (0 hits, verified 2026-08-23). Only the fase/etapa half is still live work.

<!-- ─── begin verbatim ─── -->

# Adenda: «ya» como marcador de fase, y la separación de «ya que»

> **Estado:** Adenda a la página existente *Usos del adverbio «ya»*.
> **Propósito:** Refinamiento conceptual. Más adelante integrar esto en la página principal para mayor claridad.
> **Núcleo en una línea:** «ya» no es deíctico (no señala un momento) sino **fásico** (afirma un cambio de fase). El tiempo verbal solo dice *en qué reloj* ocurre el cruce; «ya» siempre marca el cruce mismo.

---

## 1. El modelo: «ya» = marcador de transición, no de momento

«ahora» señala el presente. **«ya» afirma que ha entrado en vigor un estado nuevo que antes no existía.** Por eso, en presente, «ya» casi nunca significa *now* en el sentido de «ahora»; significa *already* — estamos del **otro lado** del umbral.

El tiempo verbal no cambia el operador. Pasado, presente y futuro se leen **igual**: siempre es «cruzamos de un estado-antes a un estado-después». El inglés luego elige *already / now / eventually* según de qué lado de la frontera esté la frase — pero esas son traducciones de superficie, no significados distintos de «ya».

**Ejemplo guía:** *Ya es muy tarde para cambiar los planes.*
Presupone que **hubo** una ventana para cambiar; afirma que esa ventana **se cerró**. La frontera es el cierre de la ventana; estamos del lado de allá. No hace falta «demasiado»: *tarde para + infinitivo* ya carga el «too late»; «ya» añade *hemos cruzado a la zona de lo-demasiado-tarde.*

### Las cuatro piezas que cubren todo el espacio

| Expresión | Antes | Después | Frontera |
|---|---|---|---|
| **todavía** (still) | P | P | aún **no** cruzada |
| **ya** (already) | no-P | P | cruzada **hacia** P |
| **todavía no** (not yet) | no-P | no-P (esperado) | **pendiente** |
| **ya no** (no longer) | P | no-P | cruzada **fuera** de P |

**Trampa de polaridad en «ya no»:** el estado que **valía antes** es siempre el positivo. *El señor Robles ya no vive aquí* = «[vivir aquí] valía → cruce → ya no». Guardarlo como **estado positivo valía → «ya no» = salida de ese estado**, nunca como «el no-estado ocurría antes». Lo de antes es siempre lo que ahora ya no está.

---

## 2. La colocación controla *qué* cruza la frontera

El tiempo verbal dice *en qué reloj*; **el orden de palabras dice *qué* cruza**.

- *Tenemos que terminarlo **ya*** (posición final) → la frontera cae sobre **el momento de la acción**. *Hazlo ya, sin más demora.* Registro más enfático, casi perentorio.
- ***Ya** tenemos que terminarlo* (preverbal) → la frontera cae sobre **la llegada de la obligación misma**. «Ya hemos llegado al punto en que toca» / «ya venció». Lo que se invierte no es *cuándo terminás* sino *que el tener-que ya entró en vigor.*
- *Tenemos que terminarlo* (sin «ya») → **nada cruza**: obligación de fondo, sin fecha. Por eso suena a «en algún momento hay que terminarlo».

Ambas versiones con «ya» se traducen al inglés como *now*, y por eso **se sienten idénticas** — pero la fase que cruza es distinta (el evento en una, el modal en la otra).

> **Rioplatense:** la versión más perentoria es «ya» en posición final sobre imperativo (voseo): *Terminalo ya. Vení ya. Pará ya.* Registro «ahora mismo, en serio».

---

## 3. La distinción clave: «ya que» **no** es «ahora que»

Esta fue la parte más útil del trabajo. Al meterse dentro de la frase fija **«ya que», el «ya» se ha gramaticalizado**: deja de computar «already» y se funde en una **conjunción causal**. Hay que sacarlo del modelo fásico.

### El reparto, contra la intuición

Uno *esperaría* que «ya» (el marcador de transición) fuera el más transicional. **Es al revés:**

- **«ahora que»** = **temporal-causal**. «Now that.» Conserva un ancla viva al presente: «en este nuevo *ahora* en que X se volvió verdad».
  *Ahora que lo pienso. Ahora que soy mayor.*
- **«ya que»** = **causal puro**. «Since / given that / seeing as.» Presenta una **razón como hecho dado**. Puede ser totalmente atemporal.
  *Ya que estás aquí. Ya que insistís. Ya que lo mencionás.*

La energía transicional **migró al «ahora que»**; el «ya que» se endureció en un ladrillo lógico.

### El test que lo parte limpio: *mayor*

- *Ahora que soy mayor, entiendo a mis padres.* → vivencia de **haber crecido**, presente nuevo. ✅
- *Ya que soy mayor…* → se aplana a «dado que soy adulto». **Se pierde el tiempo.** ✅

Cuando el sentido **temporal** es el punto de la frase, «ya que» visiblemente no lo entrega. Ahí se ve que ya no carga tiempo.

### Por qué el back-translation engaña (el punto central)

En inglés *now that you're here* funciona para *ya que estás aquí* — pero **no** porque «ya que» alcance a agarrar tiempo. Es porque el inglés *«now that»* es lo bastante flojo como para cubrir un «since» puramente causal. **La frase ambigua es la inglesa; la española es la inequívoca.** El inglés es el idioma que permite la flexibilidad — no el español.

→ Por eso el test válido es *mayor* (donde lo temporal es el punto), no el back-translation (donde el inglés hace doble trabajo y te miente).

### Diagnóstico práctico

| Lo que importa | Gana | Ejemplo |
|---|---|---|
| Solo la razón, sin presente nuevo | **ya que** | *Ya que estás, traeme un mate.* |
| Nueva fase de vida / del presente | **ahora que** | *Ahora que soy mayor, entiendo a mis padres.* |
| Ambos (causa **y** umbral temporal) | las dos encajan | *Ya que gané la lotería* (foco: la razón) / *Ahora que gané* (foco: el nuevo estado) |

---

## 4. Regla operativa para «ya que» de aquí en adelante

Tratar lo que sigue a «ya que» como un **dato dado** — una razón presentada como establecida — **no** como un significado fásico de «ya».

Matiz importante: el dato **no tiene que ser objetivamente verdadero**, solo *tomado como concedido para el argumento*:

> *Ya que sos tan inteligente, resolvelo vos.* — puro sarcasmo; el «hecho» es cualquier cosa menos cierto.

La gramática es: **«trato X como dado, por lo tanto Y».** Eso deja entrar bajo un mismo techo el sarcasmo, la concesión y la causa genuina.

> **Rioplatense:** *ya que estás / ya que estamos* es uno de los conectores causales más naturales del dialecto — «seeing as / while you're at it».
> *Ya que estás, cerrá la ventana.* Cero «already» adentro.

---

## 5. Alcance honesto del modelo fásico

- **Usos 1–5** (pasado, presente, «ya no», inmediato, futuro): el modelo es **literal y hermético**.
- **Usos 6–7** (reconocimiento *«—Ya.»*; irónico *«—Ya, ya…»*): el modelo **sigue explicándolos** como extensiones metafóricas — cruzar a la *comprensión*; *fingir* el cruce.
- **Uso 8, «ya que»**: aquí la fuerza fásica **se aplanó** en lógica pura. **Sacarlo del modelo** y archivarlo como conector causal.

**Lección general:** una vez que una frase se fusiona — *ya que, ahora que, puesto que, dado que, así que* — dejar de descomponerla y aprender el **trabajo de la unidad entera**. *ya* y *ya no* quedan en el modelo fásico; *ya que* va a su propio cajón: **«conector causal — tratar lo siguiente como dado».**

<!-- ─── end verbatim ─── -->

---

## roadmap-detalle — Full roadmap detail + source-file map

> Moved verbatim from `page-roadmap.md` on 2026-08-23. Dissolved into 06-ideas.md as short blocks; the detail and the source-file references are preserved here.

<!-- ─── begin verbatim ─── -->

# Mi Proyecto Español — Page Roadmap (from the ideas/materials dump)

**What this is:** a forward-looking map of pages to build, pages to expand, and a few non-page items — distilled from the notes in the ideas zip. It is *not* an index of the notes. Each entry names the **source file(s)** that prompted it; upload that file when we sit down to build the entry so the original thinking travels with it.

**How to read each entry:**
- **Status** — `NEW` (build a page) · `EXPAND` (add to an existing page) · `FOLD` (feed into an already-queued page) · `REBUILD` (a Gemini HTML to redo to spec) · `FEATURE` (app idea, own spec) · `INFRA`.
- **Form** — `static` (single-topic-page-spec) or `interactive` candidate (complexity earns a quiz/tool).
- **Source note(s)** — exact filename(s) from the zip.

**Build hubs with expansion in mind.** For the big topics, the first build is a parent/overview page; subpages get added over time without restructuring (your parent + subpage convention). Don't try to ship a tentpole topic whole.

**One intake rule for everything below:** these notes are riddled with Rioplatense/voseo (*campera, sos, ponés, llegués, quedate acá*) — one file even instructs voseo outright. Neutralize to Latin American neutral on intake, every time, per the site-wide policy.

---

## 1. TENTPOLE — El Subjuntivo  ·  Status: NEW (hub, phased)  ·  Form: static → interactive

The marquee build, and far too big for one page. Plan it as a hub from day one so it can grow.

**Architecture (build in this order):**
1. **Overview / mental model** — mood vs. tense; the core *assertion vs. non-assertion* logic (declared information → indicative; backgrounded / unrealized / non-asserted → subjunctive). This frame is the spine the whole topic hangs on.
2. **Subpage — Disparadores temporales** — *cuando, hasta que, en cuanto, tan pronto como, después de que, mientras*; the future-anticipation (subjunctive) vs. habitual/past (indicative) contrast. *Source: `spanish_subjunctive_time_triggers.md`*
3. **Subpage — Disparadores categóricos** — conjunctions that are always subjunctive (*antes de que, sin que*, plus *para que, a menos que, con tal de que*…). *Source: `subjunctive_triggers_analysis.md`*
4. **Subpage — Disparadores contextuales (valor informativo)** — *el hecho de que*, narrative *después de que*, the *no creer que* vs. *¿no crees que…?* loophole. The "is this being asserted or backgrounded?" judgment. *Source: `subjunctive_triggers_analysis.md`*

**Future slots (no source notes yet — leave the hub room for these):**
5. Verb-driven triggers (WEIRDO): querer/esperar que, emotion, impersonal *es importante que*, requests, doubt/denial.
6. The subjunctive **tenses** (presente, imperfecto -ra/-se, perfecto, pluscuamperfecto) + sequence of tenses.
7. **Si**-clauses / conditionals (*si tuviera…*).
8. **Interactive:** trigger-sorting or mood-choice quiz — strong fit once subpages 2–4 exist.

---

## 2. Conectores (causa, consecuencia, tiempo)  ·  Status: NEW (hub)  ·  Form: static, interactive-friendly

The *ya que / así que* conversation. A general connectors page plus a connectors-of-consequence focus.

- **Parent — Conectores de causa y consecuencia:** *ya que, puesto que, dado que, como, porque* (cause) vs. *así que, entonces, por lo tanto, por eso* (consequence) vs. concession *aunque*. Use the "domino / load-bearing pillar / diverter" mental model as the hook, the English-mapping table as the reference layer. The metaphors are Gemini's invention — vet for accuracy before they ship.
- **Possible subpage / second page — Causa vs. tiempo:** *desde que, a medida que* (time) split out from the cause group, since English "as/since" blurs them.
- **Check overlap** with existing time-construction pages (*desde-hace…*) before drafting, to avoid re-covering ground.
- *Source notes: `ya que and asi qui mental models.md`, `spanish_as_since_connectors.md`*

---

## 3. Adjetivos  ·  Status: NEW (hub)  ·  Form: static; placement = interactive candidate

A whole family currently scattered across five files (with one outright duplicate pair).

- **Subpage — Cambio de significado por posición** (before/after the noun: *gran/grande, pobre, nuevo, único, viejo*…). **Merge the duplicate pair** into one union table + examples. Excellent **interactive** candidate (before/after meaning quiz). *Source: `spanish_adjective_placement.md` + `spanish_adjectives_meaning_shifts.md` (merge these two)*
- **Subpage — Secuencia de adjetivos** (clasificadores vs. calificativos; when to use *y*; the "core unit" idea). *Source: `spanish_adjective_rules.md`*
- **Subpage — Cualquier / cualquiera** (apócope; the *cualesquiera* formal plural; the *una cualquiera* warning). *Source: `Spanish_Grammar_Cualquier_Notes.md`*
- **Subpage — Participios como adjetivos** (verbal vs. adjectival; the animacy split: *abierto* door vs. *abierto* person). *Source: `Participios_Desdoblamiento_Semantico.md`*
  - **Now has a dependency.** `topics/verbos-en-profundidad/tener-estructural.html` (SHIPPED) covers participle **agreement** and the four-way auxiliary contrast (*haber* invariable · *ser* passive · *estar* resultant state · *tener/llevar* resultative) and links forward to this page. Build this one to cover what that page does **not**: the dual-participle pairs (*freído/frito*, *imprimido/impreso*, *despertado/despierto*, *elegido/electo*), the animacy split, and participles lexicalized as nouns. Avoid re-covering agreement — cross-link instead.
- **Vocab companion — 60 adjetivos para describir a una persona** (a descriptor list page). *Source: `vocab 2.html` (REBUILD — loads no design-system fonts at all)*

---

## 4. Pronombres y mecánica de objetos  ·  Status: NEW / EXPAND (hub)  ·  Form: static

- **Parent — Pronombres redundantes y posición** (fronting/topicalization → required DOP echo; the *mandatory* IOP duplication). *Source: `spanish_pronoun_mechanics.md`*
- **Subpage — Partes del cuerpo y ropa** (article-vs-possessive; reflexive vs. IOP for who owns the body part). **Merge the duplicate pair.** You mentioned this may overlap existing coverage — check whether this is a NEW page or an EXPAND of something you already have; the notes spell out aspects (the prepositional "wall," body-part-as-subject) that may not be on the site yet. *Source: `Spanish_Body_Parts_Summary.md` + `Spanish_Grammar_Body_Parts_Clothing.md` (merge these two)*

---

## 5. El "Se"  ·  Status: FOLD into the queued **Tres Zonas de SE** page  ·  Form: static

Don't make a new page — this note is ready-made source material for the SE page already in your queue: accidental *se*, *pasiva refleja*, impersonal *se* + personal *a*. *Source: `spanish_se_constructs.md`*

---

## 6. Grados y cantidades  ·  Status: NEW (small hub or 3 standalones)  ·  Form: static

A natural trio about degree/quantity; *tan…como para* even links two of them.
- **Poco** — adverb (*poco claro*) vs. adjective (*poca paciencia*) vs. *un poco de*. *Source: `poco_mechanics.md`*
- **Como para** — *demasiado / suficiente / tan … como para* + the colloquial "looks like / in the mood for." *Source: `como_para_cheat_sheet.md`*
- **Tan / tanto** — comparatives of degree. *Source: `Spanish_Tan_Tanto_Guide.pdf`*

---

## 7. Standalone single-topic pages

> **Shipped and removed from this list:** *Tener: idiomático vs. estructural* — absorbed into the Verbos en Profundidad hub as `tener.html` + `tener-estructural.html` (August 2026).

- **De vs. a partir de** — static origin vs. forward trajectory; the "starting from" test. `NEW`. *Source: `de_vs_a_partir_de.md`*
- **La elisión de "que"** — when *que* can drop. `REBUILD` to spec. *Source: `elision-de-que-v2.html`*
- **Hasta** — límite vs. inclusión ("even"). `REBUILD`; comes with example sentences ready. *Source: `hasta.html`, `pictures for HASTA page.txt`*
- **Trampas: venir vs. salir** — English-interference trap; fits the **Palabras Tramposas** family. `REBUILD`; comes with an image asset list. *Source: `trampa de salir y venir.html`, `images for salir y venir page.txt`*

---

## 8. Páginas dinámicas (input on the fly)  ·  Status: FEATURE (own mini-spec)  ·  Form: interactive

Not a topic page — an app pattern: enter/delete vocab live (a "vocab of the week," look-alike pairs like *dar/decir*, *dejar/decir*, *dime/di*). Same Drive-CRUD family as Palabras Tramposas / quiz-género; the look-alikes overlap that page's confusables concept. Spec it separately when ready. *Source: `dynamic pages idea.txt`*

---

## 9. Site icon / favicon  ·  Status: INFRA

Replace the current icon (and the Spain-flag assets, which clash with the neutral-LatAm identity). Icon options that read as "Spanish language" without picking a country, and that use the site's own fonts/palette:
- **An *ñ* monogram** — DM Serif Display *ñ* on deep navy with an accent-color tilde. The single most recognizable, country-neutral letter of Spanish. Top pick.
- **A *¿* glyph** — the inverted question mark: unmistakably Spanish, neutral, and thematically tied to the new Formación de Preguntas app.
- **An azulejo tile** — a single motif from the existing `azulejos.webp` background, tying the icon to the site's established look.
Mechanics (sizes, `<link>` tags, cache quirk) are covered in *Source: `favicon_guide.md`* + the existing PNG set (to be regenerated at 32 / 180 / 192 from the chosen mark). I can mock up the *ñ* or *¿* as an SVG/PNG whenever you want to see them.

---

## 10. Parking lot — Comprensión Lectora follow-ups (separate track, not a page)

Captured here so they're not lost; they belong with the CL work, not the topic pipeline.
- **Disputed quiz item** — a question keyed to answer D (Javier seizing all the gold) that the passage doesn't support; you picked A. A content-quality / grader-strictness issue to revisit. *Source: `Subjunctive triggers for futuer review.txt`*
- **Episode mis-sequencing bug** — JSON error on "generar siguiente," then *reintentar* regenerates an already-done episode and desyncs the count. Last time the «»-quotes fix made the JSON error stop occurring, so the desync never resurfaced; decide whether to harden the sequence logic or leave it. *Source: same file*

---

## Cross-cutting note

Every page built from these notes needs a **neutral-LatAm pass on intake** — strip voseo and Rioplatense lexis from examples unless a page is explicitly a dedicated regional one. This is a Gemini artifact, not a content choice.

---

*Roadmap only — nothing here is built or specced for build yet. Greenlight clusters one at a time; upload the named source file(s) when we start each.*

<!-- ─── end verbatim ─── -->

---
