# Entrenador de Verbos II — Data Admin & Dynamic Verb Set
### Specification (v1, discussion-locked)

**Status:** Spec agreed in discussion. No code written yet. Build proceeds in phases, one phase tested before the next begins.

**Purpose:** Let Daniel add, review, and manage new verbs/phrases for Entrenador de Verbos II on the fly — through a front-end form plus an AI generation step — without hand-editing the curated data files, and have those additions sync across all his devices. The large curated corpus stays frozen and untouched.

---

## 1. Architecture: where the data lives

Three separate places, each with one job:

- **Netlify** — hosts the website and the **frozen curated verb files** (`verbos-a-d.js` … `verbos-r-z.js`). Identical on every device, read-only, served to whatever device opens the URL. This is the bulk of the data and it never changes from the browser.
- **Google Drive** — holds **one small mutable JSON file** containing Daniel's new verbs. Lives in the cloud, tied to his Google account, in the existing "Spanish Learning" app folder via `drive.file` OAuth scope. This is the *only* mutable data.
- **The device (PC / iPad / phone)** — runs the app in the browser; stores nothing permanent except device-local statistics. Just a window onto the two data sources above.

**Merge-at-load model.** On page load the trainer reads the frozen arrays from Netlify; on Drive connect it reads the dynamic file from Drive; it concatenates them into one in-memory dataset. After the merge, the app has **no notion of which verb came from where** — frozen and custom verbs behave identically in every quiz mode.

**Cross-device.** Because the mutable file lives in Drive, adding a verb on one device and studying it on another works automatically: log into the same Google account on the second device, the app fetches the latest file, merges, done. (Read-on-open / write-on-save, not live multiplayer sync — single device at a time when *editing*; last-write-wins.)

**Decision — the 700-verb set is NOT moved to Drive.** It is frozen and read-only; Netlify is the correct home for it (fast, no auth, no latency, uncorruptible). Moving it to Drive would add an OAuth dependency and load latency to the core trainer for zero benefit.

---

## 2. Graceful degradation (Drive optional)

- **Drive is optional for studying, required only for saving.** Frozen verbs load from Netlify regardless of Drive state. No login → trainer runs fully on the frozen 701-verb set.
- **Statistics are device-side and Drive-independent.** Missing Drive does not affect stats. A stat that references a custom verb not currently loaded goes *dormant* (skipped, not broken) until Drive reconnects.
- **Lazy connect-prompt.** Studying never prompts. The connect-Drive popup fires only on a *write* action (add / save / commit / edit). This reuses the comprensión-lectora connection UI and `driveRequest()` wrapper verbatim.

---

## 3. Data schema (the "two arrays" reality)

Each frozen file declares **two parallel arrays**. A complete entry spans both. The generation step must produce both.

### 3a. `VERB_PROFILES_xx` — reference profile (one object per verb)
```js
{
  verb: "abrigar",
  irregularity: "pret: g→gu (yo)",      // free-form tag; "regular", "pp: abierto", etc.
  summary: {
    blurb: "…one-paragraph profile…",
    uses: [
      { meaning: "to wrap up, to keep warm",
        example: { spanish: "…", english: "…" },
        register: "everyday" }
      // one entry per sense
    ],
    pronominalNote: null                 // string or null
  }
}
```

### 3b. `VERB_CONTEXTS_xx` — quiz-facing rows (one object per *context/sense*)
```js
{
  verb: "abrazar",
  phrase: "abrazar",
  grammar: "TR",                         // TR, INTR, RECIP, PRNL, … (transitivity/type tag)
  english: "to hug, to embrace",
  register: "everyday",                  // everyday, standard, … (observed; full set extracted at build)
  region: "neutral",                     // neutral, rioplatense, … (drives example dialect)
  notes: "",
  contextExplanation: "…",
  synonyms: [],
  example: { spanish: "…", english: "…" }
}
```

**Note on dialect:** the corpus is region-mixed and tagged per entry (`region`). The example's dialect must match its `region` tag (e.g. voseo for rioplatense, neutral elsewhere). The AI sets `region` and writes the example accordingly.

---

## 4. The dynamic Drive file

A single JSON file storing Daniel's additions as paired fragments, ready to merge into both arrays:

```jsonc
{
  "version": 1,
  "entries": [
    {
      "id": "uid-generated",
      "profile":  { /* VERB_PROFILES shape */ },
      "contexts": [ { /* VERB_CONTEXTS shape */ } ]   // 1+ rows
    }
  ]
}
```

At load: `allProfiles = [...frozenProfiles, ...drive.entries.profile]`, `allContexts = [...frozenContexts, ...drive.entries.contexts]`.

**Adding a context to an existing (frozen) verb** = append a new `contexts` row to the dynamic file. No edit to the frozen verb. (Whether the frozen verb's reference *card* also displays the new sense is a small display question resolved at build, once the trainer's array→mode wiring is read. Quiz behavior is clean either way.)

---

## 5. Functional components

### 5.1 Review / lookup (read-only)
- Type a verb/phrase → popup shows matching entries (frozen + dynamic), one line each: verb · context · register.
- Pure in-memory pattern match. No AI, no Drive needed for the frozen set.
- **Frozen entries: review-only. No edit, no delete.** (The curated 700 stay untouchable.)
- Dynamic entries: clickable → opens edit panel (see 5.4).

### 5.2 New-entry staging
- Form: **verb/phrase** + **desired context(s)** (free text — the context need not be verbatim; the AI interprets and fills all fields).
- Entries are saved to a **staging queue** (in the Drive file or a sibling staging file) so nothing is lost between sessions.

### 5.3 AI generation (the pipeline)
```
Staged entries → [Generate] → one Sonnet call PER entry (client-side loop)
              → results land in PENDING REVIEW (not yet live)
              → Daniel approves → [Commit] → written into the dynamic Drive file
              → trainer merges on next load
```
- **Per-entry loop, not one big batch** — each call is tiny and fast, eliminating the story-generation timeout risk; a single failure is isolated and retryable.
- **No Opus integration step.** Writing generated JSON into the Drive array is mechanical code, not an AI task.
- Model: **Sonnet via the existing `/api/claude` Netlify function** (lazy password auth pattern).
- **AI decides all tags** — `grammar`, `register`, `region`, `irregularity`, `contextExplanation`, `synonyms`, examples — mirroring the original corpus generation. A high-literary verb is tagged as such by the model.
- **Tag-vocabulary guardrail:** the generation prompt is seeded with the *actual* tag values extracted from the frozen files at build time (the grammar codes, register values, region values) so the AI chooses from the same vocabulary the badges/filters key off. Per-entry judgment stays the AI's; it just can't invent a label that breaks the UI.
- **Generation output is a structured verdict:**
  ```jsonc
  { "status": "ok" | "needs_review",
    "entry": { "profile": {…}, "contexts": [{…}] },
    "notes": "…" }   // notes surfaced in feedback box; also carries semantic near-dup warnings
  ```

### 5.4 CRUD on the dynamic set
- **Full create / read / update / delete — dynamic entries only.**
- Edit-in-place for minor corrections (errors are likelier here than in the curated set).
- The "never remove" / removability protection applies to the curated corpus, **not** Daniel's own additions.

### 5.5 Feedback / hold loop
- `status: "ok"` → goes to pending review (Daniel still approves before commit).
- `status: "needs_review"` → entry held; AI's concern shown in feedback box; two actions:
  - **Edit & resend** — reopens the input plus a clarification field; single re-request with the note appended (no multi-turn chat state).
  - **Cancel** — discard.
- Exact-duplicate detection is the review lookup (code). Semantic near-duplicate ("'to film' overlaps an existing sense of *rodar*") is returned as an AI `note`.

---

## 6. Protections summary

| | Frozen curated set (701) | Dynamic Drive set |
|---|---|---|
| Review / lookup | ✅ | ✅ |
| Edit | ❌ | ✅ (minor edits) |
| Delete | ❌ | ✅ |
| AI generation | n/a | ✅ |
| Storage | Netlify (read-only) | Google Drive (mutable) |

---

## 7. Where the admin UI lives

Recommended: a **separate gated admin page** (e.g. `entrenador-admin.html`) that owns Drive OAuth, generation, staging, review, and CRUD. The trainer page only *consumes* the merged set (loads the dynamic Drive file read-only and merges). Same `CLIENT_ID` / scope, so both pages share the one Drive file. Keeps OAuth + generation complexity out of the trainer.

---

## 8. Build phasing (one phase tested before the next)

1. **Review / lookup popup** — read-only over frozen + dynamic, in-memory. Near-zero risk, immediately useful.
2. **Dynamic Drive set + AI generation** — staging queue, per-entry Sonnet loop, pending review, commit, Drive write, trainer merge; edit/delete on dynamic entries.
3. **Feedback / needs-review loop** — structured verdict, hold, Edit-&-resend / Cancel.

---

## 9. Confirm at build time (does not change this spec)

- Pin the live Entrenador II filename (the name on file 404s; sister site `mis-materiales-espanol` is deprecated, ignore).
- Confirm whether the "another dataset may appear" merge hook already exists; if not, add the merge step.
- Read how the trainer wires `VERB_PROFILES_xx` vs `VERB_CONTEXTS_xx` to its four quiz modes — settles the "show new sense on a frozen verb's card?" display question.
- Confirm exact current storage of statistics (expected: device-side / localStorage), and that custom-verb stats go dormant (not broken) when Drive is absent.
- Extract the real tag vocabularies (grammar / register / region) from all four files to seed the generation prompt.

---

## 10. Inherited conventions

- Drive integration replicates `comprension-lectora.html` verbatim: `CLIENT_ID`, `drive.file` scope, `driveRequest()` wrapper, bubble/pill connection UI, token-expiry handling, lazy connect-on-write prompt.
- API via `/api/claude` serverless function; lazy password auth.
- Sonnet for generation.
- Always clone fresh from GitHub at the start of the build session.
- Surgical `str_replace` edits over file rewrites; one observable change per deploy.
