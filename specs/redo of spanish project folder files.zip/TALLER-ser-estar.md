<!-- FILE ROLE ------------------------------------------------------------
TALLER SLOT 2 of 3. Active build. Page: topics/ser-estar.html (proposed)
BORN:    2026-08-23 (merged from ser-estar-page-spec.md +
         ser-estar-personas-marco-decision.md — two files, one unbuilt page)
DIES:    at deploy. Killing it is Claude's job, same session as the ship.
STATUS:  §8 decisions unlocked. Engine is "clasificar vs. situar", NOT the
         usual four-domains list. Biggest gap on the site.
NOTE:    This file is the two source documents concatenated, unedited. They
         have not been reconciled with each other yet — that is the first
         task of the build session. Overlaps and contradictions are expected.
------------------------------------------------------------------------ -->

# PART A — page spec
> Verbatim from `ser-estar-page-spec.md`

# Mi Proyecto Español — Spec: *Ser y Estar* (página de gramática)

**Type:** Single-topic reference page (info/grammar only)
**Location:** `topics/ser-y-estar.html`
**Scaffold authority:** inherits `03-page-standards.md` in full (fonts, palette, favicon, back-nav, NOTA layer, neutral-voice TTS, rate bar, emoji policy, responsive rules, self-check). This document specifies *only* what is unique to this topic: the content architecture, the example sets, the NOTA plan, the contrast device, and what is shelved.
**Status:** DRAFT for Daniel's sign-off. No build until decisions in §8 are locked.

---

## 1. Thesis (the spine of the whole page)

The page runs on **one engine, not four domains: clasificar vs. situar.**

- **SER classifies.** It says what category a thing belongs to — what it *is*. Nationality, profession, material, and **character traits** are all classification.
- **ESTAR situates.** It places a thing in a **condition or a position** — what state it is *in*, read against a norm or an expectation.

Everything the textbooks present as separate "uses" is this one contrast pointed at a different noun. The page's job is to make the reader *derive* the four textbook boxes from the single engine, so they stop memorizing domains:

| Textbook "domain" | Same engine, restated |
|---|---|
| Description | a **trait** (classify → ser) vs. a **condition** (state → estar) |
| Location | an event **occurs** (ser ≈ *suceder/tener lugar*) vs. an object **sits in a position** (estar ≈ *ubicarse*) |
| Passive voice | the **action/process + agent** (ser + participio) vs. the **resulting state** (estar + participio) |
| Impersonal opinion | judging **the kind of situation** (*es bueno que*) vs. assessing **how it stands** (*está bien que*) |

**Hard rule the page must kill on contact:** the "permanent vs. temporary" heuristic. It is the exact thing that misled the *fui terca* reading. Temporariness is carried by the **tense**, not by the verb. That correction is stated in §2-Section 1 and reinforced in Section 2.

---

## 2. Section architecture (single long page, anchored nav)

Six content sections, engine first, culture as the capstone. Each is a `.grammar-card` (or contrast-card variant per §3). Section order is the teaching order.

### Section 1 — *El motor: clasificar vs. situar*
The master reframe. Establishes classify-vs-situate, kills permanent/temporary, and previews the "four coats, one engine" table above as the organizing promise of the page.
- **Anchor pair:** *Es nervioso* (an anxious **type**) / *Está nervioso* (nervous **right now**).
- Heaviest NOTA on the page sits here (NOTA-A, see §4).

### Section 2 — *Personas y cosas: rasgo vs. estado*
The engine applied to people and things. This is where the learner meets trait adjectives and would otherwise form the wrong pattern, so the negative-trait correction lives here.
- **Minimal pairs:**
  - *Es gordo* / *Está gordo* — the "he's a heavy guy" classification vs. the "he's gotten heavy / looks heavier than I expected" state-against-a-norm reading.
  - *Es callada* / *Está callada* — reserved by character vs. unusually quiet today.
  - *Es nervioso* / *Está nervioso* — reprised from §1 as the clean template.
- ***Fui terca*** gets its own micro-treatment: ser + **pretérito** = "on that one bounded occasion I behaved stubbornly," not "I was permanently stubborn." The one-time reading comes from the preterite; you do **not** switch to estar to get it. (Teacher's original *Ayer fui terca porque no quise usar el inodoro* is Rioplatense-flavored; page uses a neutral example and marks the teacher's as a `data-region="rioplatense"` aside, not a focus.)
- **NOTA-B (Daniel's observation):** *¿Por qué parece que los rasgos negativos prefieren SER?* — see §4. This is the explicit note he asked for.

### Section 3 — *Posición vs. ocurrencia: dónde "está" y dónde "es"*
The location split, reframed as object-vs-event so it stops being an exception to memorize.
- **Minimal pairs:**
  - *Mi casa está en la esquina* (object → position) / *La fiesta es en mi casa* (event → occurrence). Same house, two verbs, because one is a thing and one is a happening.
  - *El profesor está en el aula 3* (person → position) / *El examen es en el aula 3* (event → occurrence).
- NOTA-C (short): events "happen" → ser ≈ *suceder / tener lugar / celebrarse*; objects and people "sit" → estar ≈ *ubicarse / encontrarse*. The one time ser marks "where" is when it isn't really location — it's an event.

### Section 4 — *Pasiva y estado resultante: «fue construido» vs. «está construido»*
The participle split, and the home of the *se cansó / está cansado* question. Built on one pipeline:

**acción → suceso → estado resultante**
*cansarse* (verb) → *se cansó* (the bounded event, pretérito) → *está cansado* (the state that remains).

- **Minimal pair:** *El edificio fue construido en 1950 (por un arquitecto famoso)* — passive, process + agent, **ser** — vs. *El edificio está construido desde 1950* — resulting state, **estar**.
- **Pipeline trio (straight from the teacher's PDF):** *se cansó → está cansado*; *se vistió → está vestido*; *se murió → está muerto*.
- **NOTA-D (the over-extension fix):** the rule is **not** "participle → estar." It's "**resultant state** → estar." `ser + participio` is the *other* participle job — the **passive** (an event with an agent). And participle-shaped **traits classify people**, so they stay ser: *ser educado, ser considerado, ser callado*. This directly repairs the "I extrapolated participle→estar to everything" misread.

### Section 5 — *Pares que cambian de sentido*
Where both verbs are grammatical and the engine itself outputs **two different words.** Pure contrast table (§3 device), no prose needed beyond a one-line header.
- **Core set (proposed):** *ser/estar listo* (clever / ready) · *aburrido* (boring / bored) · *rico* (rich / tasty) · *orgulloso* (arrogant / proud of) · *malo* (evil / sick) · *vivo* (sharp / alive).
- **Optional extended set** (only if you want it richer): *bueno* (good person / tasty-attractive — register flag) · *verde* (inexperienced / unripe) · *despierto* (sharp / awake).
- This section is the natural seam to the *orgulloso* item your teacher flagged (ser = arrogant; estar orgulloso de un logro = the positive "proud of").

### Section 6 — *La capa cultural: cuando la regla permite pero el uso manda*
The capstone and the bridge to the shelved vocab section. The grammar engine *permits* both verbs for these, but real usage is locked and the meaning is culturally charged. This is where reading fails the learner.
- ***ambicioso*** — the headline case. Engine permits *estar ambicioso*; nobody says it. For a **person** it defaults to **ser** and means **grasping/greedy**, not "aspirational" (it softens for **things**: *un proyecto ambicioso* is neutral-positive). A false friend of *connotation*, not of grammar.
- **Connotation false friends on the same list:** *educado* = well-mannered (not "educated"); *sensible* = sensitive (not "sensible").
- **The *tener* work-around:** good judgment is a stable property, not a mood, so *estar sensato* is avoided and natives route to ***tener sentido común***. (Same instinct behind *tener valor/coraje*, *tener miedo* on the teacher's sheet.)
- **Register, not grammar:** *viejo* vs. *mayor* — *el hombre viejo* lands blunt-to-rude; *una persona mayor* is the respectful form; *mis viejos* swings affectionate for one's parents. Pure cultural usage, no ser/estar involved.
- NOTA-E (capstone): names the **two-axis split** explicitly — ser/estar is a rule-governed engine (Sections 1–5); connotation/register is a separate cultural layer where the real traps live — and points forward to the vocab section as "where we'll drill the locked words."

---

## 3. Core visual device — contrast pairs

The page is almost entirely minimal pairs, so the repeating unit is a **two-column contrast row: SER side | ESTAR side, with the meaning-delta called out.** Build this on the **existing `.decision-row` pattern** from the scaffold (two cells + center arrow on desktop, stacked with a left-accent border on mobile) — **no new CSS architecture**, just relabeled columns (SER / ESTAR) and a meaning-delta line beneath each pair. Each side carries its own Spanish example sentence (DM Serif Display) + short English `.example-en` gloss + 🔊 button, per scaffold.

If on build this proves too cramped for the longer examples (Section 4's passive pair especially), fall back to stacked `.grammar-card` example rows — but try the two-column contrast first, since the side-by-side *is* the pedagogy.

**This is the one place the spec leans on an existing pattern in a new way; flagged for sign-off in §8.**

---

## 4. NOTA plan (English layer — propose-before-drafting, per scaffold §2.2)

Five NOTAs proposed; prose not yet written, pending your nod on coverage and placement.

- **NOTA-A · Section 1 — "Drop permanent vs. temporary."** The heaviest block. Introduces classify-vs-situate and explains why the permanent/temporary shortcut breaks (with *fui terca* as the worked example). Several paragraphs.
- **NOTA-B · Section 2 — "¿Por qué parece que los rasgos negativos prefieren SER?"** *Daniel's requested note.* The pattern he spotted is real but the cause is one level down: **evaluative character labels are classifications, and classifications take ser regardless of polarity** — *cruel, egoísta, tacaño* but equally *generoso, leal, honesto*. What he noticed is a side-effect: the adjectives that genuinely admit estar are the **mood-ish** ones (*alegre, tranquilo, nervioso, orgulloso-de-algo*), and that set happens to skew neutral/positive — so *estar cruel hoy* sounds odd where *estás muy tranquilo hoy* doesn't. The negativity didn't pull ser; classification did, and the estar-capable set just isn't where the nasty traits live. ~2 paragraphs.
- **NOTA-C · Section 3 — events vs. objects** (short): the suceder/ubicarse reframe.
- **NOTA-D · Section 4 — the participle fix** (medium): "resultant state → estar," not "participle → estar"; ser+participio = passive; trait-participles classify → ser.
- **NOTA-E · Section 6 — the two-axis capstone** (medium): grammar engine vs. cultural layer, and the hand-off to the future vocab work.

---

## 5. Rioplatense policy (per scaffold)

Grammar and all core examples in **neutral Latin American Spanish**, **neutral-voice TTS only** (no dual-voice JS). The teacher's sheet is distinctly Rioplatense (*terca/inodoro*, *cagón*, *ciclotímico*, *jodido*); any example drawn from it that carries regional flavor gets `data-region="rioplatense"` as a textual flag and a light "así lo diría tu profe rioplatense" framing — **present but never the focus**, exactly as on prior pages. No lunfardo in the grammar spine.

---

## 6. Shelved — explicitly NOT in this build

These are deferred to a later vocab/práctica phase and are out of scope for this spec:
- **The 50-most-common-personality-adjectives list** (the teacher's table / `50_adjetivos` PDF) — becomes the backbone of a separate **vocab section**, not this grammar page.
- **Quizzes** of any kind (ser/estar drills, connotation traps, contrast-pair recall).
- Any **API-backed** feature (this is a static single-topic page; no `/api/claude`).

This build is the **info/grammar reference only.** Section 6 *names* the cultural layer and points at the vocab work to come, but does not host the word list or any drills.

---

## 7. Scaffold inheritance checklist (nothing re-specified here)

Taken verbatim from `03-page-standards.md`: one self-contained HTML file, inline CSS/JS, no frameworks, no API; DM Serif Display + Outfit; navy palette + one accent trio; favicon block; `← Volver al menú` → `../index.html`; Spanish-primary chrome with English NOTA layer; one rate bar near top; neutral-voice TTS; 600px responsive breakpoint; emoji policy (🔊 ⚡ ✕ only); full §19 self-check before delivery.

---

## 8. Decisions to confirm before build

1. **Section 5 pair set** — ship the **core six** (*listo, aburrido, rico, orgulloso, malo, vivo*), or pull in the extended set (*bueno, verde, despierto*)?
2. **Contrast device** — approve building the SER|ESTAR contrast row on the existing `.decision-row` pattern (§3)? It's the one place I'm reusing a scaffold pattern in a new role.
3. **Background pattern + accent trio** — pick from the scaffold's options, or want me to propose a pairing that reads distinct from Condicionales/Rasgos?
4. **Images** — propose **none** for v1 (the topic is carried by contrast pairs, and the teacher's PDF cartoons add little). The one candidate worth your call: a small schematic of the **acción → suceso → estado** pipeline in Section 4. Include it, or ship text-only and add later?
5. **Anchored section nav** — six sections is enough to warrant in-page jump links at the top. In, or keep it a clean scroll like the shorter single-topic pages?

---

# PART B — the personas decision framework
> Verbatim from `ser-estar-personas-marco-decision.md`

# Ser vs. Estar with Person-Adjectives — Decision Framework

**Purpose:** a runnable procedure for choosing *ser* or *estar* when the adjective describes a person's character, mood, or behavior. Scoped to people, not objects/events/passives.

---

## 0. First, kill the two heuristics that fail

- **"Permanent vs. temporary"** — dead. Temporariness is carried by **tense and aspect**, never by the verb choice. (See §5.)
- **"External judgment (ser) vs. internal feeling (estar)"** — dead. *Both* verbs deliver external judgments. *Está muerto* proves it: permanent, zero internal feeling, still *estar*. *Estar*'s "state" is a **condition you read off someone**, not an emotion they report.

**The one question that replaces them:**

> **Can I be *in* this, like a mood or an energy level?**

That single test sorts almost everything. The rest of this doc is the procedure built around it.

---

## 1. The decision procedure (four ordered steps)

```
START
  │
  ▼
[0] Does bare "estar + adj" hand me a DIFFERENT word?
      ├─ yes → MEANING-SHIFTER. Learn the pair; pick by which meaning you mean.
      │        (orgulloso, malo, aburrido, listo, rico, vivo, bueno, seguro…)
      └─ no ↓
[1] Can I be IN it — like a mood or an energy level?
      │   test: add "...hoy / últimamente." Does it mean "feeling X today"?
      ├─ yes → FELT STATE.
      │        ser = by nature  ·  BARE estar = right now   (both verbs, both bare)
      │        (vago, tranquilo, alegre, malhumorado, nervioso, sensible, tímido…)
      └─ no ↓
[2] Can I ACT it out in the moment?
      ├─ yes → PERFORMED BEHAVIOR.
      │        ser = the trait  ·  ESTAR SIENDO = right now / out of character
      │        (bare "está + adj" clunks or shifts — don't use it)
      │        (cruel, generoso, egoísta, educado, amable, valiente, terco, modesto…)
      └─ no ↓
[3] STANDING IDENTITY / COMMITMENT.
         ser only. No clean momentary form — even "estar siendo" resists.
         (leal, fiel, fiable, fidedigno, conservador, piadoso, ambicioso-as-trait…)
```

You never have to adjudicate "is this character or condition?" in the abstract. You just run the bare-*estar* sentence and see whether it survives, then ask the mood question.

---

## 2. The three buckets, in detail

### Felt states — *you are in them*
A mood, an energy level, a bodily/emotional weather you sink into and come out of.
- **Verb pattern:** *ser* = by nature · **bare *estar*** = right now. Both natural, both bare.
- *Es vago* (a lazy person) / *Está vago hoy* (can't be bothered today).
- *Es tranquilo* (calm type) / *Está tranquilo* (relaxed right now).
- *Es alegre* (cheerful person) / *Está alegre* (in good spirits today).
- **Tell:** *estar siendo* sounds wrong here (*?está siendo cansado*) — you don't *perform* a felt state, you're simply in it.
- These are the genuine "both verbs, both bare" personality words. This is the clean ser/estar bucket.

### Performed behaviors — *you do them*
An action you can enact in a single moment, even if it's also a settled trait.
- **Verb pattern:** *ser* = the trait (classify) · ***estar siendo*** = acting this way right now / out of character.
- *Es generoso* (generous by nature) / *Está siendo generoso por una vez* (being generous, for once).
- *Es educado* (well-mannered) / *Está siendo muy educado hoy* (being unusually polite today).
- *Es terco* (stubborn) / *Está siendo terco con esto* (being stubborn about this).
- **Tell:** bare *está + adj* clunks (*?está cruel*) or means something else (*está malo* = sick). The "right now" rides on **siendo**, never on swapping the verb.
- ***Estar siendo* is the escape hatch for this whole bucket.** When you want "right now" and bare *estar* won't go, reach for *siendo*.

### Standing identity / commitments — *neither felt nor performed-in-a-flash*
Ideologies, allegiances, dispositions, settled reputations.
- **Verb pattern:** *ser* only.
- *Es leal · es fiel · es fiable · es conservador · es piadoso · es ambicioso* (grasping, of a person).
- **Tell:** you can't *feel* loyal as weather, and you can't *do* loyalty in one gesture, so there's no clean momentary form. *?Está siendo leal* sounds off. Stay in *ser*.

---

## 3. Meaning-shifters — check FIRST, before anything else

These take both verbs grammatically, but the engine outputs **two different words**. Pick by meaning, not by mood. Don't run the rest of the procedure on these.

| Word | *ser* = | *estar* = |
|---|---|---|
| **orgulloso** | arrogant | **orgulloso de** = proud of (positive) |
| **malo** | bad / evil / naughty | sick |
| **aburrido** | boring | bored |
| **listo** | clever | ready |
| **rico** | rich (or "rich" as a quality) | tasty / cute |
| **bueno** | good-natured / good quality | tasty / good-looking |
| **vivo** | sharp, quick-witted | alive |
| **seguro** | safe, dependable | certain (note: *seguro de sí mismo* = confident is separate) |
| **soso** | a dull person | bland (food only) |
| **despierto** | sharp | awake |

> *malo* is the trap inside the trap: it's a shifter **and** a character word. *Es malo* = naughty kid (classify); *está malo* = sick (the shifted meaning already owns the bare-estar slot); *está siendo malo / se porta mal* = misbehaving right now (the thing you actually wanted). All three coexist.
>
> *educado* has the participle version of this: *es educado* = well-mannered / *está educado* = trained, raised (participle of *educar*) / *está siendo educado* = being polite right now.

---

## 4. The 50-adjective list, sorted

**Meaning-shifters (check by meaning):** *orgulloso, malo, aburrido / soso, bueno (in "es/está bueno").*

**Felt states (ser by nature · bare estar right now):** *perezoso/vago, tranquilo/relajado, alegre/jovial, malhumorado / de mal humor, sensible (also a false friend — see below), tímido, hablador/conversador, despreocupado, coqueta\*, loco/chiflado\*.*
> \* *loco* leans *estar* (*está loco* is the default; *ser loco* = wild/reckless by nature is rarer). *coqueta* is fuzzy — bare *está coqueta* works but it shades toward performed.

**Performed behaviors (ser = trait · estar siendo = right now):** *cruel, generoso, egoísta, amable, educado/cortés, valiente, terco/testarudo, modesto, honesto, encantador, descuidado, prudente/cauteloso, ingenuo, estricto/severo, discutidor, cobarde, comprensivo, simpático/agradable, presumido/creído/arrogante, travieso, charming-type traits.*
> *pesado* and *tacaño* live here but **leak into bare *estar*** (*qué pesado estás hoy*, *qué tacaño estás hoy*). Soft edge — see §6.

**Standing identity / commitment (ser only):** *leal/fiel, fiable/confiable, digno de confianza/fidedigno, conservador, convencional, piadoso, ambicioso, trabajador, de mente abierta / cerrada, introvertido, sensato (→ routes to* tener sentido común*).*

**Connotation false friends (grammar is the easy part; meaning is the trap):** *sensible* = sensitive, not "sensible"; *educado* = well-mannered, not "educated"; *ambicioso* (of a person) = grasping, not "aspirational."

---

## 5. Where "temporariness" actually lives

This is the spine. Temporary readings come from **tense and aspect**, never from switching *ser* → *estar*:

- **One bounded past occasion:** *ser* + **preterite**. *Ayer fui terca* = "that one time, I acted stubborn" — not permanently stubborn. (*Ayer fui valiente* on your sheet is the same move.)
- **Acting out of character, present:** ***estar siendo*** + adj. *Está siendo terco* = "he's being stubborn right now."
- You do **not** reach for *estar* to soften a trait. The softening is in the preterite or the progressive.

---

## 6. Soft edges (so the buckets don't feel like walls)

- **Lexical leakage:** a few character words accept bare *estar* anyway — *qué tacaño estás hoy*, *qué pesado estás hoy*. The bucket lines are tendencies, not laws. When unsure, *estar siendo* is always safe for "acting this way now."
- **The real underlying variable is a gradient,** not three boxes: *how much does this trait overlap with a felt state?* High overlap (*vago, cansado, alegre*) → bare *estar*. Zero overlap but actable (*cruel, generoso*) → *estar siendo*. Zero overlap, not actable (*leal, fiable*) → *ser* only. The three buckets are just the gradient chopped into usable pieces.
- **Region:** *de mala leche, jodido, cagón, ciclotímico, terca/inodoro* are Rioplatense/colloquial flavor from the source sheet — fine to recognize, not the neutral default.

---

## 7. The whole thing in one breath

> Does *estar* give a different word? → it's a shifter, pick by meaning.
> Can I be *in* it like a mood? → felt state: *ser* nature / bare *estar* now.
> Can I *act* it out? → performed: *ser* trait / *estar siendo* now.
> Neither? → *ser* only.
> And "temporary" is never a verb-swap — it's the preterite (*fui terca*) or the progressive (*está siendo*).

---

*Maps onto the page spec: this is the engine behind NOTA-A (kill the heuristics) and Section 2 (rasgo vs. estado). The felt-state / performed / standing split is a sharper version of "clasificar vs. situar" for the people-adjective case specifically.*
