# Adverbios Page — Planned Additions
### Created: July 2026
### Status: SPEC — content not yet drafted
### Target file: `topics/adverbios.html`

---

## Summary

The adverbios page covers *-mente* formation and fixed locuciones adverbiales organized by preposition. Three structural gaps were identified in the **formation** story, plus two smaller fixes to existing content.

---

## 1. New Card — Adjetivos adverbializados (bare adjective as adverb)

**What it is:** Adjectives used in bare masculine singular form to modify a verb, replacing *-mente*. The most informal/spoken strategy for forming manner adverbs.

**Key grammar point:** The adjective does NOT agree with the subject — it freezes in masculine singular. *Ella habla claro*, not *clara*. This invariability is what marks it as adverbial rather than predicative.

**NOTA point (English):** The agreement boundary is blurry. Some adjectives shade back toward predicative when speakers make them agree (*ella vive tranquila* = she lives [in a state of being] calm, vs. *ella vive tranquilamente* = she lives calmly). With *fijo, duro, claro, rápido, limpio*, the invariable adverbial reading is dominant and unambiguous. Test: if it agrees with the subject, it's predicative; if it doesn't, it's adverbial.

**Core examples (cluster around physical actions and speech):**

| Bare adjective | Meaning | -mente equivalent |
|---|---|---|
| hablar claro | to speak clearly | claramente |
| hablar alto / bajo | to speak loudly / softly | — (en voz alta / baja) |
| hablar fuerte | to speak loudly | fuertemente |
| mirar fijo | to stare fixedly | fijamente |
| trabajar duro | to work hard | duramente |
| jugar limpio / sucio | to play fair / dirty | limpiamente (rare) |
| pisar firme | to step firmly | firmemente |
| respirar hondo / profundo | to breathe deeply | profundamente |
| pensar rápido | to think fast | rápidamente |
| caminar lento | to walk slowly | lentamente |
| cortar fino | to cut thin | finamente |
| pegar fuerte | to hit hard | fuertemente |
| cantar bonito | to sing beautifully | — (bonitamente virtually unused) |

**Register:** Most informal — spoken Spanish's favorite shortcut. In formal writing, switch to *fijamente* or *de manera fija*.

**Placement on page:** New Card 3, immediately after current Card 2 ("Por qué los hablantes los evitan"). It's the most radical simplification of *-mente*, so it makes sense as the first alternative strategy shown.

**Triggered by:** Reading *mirando fijo* in a Comprensión Lectora story.

---

## 2. New Card — *De manera / de forma / de modo* + adjective

**What it is:** A productive template that can replace virtually any *-mente* adverb. Three interchangeable heads:

- *de manera* + adjective (most common in general writing)
- *de forma* + adjective (equally common, slightly more technical)
- *de modo* + adjective (a bit more formal/literary)

The adjective agrees with the noun: *de manera clara* (fem), *de modo claro* (masc).

**Key grammar point:** Unlike the fixed locuciones in the *de* card (Card 4 → renumbered to Card 6), this is a **live generative template** — you can apply it to almost any adjective. It's not a list to memorize; it's a machine for building adverbs.

**NOTA points (English):**
- This is the middle register — more polished than bare adjective, less heavy than *-mente*. Very common in journalism, narrative prose, professional communication.
- Cross-reference to false friends card: *de forma interesante* is the correct "interestingly" that avoids the *interesadamente* trap from Card 8 (renumbered to Card 10).

**Core examples:**

| Template phrase | Meaning | -mente equivalent |
|---|---|---|
| de manera clara / de forma clara | clearly | claramente |
| de manera directa | directly | directamente |
| de manera inmediata | immediately | inmediatamente |
| de forma gradual | gradually | gradualmente |
| de modo eficaz | effectively | eficazmente |
| de forma simultánea | simultaneously | simultáneamente |
| de manera voluntaria | voluntarily | voluntariamente |
| de forma interesante | interestingly | — (interesadamente = self-interestedly) |

**Register:** Written/polished — journalism, academic, narrative prose. Avoids *-mente* bulk while maintaining precision.

**Placement on page:** New Card 4, after the bare-adjective card. Teaching arc: Card 1 (*-mente* formation) → Card 2 (why speakers avoid it) → Card 3 (most casual alternative: bare adjective) → Card 4 (middle-register alternative: *de manera/forma/modo*) → Cards 5+ (fixed locuciones catalog).

**Triggered by:** Reading *de manera inmediata* in a Comprensión Lectora story. Page had *de inmediato* but not this construction.

---

## 3. New Card — Placement rules (where adverbs go in the sentence)

**What it is:** The page's subtitle says "formación y registro" and the index categorization spec lists the adverbios grammar bucket as "formation (-mente), placement" — but placement is never explicitly taught. The page shows correct placement through examples but never states the rules.

**Why it matters for B2:** English adverb placement is much more flexible. Default English instinct will put manner adverbs in wrong positions.

**Core rules (compact — one card or large NOTA):**

1. **Manner adverbs follow the verb.** *Habla claramente*, not *claramente habla* (fronting is possible for emphasis but marked/literary).
2. **Sentence adverbs lead the clause + comma.** *Por suerte, llegamos a tiempo.* / *En realidad, no me molesta.*
3. **Locución vs. -mente doesn't change placement.** *Con cuidado* goes in the same slot as *cuidadosamente*.
4. **Compound tenses: adverb goes after the participle, not between auxiliary and participle.** *Ha trabajado duramente*, not *ha duramente trabajado*.

**Placement on page:** Final card before the decision guide — "now that you know how to form them, here's where they go."

---

## 4. Small Fix — *Sin* entries added to existing *con* card

**What it is:** The *con* card teaches *con cuidado, con rapidez, con calma* but never mentions that *sin + noun* is the natural negation and produces equally common adverbial phrases.

**Not a new card** — fold 3–4 *sin* entries into the existing *con* card as a "y su reverso" mini-table or small addition to the table.

**Entries to add:**

| Locución | Meaning | -mente equivalent |
|---|---|---|
| sin duda | undoubtedly | indudablemente |
| sin querer | unintentionally | involuntariamente |
| sin parar | nonstop | incesantemente (rare) |
| sin embargo | however | — (sentence adverb, no -mente) |

**Note:** *sin embargo* is included because it's a *sin* locución, but it's a sentence adverb / connective, not a manner adverb. Could note this distinction or omit it to keep scope tight. It also appears on the conectores page (when built).

---

## 5. Small Fix — *-mente*-only adverbs acknowledged in decision guide

**What it is:** The decision guide has a row for "no *-mente* form exists → locución obligatoria" but never states the reverse: some adverbs have **no natural locución** and *-mente* is the only option regardless of register.

**Examples:** *probablemente, obviamente, sinceramente, precisamente, básicamente, personalmente*. These are mostly sentence-level modifiers, not manner adverbs — which is why they don't fit locución templates.

**Implementation:** A new row in the decision guide or a NOTA. Closes the loop — the page currently risks implying every *-mente* adverb has a lighter alternative.

---

## Revised Card Numbering (after additions)

| # | Topic | Status |
|---|---|---|
| ① | La formación en *-mente* | Existing (unchanged) |
| ② | Por qué los hablantes los evitan | Existing (unchanged) |
| ③ | **Adjetivos adverbializados** | **NEW** |
| ④ | ***De manera / de forma / de modo* + adj** | **NEW** |
| ⑤ | *con* + sustantivo (+ *sin* addition) | Existing (was ③, *sin* entries added) |
| ⑥ | *de* + sustantivo | Existing (was ④) |
| ⑦ | *en* + sustantivo | Existing (was ⑤) |
| ⑧ | *por* + sustantivo | Existing (was ⑥) |
| ⑨ | *a* + sustantivo / adjetivo | Existing (was ⑦) |
| ⑩ | Falsos amigos en *-mente* | Existing (was ⑧, add *de forma interesante* cross-ref) |
| ⑪ | Variación regional | Existing (was ⑨) |
| ⑫ | **Placement rules** | **NEW** |
| — | Decision guide | Existing (add *-mente*-only row) |

---

## Register Gradient (the teaching thesis, updated)

The completed page should establish a four-tier register gradient for manner adverbs:

1. **Bare adjective** (*habla claro*) — most informal, spoken
2. **Fixed locución** (*con cuidado, de repente, a ciegas*) — spoken/everyday, sometimes the only option
3. ***De manera/forma/modo + adj*** (*de manera clara*) — written, polished, middle register
4. ***-mente*** (*claramente*) — formal, technical, legal

---

## Out of Scope

These were considered and explicitly excluded from this page:

- **Degree adverbs** (*medio, bastante, demasiado*) — different topic
- **Comparative adverb forms** — different topic
- **Gerund as manner modifier** (*salió corriendo*) — separate construction, would belong on a gerundio page
- **Adverbs of place/time** — this page is scoped to adverbs of manner and sentence adverbs
