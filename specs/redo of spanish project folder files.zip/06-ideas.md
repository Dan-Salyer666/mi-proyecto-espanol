<!-- FILE ROLE ------------------------------------------------------------
WHAT THIS IS:  The dumping ground. Every idea that is not being built lives
               here as a short block. THIS IS AN INDEX, NOT A VAULT.
BELONGS HERE:  What / where it came from / shape. Three lines.
DOES NOT:      Raw material longer than a paragraph -> 07-materials.md, same
               slug. If this file stops being scannable it has failed.
NOTHING HERE IS SCHEDULED. An idea sits here indefinitely at no cost.
LAST UPDATED:  2026-08-23 (folder restructure; 06-ideas.md dissolved in)
------------------------------------------------------------------------ -->

# 06 — Ideas

**To add an idea:** a new `###` block below. Never a new file. Three lines minimum — *what*, *where it came from*, *shape*. If you have more than a paragraph of material, paste it into `07-materials.md` under a matching `## slug` and point at it.

**To promote an idea:** Daniel picks it **and** a TALLER slot is free. Promotion **moves** the text out of here and out of `07` into `TALLER-<slug>.md`. Never copies.

---

## Next up

Daniel's list. At most five. Only Daniel edits this.

1. *(empty — all three slots are currently filled)*

**Slots in use:** `TALLER-rendir.md` · `TALLER-ser-estar.md` · `TALLER-medida-medio.md` (+ standing `TALLER-clase.md`)

---

## Specced but not slotted

These have full build specs already written. Promotion is cheap — the text is ready.

### `gradacion` — Gradación e intensidad
- **What:** Spanish gives a predicate one intensity slot; if the word already fills it, *muy/mucho* is locked out. ✗*muy delicioso* and ✗*me encanta mucho* fail for the same reason. Answers the useful question: if not *muy*, then what?
- **Where from:** class, 2026-07-30 — the teacher's *gustar* ladder (*me gusta → un poco → bastante → mucho → muchísimo → **me encanta***).
- **Shape:** static page, Gramática → Estructuras y patrones.
- **Before building:** must be resolved against `roadmap-grados` below — same territory approached from two directions. Build one page, not two.
- **Material:** `07` § `gradacion`. Its §8 teacher-verification clause is void.

### `distancia-psicologica` — atenuación, future of conjecture
- **What:** softening and distancing constructions; the future used for conjecture.
- **Where from:** a Comprensión Lectora story threw it up.
- **Shape:** static page. Slug unconfirmed, §9 decisions open.
- **Material:** `07` § `distancia-psicologica`.

### `poder` — Verbos en Profundidad #2
- **What:** second entry in the series, following the *tener* pattern and its frame-chip system.
- **Where from:** roadmap. Hub already exists; no dependencies left.
- **Shape:** static page pair, `topics/verbos-en-profundidad/`.
- **Material:** `07` § `poder`.

### `adverbios-adds` — three gaps + two fixes
- **What:** additions to the live 66 KB `topics/adverbios.html` — three gaps in the formation story, two corrections.
- **Where from:** audit of the live page.
- **Shape:** addition to an existing page. Smallest real build on this list.
- **Material:** `07` § `adverbios-adds`.

### `entrenador-admin` — data admin UI
- **What:** add and manage verbs through a form with AI-assisted generation, synced via Drive.
- **Where from:** discussion; agreed, never built.
- **Shape:** app work on the Entrenador. Phased.
- **Material:** `07` § `entrenador-admin`.

### `pronunciacion` — pronunciation trainer
- **What:** Azure Speech SDK scoring via a Netlify function. Single AccuracyScore (no prosody for Spanish), lexical gate, colour-coded feedback, hysteresis ladder, five Sin Ver pools.
- **Where from:** Daniel.
- **Shape:** app. Six phases, external API, new serverless function — a multi-session build.
- **Status:** **back-burnered 2026-08-23.** Not soon.
- **Material:** `07` § `pronunciacion`.

---

## Needs a spec written first

From the old `06-ideas.md`. Full detail and source-file references in `07` § `roadmap-detalle`.

### `subjuntivo` — the tentpole
- **What:** overview page + three *disparadores* subpages. The biggest missing thing on the site.
- **Where from:** roadmap. **Shape:** static hub, phased. Source notes are in the ideas zip, not this folder.

### `conectores` — causa y consecuencia hub
- **What:** logical connectors, with the mental-image treatment.
- **Where from:** raw notes Daniel collected. **Shape:** hub. The only Tier-B idea whose raw material is already here.
- **Material:** `07` §§ `conectores`, `conectores-imagenes`.

### `tres-zonas-se`
- **What:** the three zones of *se*. **Where from:** roadmap; source material identified, nothing written. **Shape:** static page, Gramática.

### `roadmap-grados` — Grados y cantidades trio
- **What:** *poco* / *como para* / *tan-tanto*. **Where from:** roadmap §6. **Shape:** page or trio — **overlaps `gradacion` above; resolve as one.**

### `adjetivos-hub` · `pronombres-hub`
- **What:** two hubs, each merging 2–5 existing source files. **Where from:** roadmap. **Shape:** hubs.

### `standalones` — four small pages
- **What:** *de* vs. *a partir de* · elisión de *que* · *hasta* · the *venir/salir* trap. Three are rebuilds of old Gemini HTML. **Where from:** roadmap. **Shape:** small static pages.

### `verb-explorers` — quedar, echar, llevar, meter, dar
- **What:** five more Verb Depth Explorers on the `poner.html` pattern (Preact+htm, radial tree → family view → word modal). **Where from:** roadmap. **Shape:** interactive pages.

### `revision-lectora` — review portal
- **What:** browse, filter, rate, replay, delete archived Comprensión Lectora quizzes from Drive. Comprensión Lectora is the corpus generator; this is the curator. Can show provider and seed per story. **Where from:** roadmap + CL state. **Shape:** app.

### `cl-modulos` — more story modules
- **What:** Rom-com, Romántica, Drama, Sci-fi (Daniel's interest), plus Realismo mágico, Histórica, Fábula, Cotidiana, Distopía, Terror. Append to `MODULE_SPECS` + a button — the work is the spec, not the code. Pick 2–3, write deliberately, field-test on both providers. **Shape:** data + prompt work.

### `paginas-dinamicas` · `favicon`
- **What:** infrastructure items carried over from the roadmap. **Material:** `07` § `roadmap-detalle`.

---

## Site-structure ideas

### `reagrupar-confundibles` — implement *Palabras que se confunden*
- **What:** create the Vocabulario sub-bucket and move `rasgos.html`, `tropiezos-con-p.html`, `palabras-tramposas.html` into it alongside the new medida/medio page. See `02-site-map.md` → Part B.
- **Where from:** Daniel, 2026-08-23 — noticing that several pages exist for the same reason (words he misreads) and are currently filed by their material instead.
- **Shape:** index restructure. Flat bucket for now; probably a hub later.
- **Held for:** the wider site-arrangement conversation Daniel wants to have, which also covers removing and moving other pages.

### `ya-fase-etapa` — finish the half-applied addendum
- **What:** *fase* / *etapa* additions to `topics/ya-todavia-aun.html`. The *ya que* half is already live (5 hits); this half is not (0 hits, verified 2026-08-23).
- **Shape:** small addition to an existing page. **Material:** `07` § `ya-fase-etapa`.
