<!-- FILE ROLE ------------------------------------------------------------
STANDING TALLER — outside the cap of three. Class notes are a recurring
process, not a one-off build, so they get a permanent file.

PART 1 (the procedure) never changes and is never cleared.
PART 2 (the current class) is cleared when that sheet ships.

A class never competes with a build for a slot.
LAST UPDATED:  2026-08-23 (created in the folder restructure)
------------------------------------------------------------------------ -->

# TALLER — Class notes

---

# PART 1 — The procedure

This half is permanent. Read it at the start of every class-sheet build.

## What a class sheet is

A **summary** of one Spanish class, filed by *where the content came from* rather than by what the content is. A single class routinely covers a noun set, a pragmatics point and a verb, so it cuts across the Vocabulario/Gramática word-class axis entirely — which is why Notas de Clase is a top-level hub of its own.

**File:** `topics/clase-de-espanol/clase-YYYY-MM-DD.html`. Flat — no subpages.
**Index:** `hub-clases`, `hub-section` blocks by year, newest first, no badge on link items. Icon 📝, rose `#f472b6`. Count word: `clase` / `clases`.
**Assets:** `recursos/clase-YYYY-MM-DD/` for PDFs and images.

## The pressure valve — how sheets stay small

A class sheet is never an exhaustive treatment. When a topic outgrows the summary:

1. The sheet keeps a short summary and links **out** to a full page in Vocabulario or Gramática.
2. If that page doesn't exist yet, the sheet **still ships complete** — the link renders as a muted `.topic-link.pending` block with no `href`, and the topic gets an idea block in `06-ideas.md`.
3. **Links are one-way.** Topic pages never link back to a class sheet. They stay independent of when Daniel happened to learn the thing.

**Outgrowth means promotion, never in-place expansion.** If a card is turning into a page, it becomes a page.

## Provenance chips

Every card carries one, so a cold read can tell what the teacher actually said from what was built afterwards:

- **`EN CLASE`** — the teacher said it, in this class.
- **`MATERIAL`** — from the material she handed out.
- **`AMPLIACIÓN`** — added afterwards by Daniel or Claude. Scaffolding, not attestation.

Track topic origination too — whether the teacher raised it or Daniel did. It changes how much weight the item carries later.

## Preguntas para la profe

Every sheet carries this block. **It is a notepad with no deadline attached, not a work queue.**

- Nothing reads it back as a task, and no build is gated on it.
- Questions get slipped into class organically, individually, when there's room. The teacher knows Daniel uses AI but finds it professionally sensitive, so a printed list of AI-generated questions is not the move.
- An unanswered question can sit there forever at no cost. That is the point.
- When one is answered, the content changes and the question comes out.

## Content confidence

Uncertainty is annotated at the point of the claim with `USO VARIABLE` / `REG: incierto` / `NO ATESTIGUADO`, and the sheet ships. Never `? por confirmar` — a procedural marker rots when the action doesn't happen. See `01-briefing.md`.

The teacher is Buenos Aires–based, so class content arrives Rioplatense. The sheet records what she said; where it is regional, badge it, and keep the surrounding page neutral. Voseo and Argentine forms stay tagged and confined, and TTS stays neutral.

## Landing page

Not yet. Once the class list passes roughly **8 entries**, build `topics/clase-de-espanol/index.html` and change the index block to show the 6 most recent plus a `Ver todas las clases →` link. Currently 2 sheets.

## Session-end for a class build

When the sheet deploys: clear PART 2 of this file, add any promoted topics to `06-ideas.md`, and update the class count in `02-site-map.md`.

---

# PART 2 — Current class

**Status: empty.** No class sheet in progress as of 2026-08-23.

The most recent shipped sheet is `clase-2026-08-18.html` (56 KB, 14 cards). Its build spec has been retired — the page is the record.

One thread carried over from it: the ***de* vs. *por* emotion distinction** is an open *Pregunta para la profe*. Card ① of that sheet may be rewritten depending on her answer. No action until then.

<!-- When the next class happens, fill in below:
## Class YYYY-MM-DD
### Raw material
(what she handed out, what was said, photos/PDFs in recursos/)
### Card plan
(one line per card + its provenance chip + whether it links out)
### Preguntas para la profe
### Promoted topics
(anything outgrowing a card -> idea block in 06)
-->
