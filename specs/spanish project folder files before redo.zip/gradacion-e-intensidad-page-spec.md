# Gradación e intensidad — Page Spec

> **Status:** PRELIMINARY. Architecture and scope only. Card contents, NOTA text,
> example sentences, images, accent trio, and background pattern are all **not yet
> settled** — this doc exists to hold the shape while the details get hashed out.
> **Do not build from this as-is.** Content draft comes first, per house workflow.
>
> **Origin:** Spanish class, July 30 2026. Teacher flagged \**me encanta mucho* and laid
> out the gustar ladder (*me gusta → un poco → bastante → mucho → muchísimo → me encanta*,
> and nothing above *encanta*). Recognized as the same phenomenon as the existing
> *adjetivos no graduables* page, but operating across far more than adjectives.

---

## 1. Núcleo en una línea

**Spanish gives a predicate one intensity slot.** If the word already fills that slot —
lexically, morphologically, or constructionally — the syntactic intensifier (*muy* /
*mucho*) is locked out. \**Muy delicioso* and \**me encanta mucho* fail for the identical
reason.

The page's job is to make that one principle visible across word classes, and — more
usefully — to answer the question the prohibition raises: **if not *muy/mucho*, then what?**

---

## 2. Placement

- **Section:** Gramática → **Estructuras y patrones**
  - Rationale: cross-cutting by nature (verbs, adjectives, adverbs, morphology). Does not
    belong under Adjetivos, which is the whole point of building it separately.
- **File:** `topics/gradacion-e-intensidad.html`
- **Back nav:** `../index.html` → `← Volver al menú`
- **Index bucket:** `gram-estructuras` (existing sub-hub — increment `sub-hub-count`)
- **Build spec:** standard `single-topic-page-spec.md`. Static, no API, neutral TTS.

**Title candidates** (pick later):
1. *Gradación e intensidad* — subtitle: *Un solo espacio para el grado*
2. *Un solo espacio para la intensidad*
3. *Lo que no admite «muy»*

---

## 3. Relationship to the existing Adjetivos page

**Nothing on the existing page gets torn up or moved.** It stays as the adjective-specific
deep dive.

- This page carries **one truncated adjective card** (see ⑦) — the principle restated for
  adjectives in a few lines, a short illustrative list, and an explicit link out.
- Adjective examples (*delicioso, enorme, horrible*) may appear **as illustration** in the
  general cards (② especially), since the principle can't be taught without them. That's
  fine — the truncated card is the formal handoff, not the only mention.
- **Adjetivos relacionales** (\**energía muy nuclear*, \**informe muy mensual*) —
  recommend these stay **entirely** on the adjectives page. They block *muy* for a
  different reason (classifying, not qualifying — no scale at all), and folding them in
  here muddies the one-slot thesis. Mention in passing at most.
- Add a short pointer NOTA on the **existing** adjectives page directing up to this one.
  Separate edit, separate deploy — not bundled into this build.

---

## 4. Proposed card breakdown

Eight cards + decision guide. Count is negotiable; ③ and ⑥ are the load-bearing ones.

### ① El principio: un solo espacio
The one-slot thesis stated plainly, with the two flagship failures side by side
(\**muy delicioso* / \**me encanta mucho*) to establish that this is one phenomenon and
not two coincidences. Short card. Sets up everything below.

### ② Léxico elativo — la intensidad ya viene dentro
Words that *are* the intensified version of a plainer word. Paired presentation
(plain → elative) so the "already contains *muy*" claim is visible rather than asserted.

Sample pairs: *bueno → excelente · grande → enorme · malo → atroz · rico → delicioso ·
bonito → precioso · sorprendente → asombroso*. Verbs get their own card (③) but a
one-line forward reference belongs here.

### ③ Verbos de emoción: la escala del gusto — **flagship card**
The teacher's ladder, then the generalization: **neutral psych-verb + elative
counterpart** is a systematic pattern, not a *gustar* quirk.

The ladder as given in class:
> *me gusta · me gusta un poco · me gusta bastante · me gusta mucho · me gusta muchísimo ·* **me encanta**

Then the pair table (draft inventory — verify each before content sign-off):

| Neutral (admite *mucho*) | Elativo (lo bloquea) |
|---|---|
| gustar | **encantar**, fascinar |
| interesar | **apasionar**, fascinar |
| querer | **adorar**, idolatrar |
| no gustar / disgustar | **detestar**, aborrecer |
| molestar, fastidiar | **indignar**, enfurecer |
| dar miedo, asustar | **aterrar**, aterrorizar |
| sorprender | **asombrar**, pasmar |
| alegrar | **entusiasmar**, emocionar |
| cansar | **agotar**, extenuar |

Plus a short non-psych tail to show the pattern isn't confined to emotion verbs:
*llover → diluviar · comer → devorar · romper → destrozar · destruir → arrasar ·
pedir → suplicar · reír → carcajearse*.

### ④ Escalas cerradas — lo que llega al tope
Different mechanism, same surface effect: the property has a built-in ceiling, so degree
is meaningless. *muerto, lleno, vacío, perfecto, único, infinito, embarazada*; verbs
*morir, terminar, acabar, aniquilar*. Key payoff: these take **completamente / totalmente**,
not *muy* — which is the bridge into ⑥.

### ⑤ Ya intensificado por la forma
Cases where morphology or a fixed expression fills the slot:
- **-ísimo** — \**muy buenísimo*, \**muy carísimo*
- **Prefijos** — *rebueno, superconocido, archiconocido, hipersensible*
- **Comparativos sintéticos** — \**más mejor*, \**muy mejor* (but ✓ *mucho mejor* — see ⑧)
- **Locuciones precargadas** — *muerto de hambre, hecho polvo, a más no poder*

### ⑥ Qué se dice en su lugar — **second load-bearing card**
The correction to how this is usually taught: *no graduable* does **not** mean *no
intensificable*. It means a **different intensifier**.

- **Reforzadores de veracidad:** *realmente, verdaderamente, absolutamente, totalmente,
  completamente, simplemente, francamente*
  → *absolutamente delicioso · realmente me encanta · me encanta de verdad*
- **Para escalas cerradas:** *completamente lleno, totalmente vacío*
- **Por encima de *encanta*, la lengua se vuelve perifrástica:**
  *me vuelve loco · me muero por · soy fanático de · no puedo vivir sin*
  → This is the actual top of the ladder and the practical payoff of the whole page.

### ⑦ Adjetivos — resumen y enlace *(truncated by design)*
Three or four lines: same principle, applied to adjectives; a compact illustrative list;
then the link out to the existing page for the full treatment (including relacionales).
Deliberately thin. Uses the `.subpage-links` block styling or a variant — decide at build.

### ⑧ Trampas vecinas
Two adjacent errors that live in the same conversation and are worth catching here:
- ***muy* vs *mucho* distribution** — *muy* modifies adjectives/adverbs, *mucho* modifies
  verbs/nouns. \**Muy me gusta*. And the exception: *mucho* **does** modify synthetic
  comparatives — *mucho mejor* ✓ / \**muy mejor* ✗.
- **La escala negativa corre con *nada*, no con *mucho*** — *no me gusta nada* is the
  **intensified** negative; *no me gusta mucho* is a **mitigated** one. Asymmetry worth
  its own row.

### Decision guide (optional, recommend include)
Shape: *¿Puedo decir «muy/mucho» aquí?* → three or four rows routing to
*sí* / *no, usá **completamente*** / *no, usá **realmente*** / *no, cambiá de palabra*.

---

## 5. NOTA\* candidates — proposed, not approved

Per house rules these are a discussion, not a unilateral insert. Candidates, in rough
priority order:

1. **The register caveat (recommend: include).** *Me encanta muchísimo* does occur in
   casual Latin American speech and online. The teacher's rule is the right rule to
   internalize and to write by, but it's a **register line, not a grammaticality wall**.
   Daniel reads above his level and will meet it in the wild — tag it honestly rather
   than pretending it doesn't exist. Sits in ③.
2. **Two mechanisms, one symptom.** Why elative lexemes (②/③) and closed scales (④) are
   genuinely different things that produce the same blocked slot. Structural clarity —
   the kind of distinction that earns its keep. Sits between ③ and ④, or opens ④.
3. **Why English hides this.** English lets *very* stack much more freely (*very
   delicious* is unremarkable), so the constraint is invisible from the L1 side and has
   to be learned as a positive rule. Short. Sits in ①.
4. **The *mucho mejor* exception explained** — why *mucho* survives where *muy* dies on
   synthetic comparatives. Possibly too fine-grained for a NOTA; may just be a table row
   in ⑧.

---

## 6. Scope boundaries

**In scope**
- The one-slot principle and its four sources
- The full alternate-intensifier inventory (this is the reason the page exists)
- The *gustar → encantar* ladder and the psych-verb pair pattern
- *muy* vs *mucho* distribution; the *nada* negative asymmetry

**Out of scope**
- Full treatment of **degree adverbs** (*medio, bastante, demasiado, apenas*) — the
  `adverbios` spec explicitly punted these as "different topic." This page uses
  *un poco / bastante / muchísimo* as **rungs on the ladder** in ③ but does not take on
  the degree-adverb system. If that page ever gets written, this one links to it.
- Comparative and superlative **syntax** (*más… que*, *el más… de*) — separate topic
- **Adjetivos relacionales** — stays on the adjectives page (see §3)
- **Aumentativos / diminutivos** as intensity (*-azo, -ote*) — adjacent, but that's a
  morphology topic. Flag as a possible future cross-link, not content here.

---

## 7. Cross-links to add later (each a separate, intentional edit)

- Existing **adjetivos no graduables** page → pointer NOTA up to this page
- **Adverbios** page → link, if/when the degree-adverb additions land
- Any **gustar-class verbs** page → link into card ③
- `index.html` → new `link-item` in `gram-estructuras`, count incremented

---

## 8. Deferred — decide before content draft

- [ ] Final title + Spanish subtitle
- [ ] Accent color trio and background pattern (per `single-topic-page-spec.md` §14)
- [ ] Card count — is ⑧ one card or two? Is ① too thin to stand alone?
- [ ] **Does card ③ stay here, or does the psych-verb ladder graduate to its own page**
      in the Verbos en Profundidad track, with a summary + link left behind? Open.
- [ ] Images — none proposed yet. A single "one slot, already occupied" visual for ①
      could carry the whole thesis, but nothing is committed.
- [ ] Guía Rápida modal — plausible fit (a *muy / mucho / completamente / realmente*
      cheat sheet). Decide once card content firms up.
- [ ] Verify every verb pair in ③ against RAE + teacher before content sign-off. Several
      of the elative claims (*me fascina mucho*, *odio mucho*) sit closer to the
      acceptability line than others and need checking, not asserting.

---

*End of preliminary spec. Not build-ready. Next step: content draft for sign-off.*
