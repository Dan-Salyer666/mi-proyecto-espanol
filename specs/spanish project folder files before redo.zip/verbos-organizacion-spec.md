# Mi Proyecto Español — Verbos: Going-Forward Organization
### Created: June 2026
### Status: ACTIVE — governs how new verb pages slot into Vocab → Verbos
### Amended: August 2026 — §4 rewritten to the folder model when the hub shipped with *tener*
### Companion to: `index-categorization.md`, `single-topic-page-spec.md`, `page-roadmap.md`

---

## 1. Purpose

Two shapes of verb page now exist on the site, and they grow at different rates. This doc decides where each one lives so the **Vocab → Verbos** sub-bucket stays a short, scannable list instead of turning into a wall of individual links. Hand this file to any future session alongside `index-categorization.md` and a new verb page slots in without re-litigating the structure.

The whole point: **one extra click is cheaper than a list of twenty.**

---

## 2. The two content shapes

**A. Single-verb deep dive** — one verb, many contexts and frames.
- Examples: *esperar* (wait/hope/expect); the planned explorers for *quedar, echar, llevar, meter, dar*; eventually a rebuilt *poner*.
- Source format: a `.md` like `esperar-uso.md` — numbered frames, NOTA points, example sentences, frame/contrast tables.
- **Growth: unbounded.** You keep finding verbs that earn their own page. This is the list that explodes if left flat.

**B. Thematic cluster** — a small *named set* of verbs grouped by what they **do**.
- Examples: *Tema del Movimiento*, *Los Verbos de Demostración*, *Prestar y Pedir Prestado*, and the new breaking/damaging set (*romper, dañar, estropearse, averiarse, pudrir(se)…*).
- Each is a meaty multi-verb page that takes real work to assemble.
- **Growth: bounded and slow.** There will never be twenty of these.

---

## 3. The rule

| Shape | Home | Why |
|---|---|---|
| **Single-verb deep dive** | Child of **one hub page** | Unbounded set → hub it, so the index shows one entry no matter how many verbs |
| **Thematic cluster** | **Flat link item** in Vocab → Verbos | Bounded, slow-growing → an extra click would be over-engineering |

---

## 4. The hub: "Verbos en Profundidad"

One parent page collects every single-verb deep dive. **Shipped August 2026 with *tener* as the first child.**

### Folder model

The hub and all its children live in **one dedicated folder**. This was adopted when the hub shipped, because `topics/` was already ~25 files and this section grows without limit.

```
topics/verbos-en-profundidad/
    verbos-en-profundidad.html     ← hub
    tener.html
    tener-estructural.html         ← flat sibling extension
    (quedar.html, echar.html, poder.html … as built)
```

- **Hub file:** `topics/verbos-en-profundidad/verbos-en-profundidad.html`. The name repeats the folder deliberately — an `index.html` would give a cleaner URL but produce multiple identically-named files in the editor, which was judged the worse trade.
- **Children are named by verb alone.** The folder already carries the family name; `verbos-en-profundidad-tener.html` says it twice.
- **Hyphens, never underscores.** Every path on the site is hyphenated; one underscore folder becomes a permanent guessing game.
- **Reorganization is additive only.** No existing page moved, no existing link was rewritten. A site-wide `topics/` reorganization was explicitly considered and declined — it is a high-risk, zero-visible-change deploy and must never ride along with a content build.

### Paths

| From | To | Path |
|---|---|---|
| verb page | assets | `../../assets/…` |
| verb page | hub | `verbos-en-profundidad.html` |
| verb page | main menu | `../../index.html` |
| hub | main menu | `../../index.html` |
| `index.html` | hub | `topics/verbos-en-profundidad/verbos-en-profundidad.html` |
| favicon (all) | — | absolute `/assets/bandera/…` |

### Nesting rule — amended

The original rule was one level only: hub → verb page, no deeper. *Tener* broke it by needing a second page for the structural construction.

**Amended rule:** a verb page may have **flat sibling extensions** named `<verb>-<subtopic>.html`, living in the same folder rather than a nested subfolder. They sort alphabetically beside their parent, and their back-nav points to the parent verb page (`← Volver a Tener`), not to the hub. Per-verb subfolders remain disallowed until some verb genuinely needs three or more pages.

### What the hub page is

A *light* page: title card + one short intro paragraph + a grid of verb cards. **No content cards of its own.** Card format is the verb set large with a thesis line beneath — *TENER — un sistema, no una lista*; *PODER — una sola potencia, varios blancos* — so the hub teaches something at a glance instead of listing infinitives.

**No placeholder cards for unbuilt verbs.** A hub full of dead links is worse than a short hub. Verbs in preparation may be named in a plain roadmap note at the foot of the page; they do not get cards until they exist.

### Index wiring

A **single** `<a class="link-item">` in the Vocab → Verbos sub-hub, per `index-categorization.md` → *How to Add — Existing Bucket*. This one entry stands in for the entire deep-dive library.

**Children are NOT individually wired into `index.html`.** The hub is the only index entry; discovery happens *on* the hub page. **This is the mechanism that keeps the sub-bucket flat.**

---

## 5. The single-verb pipeline (repeatable)

1. **Draft** the verb as a `.md` — frames, NOTA points, example sentences, contrast tables. `esperar-uso.md` is the template.
2. **Build** it to `single-topic-page-spec.md` as a child of the hub, at `topics/verbos-en-profundidad/<verb>.html`:
   - numbered sections → content cards
   - NOTA blocks → NOTA boxes (English explainer layer, Spanish terms italicized inside)
   - frame/contrast tables → decision guides
   - every example sentence → an `.example-es` row with a 🔊 button (correct Spanish only in the spoken line)
3. **Add** a verb card to the hub's `.subpage-links`. No `index.html` change.
4. **Validate** per project discipline: `node --check` on extracted JS, tag-balance counter, CSS brace count, grep the named feature markers (favicon block, back-nav path, rate bar, `es-419` chain, absence of voseo in spoken lines).
5. **Deploy the child alone**, then the hub card and any index change as a separate step — one observable change per deploy.

---

## 6. Thematic clusters stay flat — and when to revisit

- **Adding one:** a single `<a class="link-item">` in the Vocab → Verbos sub-hub + bump the `sub-hub-count`. (`index-categorization.md` → *How to Add — Existing Bucket*.) Built to `single-topic-page-spec.md` like any topic page.
- **Trigger to reconsider:** if flat thematic verb pages ever exceed **~6–7**, stand up a parallel **"Verbos por Tema"** hub and migrate them in (same parent→subpage convention as §4). Until then, flat beats an extra click.

---

## 7. Cleanup of the two legacy pages

- **`Verbos con Que-` → remove.** Not useful; predates the single-topic format. Delete the link item, decrement the sub-hub count, archive the file. Do it anytime.
- **`Familia de Poner` → rebuild, don't delete.** *poner/ponerse* is worth keeping and overlaps the planned **meter** explorer (meter/poner are a natural pair). When the hub exists, rebuild *poner* to spec as a hub child — consider merging *poner + meter* into one explorer. Pull it from the flat list at that point. Not urgent.

---

## 8. Where the roadmap's verb explorers land

The Verb Depth Explorer pages on the horizon — **quedar, echar, llevar, meter, dar, poder, rendir** — are all single-verb deep dives, so they all become **children of the Verbos en Profundidad hub**.

***Tener* is the first child and the pattern-setter** (August 2026), not *esperar* as originally projected. What it established, for reuse:

- **Thesis-line naming** — every verb page gets a claim, not a label.
- **Frame chips** — each phrase entry carries its full grammatical frame as labelled chips (`PREP` · `IMP` · `CUANT` · `ASP` · `GRAM` · `REG`), generated from a single data array alongside the master table so the two cannot drift.
- **A legend is mandatory** wherever chips appear — placed at the head of the inventory section and mirrored into the Guía Rápida. Chips must be readable cold, months later, without hunting for the section that explained them.
- **System before inventory** — the rules that cut across the whole verb come first; the phrase families follow.
- **Hybrid accordion** — argument sections open by default, lookup sections collapsed.
- **Honest marking** — where a rule *predicts* a form but usage is unattested, the entry is tagged rather than asserted, and the open items are collected in one block at the foot of the page.

---

## 9. Net effect on the index

Vocab → Verbos goes from "every verb is its own link" to:

- **Verbos en Profundidad** ← hub; holds N single-verb pages, costs 1 index entry *(shipped: tener)*
- **Tema del Movimiento**
- **Los Verbos de Demostración**
- **Prestar y Pedir Prestado**
- *(Familia de Poner — interim, until rebuilt into the hub)*
- **Cuando las cosas se rompen** *(the breaking/damaging set — shipped)*

One entry per theme, plus one entry for the entire deep-dive library — regardless of how many individual verbs accumulate inside.

> The hub shipped in August 2026; the *Quick Reference — Current State* block in `index-categorization.md` has been updated to reflect it.

---

*End of doc. Commit a copy to the project folder once approved.*
