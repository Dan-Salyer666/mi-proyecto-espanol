<!-- FILE ROLE ------------------------------------------------------------
WHAT THIS IS:  What is live on the site and still has loose ends. One short
               section per component. Plus deferred edits, shelved decisions,
               and a recent-sessions log.
BELONGS HERE:  Facts about shipped things. Short. If a section grows past a
               screen, the detail probably belongs on the page itself.
DOES NOT:      Build plans (-> TALLER-*.md). Ideas (-> 06). How-to (-> 03/04).
NOTHING HERE IS A DEADLINE. See 00-README -> Rule 3.
LAST UPDATED:  2026-08-23 (folder restructure)
------------------------------------------------------------------------ -->

# 05 — State

## Recent sessions (newest first, keep 5)

**2026-08-23 — Project folder restructure.** 25 topic-organised files → 8 role-organised files + 3 TALLER slots + standing `TALLER-clase.md`. Slots given to rendir, ser/estar, medida-medio. Pronunciación back-burnered. Established: content sign-off is Daniel's alone; confidence markers replace `? por confirmar`; *Palabras que se confunden* named as a page family. Pre-restructure snapshot zipped to `repo/specs/`.

*(Earlier sessions predate this log.)*

---

## Live components with open threads

### Comprensión Lectora — `interactive/comprension-lectora.html`

**Status: complete.** Generation pipeline, multi-provider routing (Claude + Gemini), provider persistence, Semilla Aleatoria (engine + vat + review + genre filter), story bible / canon continuity, structured Gemini output via `responseSchema`. All shipped and field-tested. No open build work.

Open threads:

- **`variationBlock` suppression** — undecided whether to suppress it when `hasStoryPlan` is true. Revisit when reviewing prose quality.
- **`thinking` is dropped on the Anthropic path.** `generate.mts` handles `thinking` only on the Gemini branch; the Anthropic branch silently discards it. *(Surfaced 2026-08-23 from the now-deleted Gemini schema spec.)*
- **`story_plan` can be null.** It is persisted as `storyPlan || null`. Anything downstream must tolerate null. *(Same origin.)*

The seed vat (`datos/seeds/semillas-data.js`) is pure data — adding genres/themes or adjusting `noneWeight`/`weight` needs no code, just a `version` bump.

Schema implementation, for reference: `buildResponseSchema` at page ~line 1619, sent ~2370, applied in `generate.mts` ~209.

### Verbos en Profundidad — `tener` · `tener-estructural`

**Status: shipped, August 2026.** The frame-chip system is the device the pages hang on and the thing most worth reusing — see the *Hard-won lessons* now folded into `03-page-standards.md`.

Open thread — **the chip relabel** (see *Deferred edits* below). The 11 items catalogued in the old state doc were the *listed* ones; the live page carries **19** `por confirmar` instances (verified 2026-08-23). The catalogue was already wrong about its own page, which is a good argument for keeping this file short and the page authoritative.

Two Gemini reviews were applied as second opinion, not attestation (30 items on `tener.html`, 5 on `tener-estructural.html`). Landed corrections include *tenerle envidia a* (dative), *dificultad para* over *en*, *¡Ten suerte!* deleted as rule-breaking, *una gripe fuerte* over a quantifier, and object-first order in `tener-estructural` §⑥.

### Formación de Preguntas — four pages

**Status: mostly shipped.** `preguntas.html`, `preguntas-trampas.html`, `preguntas-dinamica.html`, `preguntas-jeopardy.html` (54 KB, API-backed, target mode + weakness store live).

Open threads:

- **Dimension B is unshipped.** `features` appears **zero times** across all four pages (verified 2026-08-23).
- **§10 open decisions** from the old app spec remain unresolved. Full text preserved in the 2026-08-23 snapshot zip if needed.

### Entrenador de Verbos — `entrenador-de-verbos` · `entrenador-de-verbos2`

**Status: both deployed.** V1 ~513 KB, 701 verbs, 4 modes, with EN meanings, contextQ translations, irregular badges, and the *gustar* emotion fix. V2 runs on the four split data files in `datos/verbos/`. Hub at `entrenadores.html`.

Open threads:

- **Sin Ver audit** — Daniel is working through it and will bring batch fixes.
- **To-add verbs** — SpanishDict list URLs → fetch, dedupe against `final_master_list.md` (now in the repo), enrich, rebuild.
- A data-admin UI was specced and never built → `07-materials.md` § `entrenador-admin`.

---

## Deferred edits

Not a queue and not a deadline. These are notes that fire **when that page is next open for another reason**.

- **`topics/verbos-en-profundidad/tener.html` — chip relabel.** Replace the 19 `? por confirmar` chips with the stable confidence markers `USO VARIABLE` / `REG: incierto` / `NO ATESTIGUADO`, and rewrite the *Puntos por confirmar* block to say these are lower-confidence rather than pending. Update the chip legend and the Guía Rápida modal to match. The old state doc anticipated this: *"a marker that never resolves is worse than none."* Decided 2026-08-23.
- **`topics/IOP usage.html` — rename.** Literal space in the filename renders as `%20` in every link. Also written English-primary rather than Spanish-primary. Rename + fix inbound links; a content expansion is also wanted.
- **`topics/rasgos.html` — rename.** The filename gives no hint it is *Las cinco A*. Candidate: `las-cinco-a.html`.
- **Back-arrows cleanup** across older pages, plus a grammar-page styling pass.
- **`topics/adjectivos-no-graduables.html`** — add a short pointer NOTA up to *Gradación e intensidad*, if and when that page is built. Separate edit, separate deploy.

Renames travel together with their inbound links — the site has ~327 internal links and no build step to catch a break.

---

## Shelved decisions

- **Tiempo y Distancia — quizzes 2 and 3.** Drafted, then shelved. The drafts are preserved in `07-materials.md` § `tiempo-distancia-quizzes`. Not cancelled, just not wanted at the time.
- **Front-page dialect toggle.** On hold and being retired. Five pages read `spanish_dialect` from `localStorage`, all with `|| 'neutral'` fallbacks — so removing the toggle requires **no edits** to those pages.
- **Site cleanup** (copy-pasted CSS, directory drift, 327 internal links). Acknowledged, low priority. Deferred until the new CS/Linux site's visual design proves itself and can serve as the target.
