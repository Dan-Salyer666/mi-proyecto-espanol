<!-- FILE ROLE ------------------------------------------------------------
TALLER SLOT 3 of 3. Active build. Page: topics/medida-medio.html
BORN:    2026-08-23 (from a Gemini draft + Daniel's misreading that prompted it)
DIES:    at deploy. Killing it is Claude's job, same session as the ship:
         general lessons -> 03-page-standards.md; open threads -> 05-state.md;
         the rest is deleted, because the page is now the record.
STATUS:  content drafted, NOT signed off. Small page. Card plan below is a
         proposal — discuss before building, per usual workflow.
------------------------------------------------------------------------ -->

# TALLER — *Medida* vs. *Medio*

## Why this page exists

Daniel misread the two while reading. That is the whole brief. They look alike enough to collide at reading speed, and the collision **is** the subject.

This makes it a member of the ***Palabras que se confunden*** family — alongside *Las cinco A* (`rasgos.html`), *Tropiezos con P* (`tropiezos-con-p.html`) and *Palabras Tramposas* (`palabras-tramposas.html`). See `02-site-map.md` → Part B. Collision type: **similar form**.

**Scope discipline:** this is a *quick reference to stop the confusion*, not a treatise on either word. Resist expansion. If a sense turns out to need real depth, it goes to a theme page, not here.

## Placement

- **File:** `topics/medida-medio.html`
- **Bucket:** Vocabulario → **Palabras que se confunden** *(bucket not yet implemented — until it is, file under Vocabulario → Miscelánea and move it with the others later; see `06-ideas.md` § `reagrupar-confundibles`)*
- **Species:** small static page → `03-page-standards.md` applies in full. Neutral TTS, English NOTA layer, back-nav to `../index.html`.
- **Title:** *Medida y medio* — subtitle candidate: *Escalas y mitades*

## The core distinction

Two words in genuinely different conceptual spaces, which is what makes a clean page possible:

- ***Medida*** ← *medir*. **Scaling and progression.** Rulers, proportion, gradual change, exact sizing. Something is *moving along a scale*.
- ***Medio*** ← the fraction ½. **Halves, centres, instruments.** A split, a literal midpoint, or the vehicle used to get something done. **Static.**

## Proposed card plan

Five cards. Negotiable — ① and ② are load-bearing, ⑤ is the payoff.

### ① *Medida* — la escala
| Frase | Literal | Sentido | Ejemplo |
|---|---|---|---|
| **ropa a medida** | to measure | hecha a la medida de alguien | *Me compré un traje a medida.* |
| **a medida que** | to the measure that | conforme, al mismo tiempo que (gradual) | *A medida que practicas, entiendes mejor el acento.* |
| **en gran medida** | in great measure | en buena parte | *El éxito del viaje depende en gran medida de la preparación.* |
| **tomar medidas** | to take measures | actuar — o tomar las dimensiones | *Hay que tomar medidas preventivas.* |

Note the double life of *tomar medidas* — it is both "take action" and "take someone's measurements", and context alone separates them. Worth one line; it is a small joke the language is making.

### ② *Medio* — la mitad, el centro, el instrumento
| Frase | Literal | Sentido | Ejemplo |
|---|---|---|---|
| **un año y medio** | — | a year and a half | *Planeo quedarme un año y medio en Buenos Aires.* |
| **en medio de** | in middle of | rodeado por, en pleno | *El café está en medio de la plaza.* |
| **a medias** | to halves | sin terminar; o entre dos | *No dejes el estudio a medias.* |
| **por medio de** | by middle of | a través de, usando | *Nos comunicamos por medio de mensajes.* |
| **medio ambiente** | — | the environment | *Debemos cuidar el medio ambiente.* |

### ③ El diagnóstico — the binary check
The card Daniel will actually use. Ask one question before committing:

- **¿Proporción, progresión o tamaño?** → *medida*
- **¿Mitades, centros o instrumentos?** → *medio*

### ④ Los que casi se tocan
The pairs where the confusion actually lives, side by side — this is the card that earns the page rather than restating a dictionary:

- ***a medida que*** (gradual, *as*) vs. ***a medias*** (incomplete, *halfway*) — closest pair by sound.
- ***en gran medida*** (largely) vs. ***en medio de*** (amidst).
- ***por medio de*** (by means of) vs. ***a medida*** (custom-made).

### ⑤ NOTA — in English
*Medida* is a **ruler**; *medio* is a **half or a middle**. Every idiom on the page is that root doing its obvious job — *a medida que* is literally "to the measure that," so it tracks two things changing together; *por medio de* is literally "by middle of," so it names whatever sits *between* you and the result. Once the roots are visible, none of these have to be memorised individually.

## Build notes

- **Voseo removed on intake.** The Gemini source draft used *A medida que practicás* — standard Gemini drift. All examples are neutral (*practicas*). Buenos Aires appears as a *place* in one example, which is fine and true to Daniel's context; the *grammar* stays neutral.
- ***a medida que* is also claimed by the future conectores hub** (`06-ideas.md` § `conectores`, listed there as a time connector alongside *desde que*). **Settled 2026-08-23: this page owns the disambiguation; the hub cross-links rather than re-covering it.** Recording it here so it isn't rediscovered in a year.
- **Field is clear.** Verified against the live repo 2026-08-23: zero site hits for *a medida que*, *en medio de*. One hit for *a medias* on `topics/adverbios.html` — make that a cross-link, don't duplicate.
- **Confidence:** everything here is common and well-attested; no markers expected. If any register call feels like a judgment, mark it `REG: incierto` inline and ship.

## Open for Daniel

1. Five cards or four? ④ could fold into ③.
2. Title: *Medida y medio* vs. *Medida vs. medio* — the site leans Spanish-primary, and *vs.* is a little English.
3. File under Miscelánea now and move later, or hold the page until the *Palabras que se confunden* bucket exists?
